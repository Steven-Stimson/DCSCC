# 提示语国际化翻译
PATH_ERROR = 'PATH_ERROR'
SYSTEM_ERROR = 'SYSTEM_ERROR'
PATH_TYPE_ERROR = 'PATH_TYPE_ERROR'
DISK_SPACE_ERROR = 'DISK_SPACE_ERROR'
FILE_INVALID_ERROR = 'FILE_INVALID_ERROR'
QUERY_FAILED_ERROR = 'QUERY_FAILED_ERROR'
CLOUD_SERVICE_ERROR = 'CLOUD_SERVICE_ERROR'
GET_USER_PREM_ERROR = 'GET_USER_PREM_ERROR'
FILE_NOT_FOUND_ERROR = 'FILE_NOT_FOUND_ERROR'
NOT_A_DIRECTORY_ERROR = 'NOT_A_DIRECTORY_ERROR'
FILE_GENERATION_ERROR = 'FILE_GENERATION_ERROR'
FILE_GENERATION_SUCCESS = 'FILE_GENERATION_SUCCESS'
PERMISSION_DENIED_ERROR = 'PERMISSION_DENIED_ERROR'
INPUT_VALID_NUMBER_ERROR = 'INPUT_VALID_NUMBER_ERROR'
AUTHENTICATION_FAILED_ERROR = 'AUTHENTICATION_FAILED_ERROR'
NO_DIRECTORY_ACCESS_PERMISSION = 'NO_DIRECTORY_ACCESS_PERMISSION'
NO_FILE_READ_PERMISSION = 'NO_FILE_READ_PERMISSION'
ECHO_TOTAL_COUNT_SUCCESS = 'ECHO_TOTAL_COUNT_SUCCESS'
PERMISSION_DENIED_ACCESS_ERROR = 'PERMISSION_DENIED_ACCESS_ERROR'
PERMISSION_DENIED_WRITE_ERROR = 'PERMISSION_DENIED_WRITE_ERROR'
# 其他字段国际化翻译
TAG = 'TAG'
CREATOR = 'CREATOR'
DESCRIBE = 'DESCRIBE'
CREATE_TIME = 'CREATE_TIME'
SOURCE_SYSTEM = 'SOURCE_SYSTEM'

COMMON_CODES = {
    FILE_NOT_FOUND_ERROR: {
        'en': 'File path "%s" does not exist. Please verify the path exists within the current container.',
        'zh': '文件路径“%s”不存在，请检查路径是否存在当前容器中。'
    },
    FILE_INVALID_ERROR: {
        'en': 'File "%s" is invalid. Currently only files with the following extensions are supported: %s.',
        'zh': '文件“%s”不符合规范，当前仅支持“%s”后缀的文件。'
    },
    AUTHENTICATION_FAILED_ERROR: {
        'en': 'Session expired. Please sign in again to continue.',
        'zh': '认证失败：会话已过期，请重新登录。'
    },
    CLOUD_SERVICE_ERROR: {
        'en': 'STOmics Cloud Service Exception',
        'zh': 'STOmics Cloud服务异常'
    },
    PATH_ERROR: {
        'en': 'Invalid path.',
        'zh': '路径有误。',
    },
    PATH_TYPE_ERROR: {
        'en': 'Path must be a string type, current type: %s.',
        'zh': '路径必须是字符串类型，当前类型: %s。',
    },
    NOT_A_DIRECTORY_ERROR: {
        "en": "Cannot create subdirectory. A file already exists at the path.",
        "zh": "无法创建子目录，路径中存在文件。",
    },
    PERMISSION_DENIED_ERROR: {
        'en': 'No permission to create directory "%s". Please check path permissions.',
        'zh': '没有权限创建目录%s，请检查路径权限。',
    },
    PERMISSION_DENIED_ACCESS_ERROR: {
        'en': 'No permission to access directory "%s". Please check the directory permissions.',
        'zh': '没有权限访问目录%s，请检查路径权限。',
    },
    PERMISSION_DENIED_WRITE_ERROR: {
        'en': 'No permission to write directory "%s". Please check path permissions.',
        'zh': '没有权限写入目录%s，请检查路径权限。',
    },
    DISK_SPACE_ERROR: {
        'en': 'Insufficient disk space to create directory.',
        'zh': '磁盘空间不足，无法创建目录。',
    },
    SYSTEM_ERROR: {
        'en': 'System error.',
        'zh': '系统错误。',
    },
    QUERY_FAILED_ERROR: {
        'en': 'Data query failed.',
        'zh': '查询数据失败。'
    },
    INPUT_VALID_NUMBER_ERROR: {
        'en': 'Please enter a valid number.',
        'zh': '请输入有效数字。',
    },
    FILE_GENERATION_SUCCESS: {
        'en': 'File generated successfully at: %s',
        'zh': '文件生成成功，路径:  %s',
    },
    FILE_GENERATION_ERROR: {
        'en': 'File generation failed: "%s"',
        'zh': '文件生成失败：%s',
    },
    GET_USER_PREM_ERROR: {
        'en': 'Failed to obtain user permissions.',
        'zh': '获取用户权限失败。',
    },
    NO_DIRECTORY_ACCESS_PERMISSION: {
        "en": "No directory access permission: %s.",
        "zh": "无路径访问权限: %s."
    },
    NO_FILE_READ_PERMISSION: {
        "en": "No read permission for file: %s.",
        "zh": "无文件读取权限: %s."
    },
    ECHO_TOTAL_COUNT_SUCCESS: {
        "en": "Total: %s items.",
        "zh": "共%s条。"
    },

    # 其他字段
    CREATE_TIME: {
        'en': 'Create Time',
        'zh': '创建时间'
    },
    CREATOR: {
        'en': 'Creator',
        'zh': '创建人',
    },
    DESCRIBE: {
        'en': 'Describe',
        'zh': '描述',
    },
    TAG: {
        'en': 'Tag',
        'zh': '标签',
    },
    SOURCE_SYSTEM: {
        'en': 'Source',
        'zh': '来源'
    },
}
