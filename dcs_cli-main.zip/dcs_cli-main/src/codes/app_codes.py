# 提示语国际化翻译
APP_INPUT_ERROR = 'APP_INPUT_ERROR'
VERIFICATION_SUCCESS = 'VERIFICATION_SUCCESS'
VERIFICATION_FAILED_ERROR = 'VERIFICATION_FAILED_ERROR'
PULL_APP_FAILED_ERROR = 'PULL_APP_FAILED_ERROR'
DOWNLOAD_SUCCESS = 'DOWNLOAD_SUCCESS'
REGISTER_SUCCESS = 'REGISTER_SUCCESS'
LOAD_FAILED_ERROR = 'LOAD_FAILED_ERROR'
REGISTER_FAILED_ERROR = 'REGISTER_FAILED_ERROR'
PULL_FAILED_ERROR = 'PULL_FAILED_ERROR'
UPDATE_SUCCESS = 'UPDATE_SUCCESS'
UPDATE_FAILED_ERROR = 'UPDATE_FAILED_ERROR'
NO_WORKFLOW_IMPORT_ERROR = 'NO_WORKFLOW_IMPORT_ERROR'
NO_WORKFLOW_EXPORT_ERROR = 'NO_WORKFLOW_EXPORT_ERROR'
NO_WORKFLOW_COPY_ERROR = 'NO_WORKFLOW_COPY_ERROR'
NO_WORKFLOW_DETAIL_ERROR = 'NO_WORKFLOW_DETAIL_ERROR'
NO_WORKFLOW_UPDATE_ERROR = 'NO_WORKFLOW_UPDATE_ERROR'
PUBLIC_AND_VERSION_ERROR = 'PUBLIC_AND_VERSION_ERROR'
GET_UPDATE_LIST_EMPTY_ERROR = 'GET_UPDATE_LIST_EMPTY_ERROR'
APP_NOT_FOUND_BY_NAME_ERROR = 'APP_NOT_FOUND_BY_NAME_ERROR'
APP_NOT_FOUND_BY_NAME_AND_VERSION_ERROR = 'APP_NOT_FOUND_BY_NAME_AND_VERSION_ERROR'
APP_PUBLIC_NOT_FOUND_BY_NAME_ERROR = 'APP_PUBLIC_NOT_FOUND_BY_NAME_ERROR'
APP_PUBLIC_NOT_FOUND_BY_NAME_AND_VERSION_ERROR = 'APP_PUBLIC_NOT_FOUND_BY_NAME_AND_VERSION_ERROR'
# 其他字段国际化翻译
WORKFLOW_NAME = 'WORKFLOW_NAME'
WORKFLOW_CREATOR = 'WORKFLOW_CREATOR'
WORKFLOW_TAGS = 'WORKFLOW_TAGS'
WORKFLOW_PRICE = 'WORKFLOW_PRICE'
PRIVATE_WORKFLOW = 'PRIVATE_WORKFLOW'
PUBLIC_WORKFLOW = 'PUBLIC_WORKFLOW'

APP_CODES = {
    APP_PUBLIC_NOT_FOUND_BY_NAME_AND_VERSION_ERROR: {
        'en': 'Cannot find an app named "%s" with version "%s". Please use "dcs app ls -p" to list all available apps.',
        'zh': '找不到名称为“%s”、版本为“%s”的应用。请使用“dcs app ls -p”查找所有可用应用。'
    },
    APP_PUBLIC_NOT_FOUND_BY_NAME_ERROR: {
        'en': 'Cannot find an app named "%s". Please use "dcs app ls -p" to list all available apps.',
        'zh': '找不到名称为“%s”的应用。请使用“dcs app ls -p”查找所有可用应用。'
    },
    APP_NOT_FOUND_BY_NAME_AND_VERSION_ERROR: {
        'en': 'Cannot find an app named "%s" with version "%s". Please use "dcs app ls" to list all available apps.',
        'zh': '找不到名称为“%s”、版本为“%s”的应用。请使用“dcs app ls”查找所有可用应用。'
    },
    APP_NOT_FOUND_BY_NAME_ERROR: {
        'en': 'Cannot find an app named "%s". Please use "dcs app ls" to list all available apps.',
        'zh': '找不到名称为“%s”的应用。请使用“dcs app ls”查找所有可用应用。'
    },
    APP_INPUT_ERROR: {
        'en': 'Found %s invalid input: %s.',
        'zh': '发现%s个无效输入: %s。'
    },
    VERIFICATION_SUCCESS: {
        'en': 'Verification successful: %s.',
        'zh': '校验成功：%s。'
    },
    VERIFICATION_FAILED_ERROR: {
        'en': 'Verification failed: %s.',
        'zh': '校验失败：%s。'
    },
    PULL_APP_FAILED_ERROR: {
        'en': 'Failed to pull the application "%s" from the public repository.',
        'zh': '拉取公共库的应用“%s”失败。'
    },
    DOWNLOAD_SUCCESS: {
        'en': 'The download path for the tool is: %s',
        'zh': '工具下载的路径为：%s'
    },
    REGISTER_SUCCESS: {
        'en': 'Registration workflow successful.',
        'zh': '注册流程成功。'
    },
    REGISTER_FAILED_ERROR: {
        'en': 'Registration workflow failed.',
        'zh': '注册流程失败。'
    },
    LOAD_FAILED_ERROR: {
        'en': 'The following workflows failed to import. Please verify the file format and related configurations:',
        'zh': '以下工作流导入异常，请检查文件格式及相关配置：'
    },

    PULL_FAILED_ERROR: {
        'en': 'Failed to pull the tool to local.',
        'zh': '拉取工具到本地失败。'
    },
    UPDATE_SUCCESS: {
        'en': 'Workflow update succeeded.',
        'zh': '更新工作流成功。'
    },
    UPDATE_FAILED_ERROR: {
        'en': 'Workflow update failed.',
        'zh': '更新工作流失败。'
    },
    GET_UPDATE_LIST_EMPTY_ERROR: {
        'en': 'No updatable workflows found, or the workflows are already up to date and require no update.',
        'zh': '未找到可更新工作流或该工作流已经是最新版本，无需更新。'
    },
    NO_WORKFLOW_IMPORT_ERROR: {
        "en": "No import permission. Cannot execute 'dcs app push' command.",
        "zh": "无导入权限，不可执行dcs app push命令。"
    },
    NO_WORKFLOW_EXPORT_ERROR: {
        "en": "No export permission. Cannot execute 'dcs app pull' command.",
        "zh": "无导出权限，不可执行dcs app pull命令。"
    },
    NO_WORKFLOW_COPY_ERROR: {
        "en": "No copy permission, cannot copy workflow from public library.",
        "zh": "无复制权限，不可从公共库复制工作流。"
    },
    NO_WORKFLOW_UPDATE_ERROR: {
        "en": "No update permission. Cannot execute 'dcs app update' command.",
        "zh": "无更新权限，不可执行dcs app update命令。"
    },
    NO_WORKFLOW_DETAIL_ERROR: {
        "en": "No view permission. Cannot execute 'dcs app info' command.",
        "zh": "无查看详情权限，不可执行dcs app info命令。"
    },
    PUBLIC_AND_VERSION_ERROR: {
        "en": "The 'public' parameter cannot be used together with a version number.",
        "zh": "参数public不能跟版本（version）号共用。"
    },
    WORKFLOW_NAME: {
        'en': 'Workflow Name',
        'zh': '流程名称',
    },
    WORKFLOW_CREATOR: {
        'en': 'Workflow Creator',
        'zh': '流程创建人',
    },
    WORKFLOW_TAGS: {
        'en': 'Workflow Tags',
        'zh': '流程标签'
    },
    WORKFLOW_PRICE: {
        'en': 'Price',
        'zh': '流程价格'
    },
    PRIVATE_WORKFLOW: {
        'en': 'Private Workflow',
        'zh': '私有流程'
    },
    PUBLIC_WORKFLOW: {
        'en': 'Public Workflow',
        'zh': '公共流程'
    }
}
