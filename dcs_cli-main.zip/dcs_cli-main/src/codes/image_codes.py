# 提示语国际化翻译
IMAGE_EXEC_INFO_ERROR = 'IMAGE_EXEC_INFO_ERROR'
IMAGE_NOT_FOUND_BY_URL_ERROR = 'IMAGE_NOT_FOUND_BY_URL_ERROR'
IMAGE_NOT_FOUND_BY_NAME_ERROR = 'IMAGE_NOT_FOUND_BY_NAME_ERROR'
IMAGE_NOT_FOUND_BY_URL_AND_NAME_ERROR = 'IMAGE_NOT_FOUND_BY_URL_AND_NAME_ERROR'
IMAGE_PUBLIC_NOT_FOUND_BY_NAME_ERROR = 'IMAGE_PUBLIC_NOT_FOUND_BY_NAME_ERROR'
IMAGE_PUBLIC_NOT_FOUND_BY_URL_ERROR = 'IMAGE_PUBLIC_NOT_FOUND_BY_URL_ERROR'
IMAGE_PUBLIC_NOT_FOUND_BY_URL_AND_NAME_ERROR = 'IMAGE_PUBLIC_NOT_FOUND_BY_URL_AND_NAME_ERROR'

# 其他字段国际化翻译
BUILD_TYPE = 'BUILD_TYPE'
IMAGE_NAME = 'IMAGE_NAME'
IMAGE_URL = 'IMAGE_URL'
PACKAGE_AND_VERSIONS = 'PACKAGE_AND_VERSIONS'
PROGRAMMING_LANGUAGE = 'PROGRAMMING_LANGUAGE'
PLATFORM_BASED = 'PLATFORM_BASED'
NETWORK_BASED = 'NETWORK_BASED'

IMAGE_CODES = {
    IMAGE_PUBLIC_NOT_FOUND_BY_NAME_ERROR: {
        'en': 'Cannot find image named "%s". Please recheck the name or use "dcs image ls -p" to list '
              'all available images.',
        'zh': '找不到名称为“%s”的镜像。请重新检查名称或使用“dcs image ls -p”查看所有可用镜像。'
    },
    IMAGE_PUBLIC_NOT_FOUND_BY_URL_ERROR: {
        'en': 'Cannot find an image with URL "%s". Please recheck the URL or use "dcs image ls -p" to list '
              'all available images.',
        'zh': '找不到URL为“%s”的镜像。请重新检查URL或使用“dcs image ls -p”查看所有可用镜像。'
    },
    IMAGE_PUBLIC_NOT_FOUND_BY_URL_AND_NAME_ERROR: {
        'en': 'Cannot find an image with URL "%s" and name "%s". Please recheck the name and URL or use "dcs image ls'
              ' -p" to list all available images.',
        'zh': '找不到URL为“%s”、名称为“%s”的镜像。请重新检查名称和URL或使用“dcs image ls -p”查看所有可用镜像。'
    },
    IMAGE_NOT_FOUND_BY_NAME_ERROR: {
        'en': 'Cannot find image named "%s". Please recheck the name or use "dcs image ls" to list '
              'all available images.',
        'zh': '找不到名称为“%s”的镜像。请重新检查名称或使用“dcs image ls”查看所有可用镜像。'
    },
    IMAGE_NOT_FOUND_BY_URL_ERROR: {
        'en': 'Cannot find an image with URL "%s". Please recheck the URL or use "dcs image ls" to list '
              'all available images.',
        'zh': '找不到URL为“%s”的镜像。请重新检查URL或使用“dcs image ls”查看所有可用镜像。'
    },
    IMAGE_NOT_FOUND_BY_URL_AND_NAME_ERROR: {
        'en': 'Cannot find an image with URL "%s" and name "%s". Please recheck the name and URL or use "dcs image ls"'
              ' to list all available images.',
        'zh': '找不到URL为“%s”、名称为“%s”的镜像。请重新检查名称和URL或使用“dcs image ls”查看所有可用镜像。'
    },
    IMAGE_EXEC_INFO_ERROR: {
        'en': 'Required: Please provide "-n/--name" or "-u/--url" to continue.',
        'zh': '请输入"-n/--name"或者"-u/--url"命令。'
    },

    # image表单相关国际化
    IMAGE_NAME: {
        'en': 'Image Name',
        'zh': '镜像名称',
    },
    PROGRAMMING_LANGUAGE: {
        'en': 'Programming Language',
        'zh': '编程环境',
    },
    BUILD_TYPE: {
        'en': 'Build Type',
        'zh': '构建方式',
    },
    PACKAGE_AND_VERSIONS: {
        'en': 'Package And Versions',
        'zh': '工具包及版本',
    },
    IMAGE_URL: {
        'en': 'IMAGE URL',
        'zh': '镜像URL',
    },
    PLATFORM_BASED: {
        'en': 'Platform-based',
        'zh': '基于平台镜像',
    },
    NETWORK_BASED: {
        'en': 'Network-based',
        'zh': '基于公网镜像',
    },

}
