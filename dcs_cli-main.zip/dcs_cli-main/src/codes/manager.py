import os
from typing import Dict, Any, Optional

from src.codes.app_codes import APP_CODES
from src.codes.common_codes import COMMON_CODES
from src.codes.image_codes import IMAGE_CODES


class CodeManager:
    def __init__(self):
        self._code_registry: Dict[str, Dict[str, Dict[str, str]]] = {}
        self._language_fallback = "zh"

    def register_codes(self, category: str, codes: Dict[str, Dict[str, str]]) -> None:
        """动态注册新的代码类别"""
        if category in self._code_registry:
            conflicting_keys = set(self._code_registry[category].keys()) & set(codes.keys())
            if conflicting_keys:
                raise KeyError(f"键名冲突: {conflicting_keys} in category {category}")
            self._code_registry[category].update(codes)
        else:
            self._code_registry[category] = codes

    def get_msg_info(
            self,
            key: str,
            lang: str = None,
            category: str = None,
            default: str = None,
            **format_args: Any
    ) -> str:
        """统一查询入口"""
        # 自动语言检测
        target_lang = lang or self._detect_system_language()

        # 多类别搜索
        candidates = []
        if category:
            candidates.append(category)
        else:
            candidates = list(self._code_registry.keys())

        for cat in candidates:
            if code_entry := self._code_registry.get(cat, {}).get(key):
                # 处理多语言回退
                msg = code_entry.get(target_lang) or code_entry.get(self._language_fallback)
                if msg:
                    return msg.format(**format_args) if format_args else msg

        # 未找到的兜底处理
        return default or f"[[Translation missing: {key}]]"

    def translate_message(
            self,
            original_msg: str,
            target_lang: str,
            source_lang: Optional[str] = None,
            default: Optional[str] = None,
            **kwargs
    ) -> str:
        """
        在已注册的国际化代码中查找对应翻译
        比如： Tag -> 标签  或者 Tag -> 标签
        :param original_msg: 需要翻译的原始信息 (支持带格式化占位符)
        :param target_lang: 目标语言代码 (如 'en', 'zh')
        :param source_lang: 可选指定原始语言代码，加速查找
        :param default: 未找到翻译时的默认返回值
        :param kwargs: 需要注入的格式化参数
        :return: 翻译后的信息
        """
        # 遍历所有已注册的代码类别
        for category in manager_cli._code_registry.values():
            for code_entry in category.values():
                # 自动检测原始语言
                if source_lang:
                    if code_entry.get(source_lang) == original_msg:
                        return code_entry.get(target_lang, default).format(**kwargs)
                else:
                    for lang in ['en', 'zh']:
                        if code_entry.get(lang) == original_msg:
                            return code_entry.get(target_lang, default).format(**kwargs)

        # 未找到时的处理逻辑
        return default or original_msg

    def _detect_system_language(self) -> str:
        """实现系统语言检测逻辑"""
        return os.getenv('DCS_X_LANG') or self._language_fallback


# 初始化管理器并注册代码
manager_cli = CodeManager()
manager_cli.register_codes("app", APP_CODES)
manager_cli.register_codes("image", IMAGE_CODES)
manager_cli.register_codes("common", COMMON_CODES)
