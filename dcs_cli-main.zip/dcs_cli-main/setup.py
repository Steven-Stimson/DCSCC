from pathlib import Path

from setuptools import setup, find_packages

here = Path(__file__).resolve().parent
version_txt = here / 'version.txt'
requirements_txt = here / 'requirements.txt'
with open(version_txt, 'r') as f:
    version = f.read().strip()
with open(requirements_txt, 'r') as f:
    install_requires = f.read().splitlines()

setup(
    name='dcs-cli',
    version=version,
    packages=find_packages(),
    install_requires=install_requires,
    entry_points={
        'console_scripts': [
            'dcs = dcs_cli.main:main',
        ],
    },
)
