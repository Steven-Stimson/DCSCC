import click
import json
from click import Abort
from math import ceil
from typing import List
from urllib.parse import urljoin

from dcs_cli.common import MAX_DIRECT_PRINT_PAGESIZE
from dcs_cli.common import MAX_OUTPUT_PAGESIZE
from dcs_cli.common import URL_DICT
from dcs_cli.common import echo_info
from dcs_cli.enums import MsgStatusTypeEnum
from dcs_cli.utils import HelpOnInvalidCommand
from dcs_cli.utils import HelpOnMissingParamCommand
from dcs_cli.utils import _build_common_headers
from dcs_cli.utils import _build_common_params
from dcs_cli.utils import _safe_request
from dcs_cli.utils import bytes_to_human_readable
from dcs_cli.utils import echo_debug_info
from dcs_cli.utils import echo_exceprtion
from dcs_cli.utils import echo_table_info
from dcs_cli.utils import format_datetime
from dcs_cli.utils import handle_msg
from dcs_cli.utils import handle_output
from dcs_cli.utils import output_file
from dcs_cli.utils import paginate_query
from dcs_cli.utils import split_desc
from src.codes.common_codes import ECHO_TOTAL_COUNT_SUCCESS
from src.codes.common_codes import FILE_GENERATION_ERROR
from src.codes.common_codes import FILE_GENERATION_SUCCESS
from src.codes.common_codes import QUERY_FAILED_ERROR
from src.codes.image_codes import *
from src.codes.manager import manager_cli

base_image_type_map = {
    # 构建方式，1:基于平台镜像 2:基于公网镜像
    '1': manager_cli.get_msg_info(PLATFORM_BASED),
    '2': manager_cli.get_msg_info(NETWORK_BASED)
}

image_from_type_map = {
    # 在base_image_type!=1的情况下,镜像来源 1:sif/simg file,2:docker.io,3:cloud.sylabs.io，默认值为1
    '1': 'sif/simg file',
    '2': 'docker.io',
    '3': 'cloud.sylabs.io'
}
root_type_map = {
    # 编程环境 1:jupyter 2:workflow 3:vscode
    '0': '',
    '1': 'jupyter',
    '2': 'workflow',
    '3': 'vscode'
}


def handle_tags_info(tools):
    tags_dict = dict()
    if not tools:
        return tags_dict

    for key, tool_list in json.loads(tools).items():
        res = []
        for tool_info in tool_list:
            if 'version' not in tool_info or 'name' not in tool_info:
                continue
            res.append(f"{tool_info['name']}=={tool_info.get('version', '')}")
        tags_dict[key] = res

    return tags_dict


def echo_image_describe_table(data: List, public=None):
    """
    :param data: 镜像信息
    :return:
    """
    if public:
        for info in data:
            echo_info('镜像名称：' + handle_msg(info.get("imgName")))
            echo_info("URL：" + handle_msg(info.get("imgUrl")))
            echo_info('构建方式：' + base_image_type_map.get(info.get('baseImageType'), ''))
            echo_info('标签：' + handle_msg(info.get("srcTags")))
            echo_info('编程环境：' + root_type_map.get(str(info.get("progEnv")), ''))
            echo_info('镜像大小：' + bytes_to_human_readable(int(info["size"] if info.get("size") else 0)))
            echo_info('语言：' + handle_msg(info.get("imgPl")))
            echo_info('创建人：' + handle_msg(info.get("createByName")))
            echo_info('创建时间：' + handle_msg(info.get("createTime")))
            echo_info('更新时间：' + handle_msg(info.get("updateTime")))
            echo_info('当前版本：' + handle_msg(info.get("version")))
            echo_info('描述：' + handle_msg(info.get("imgDescription")))
            for language, packages in handle_tags_info(info.get('tools', {})).items():
                echo_info(f'工具包（{language}）及版本：' + ' '.join(packages))
            echo_info('bash指令：' + handle_msg(info.get('imgBuildScript')))
    else:
        for info in data:
            share_msg = ' 共享镜像' if info.get('share_status') == 1 else ''
            if info.get('container_name'):
                build_type = '容器快照'
            else:
                build_type = base_image_type_map.get(info.get('base_image_type'), '') + share_msg
            if info.get('base_image_type') == '1':
                image_from = info.get('base_image_name', '')
            else:
                image_from = image_from_type_map.get(info.get('external_image_type'), '1')
            echo_info('镜像名称：' + handle_msg(info.get("image_name")))
            image_url = info["image_url"].split('/', 1)[-1] + ':latest' if info.get("image_url") else info.get(
                "image_url")
            echo_info("URL：" + handle_msg(image_url))
            echo_info('构建方式：' + build_type)
            echo_info('标签：' + handle_msg(info.get("image_tags")))
            echo_info('编程环境：' + root_type_map.get(info.get("root_type"), ''))
            echo_info('镜像大小：' + bytes_to_human_readable(int(info["size"] if info.get("size") else 0)))
            echo_info('语言：' + handle_msg(info.get("language")))
            echo_info('创建人：' + handle_msg(info.get("username")))
            echo_info('创建时间：' + handle_msg(info.get("create_time")))
            echo_info('更新时间：' + handle_msg(info.get("update_time")))
            echo_info('当前版本：' + handle_msg(info.get("version")))
            echo_info('镜像来源：' + handle_msg(image_from))
            echo_info('描述：' + handle_msg(info.get("image_desc")))
            for language, packages in handle_tags_info(info.get('tools', {})).items():
                echo_info(f'工具包（{language}）及版本：' + ' '.join(packages))
            echo_info('bash指令：' + handle_msg(info.get('image_bash')))


def _build_image_table(data: List, pulic: bool):
    """
    :param data: 镜像信息
    :param pulic: 是否公共库img
    :return: table对象
    """
    from rich.table import Table
    table = Table(show_header=True, header_style="bold black", show_lines=True)
    table.add_column("镜像名称", width=35, overflow='fold')
    table.add_column("镜像URL", width=45, overflow='fold')
    table.add_column("标签", width=35, overflow='fold')
    table.add_column("编程环境", width=20, overflow='fold')
    table.add_column("创建人", width=20, overflow='fold')
    table.add_column("创建时间", width=25, overflow='fold')
    table.add_column("描述", width=35, overflow='fold')
    if not pulic:
        table.add_column("构建方式", width=20, overflow='fold')
        table.add_column("工具包及版本", width=35, overflow='fold')
        for info in data:
            tags = []
            for packages in handle_tags_info(info.get('tools', {})).values():
                tags += packages
            table.add_row(
                info.get("image_name"),
                info.get("image_url").split('/', 1)[-1] + ':latest' if info.get("image_url") else info.get("image_url"),
                info.get("image_tags").strip() if info.get("image_tags") else '',
                root_type_map.get(info.get("root_type"), ''),
                info.get("username"),
                info.get("create_time"),
                split_desc(info.get("image_desc")),
                base_image_type_map.get(info.get("base_image_type"), ''),
                " ".join(tags[:5]) if tags else ''
            )
    else:
        for info in data:
            image_url = info.get("more").get('url', '') if info.get("more") else ''
            if image_url:
                image_url = f'{image_url}:{info.get("version")}'
            table.add_row(
                info.get("name"),
                image_url if image_url else '-',
                ','.join(info.get('tags')) if info.get("tags") else '',
                root_type_map.get(str(info.get("progEnv", '')), ''),
                info.get("createdBy"),
                format_datetime(timestamp_ms=int(info.get("resCreatedAt"))),
                split_desc(info.get("intro"))
            )

    return table


def return_info(name, url, public):
    if public:
        if name and url:
            return echo_info(manager_cli.get_msg_info(IMAGE_PUBLIC_NOT_FOUND_BY_URL_AND_NAME_ERROR) % (url, name),
                             msg_status=MsgStatusTypeEnum.ERROR)
        elif name:
            return echo_info(manager_cli.get_msg_info(IMAGE_PUBLIC_NOT_FOUND_BY_NAME_ERROR) % name,
                             msg_status=MsgStatusTypeEnum.ERROR)
        else:
            return echo_info(manager_cli.get_msg_info(IMAGE_PUBLIC_NOT_FOUND_BY_URL_ERROR) % url,
                             msg_status=MsgStatusTypeEnum.ERROR)
    else:
        if name and url:
            return echo_info(manager_cli.get_msg_info(IMAGE_NOT_FOUND_BY_URL_AND_NAME_ERROR) % (url, name),
                             msg_status=MsgStatusTypeEnum.ERROR)
        elif name:
            return echo_info(manager_cli.get_msg_info(IMAGE_NOT_FOUND_BY_NAME_ERROR) % name,
                             msg_status=MsgStatusTypeEnum.ERROR)
        else:
            return echo_info(manager_cli.get_msg_info(IMAGE_NOT_FOUND_BY_URL_ERROR) % url,
                             msg_status=MsgStatusTypeEnum.ERROR)


def filter_records(data, name, url, public):
    """根据name过滤数据
    由于公共库如果使用name和url共同查询，这边直接使用的是url查询，所以需要用name过滤
    """
    if not public:
        return data.get('record')

    if not url or not name:
        return data.get('records')

    return [info for info in data.get('records', []) if name.upper() in info.get("name", '').upper()]


def _build_list_params(project, base_url, public, url, name, page_size=10):
    """构建请求参数"""
    if public:
        url = url.rsplit(':', 1)[0] if url else url
        params = _build_common_params(key='limit', page_size=page_size)
        req_url = urljoin(base_url, URL_DICT.get('app_public_list'))
        if url:
            # 查询公共库流程
            params.update({"types": "img", "in": 'url', "kw": url.lower(), 'exc': True})
        elif name:
            params.update({"types": "img", "in": 'name', "kw": name})
        else:
            params.update({"types": "img"})
    else:
        params = _build_common_params(page_size=page_size)
        req_url = urljoin(base_url, URL_DICT.get('image_list'))
        params['project_id'] = project
        if name:
            params['image_name'] = name
        if url:
            params['image_url'] = url.lower()

    return req_url, params


def get_detail_data(records, name, url, public):
    """匹配详情信息"""
    detail_data = None
    for info in records:
        if public:
            if name:
                if name.upper() == info['name'].upper():
                    return info
            else:
                return info
        else:
            if name and url:
                return info
            elif name:
                if name.upper() == info['image_name'].upper():
                    return info
            else:
                return info

    return detail_data


@click.group(cls=HelpOnInvalidCommand)
def image():
    """镜像管理"""
    pass


@image.command(cls=HelpOnMissingParamCommand)
@click.option('-n', '--name', help="查询指定名称的镜像，支持模糊查询")
@click.option('-u', '--url', help="查询指定URL的镜像")
@click.option('-p', '--public', is_flag=True, help="查询公共库的镜像")
@click.option('-a', '--all', is_flag=True, help="查询所有镜像")
@click.option('-o', '--output',
              help="输出文件路径，指定全路径如data/work/A.txt，则在work目录下生成名为A的文件；指定目录如data/work/，则在work目录下生成系统命名的文件")
@click.pass_context
def ls(ctx, name, url, public, all, output):
    """查询镜像列表"""
    try:
        # 处理output参数
        if isinstance(output, str):
            output = handle_output(output)

        # 构造请求参数
        from yarl import URL
        base_url = str(URL(ctx.obj.get('cloud_url')))
        headers = _build_common_headers(ctx, 'access')
        def _request_data(page_size):
            # 添加查询条件
            project = ctx.obj.get('projectId')
            req_url, params = _build_list_params(project, base_url, public, url, name, page_size=page_size)

            # 查询列表信息
            status, response = _safe_request(req_url, params=params, headers=headers)
            return status, response, req_url, params

        # 构建查询的每页展示的条数
        if all and output:
            init_page_size = MAX_OUTPUT_PAGESIZE
        elif all:
            init_page_size = MAX_DIRECT_PRINT_PAGESIZE
        else:
            init_page_size = 10

        status, response, req_url, params = _request_data(page_size=init_page_size)
        if not status:
            return echo_info(response, MsgStatusTypeEnum.ERROR)

        def callback(response):
            records = filter_records(response['data'], name, url, public)
            # echo_info(_build_image_table(records, public))
            echo_table_info(_build_image_table(records, public))
            echo_debug_info(ctx, req_url, params, headers, records)

        if output:
            # 将数据输出为文件
            records = filter_records(response['data'], name, url, public)
            echo_debug_info(ctx, req_url, params, headers, records)
            table_data = _build_image_table(records, public)
            status, msg = output_file(output, table_data, 'image')
            if status:
                return echo_info(manager_cli.get_msg_info(FILE_GENERATION_SUCCESS) % msg)
            else:
                return echo_info(manager_cli.get_msg_info(FILE_GENERATION_ERROR) % msg, MsgStatusTypeEnum.ERROR)
        else:
            # 渲染数据，并且构建翻页信息
            callback(response)
            total_count = response['data']['total']
            total_page = ceil(total_count / (params['limit'] if public else params['page_size']))
            if all or total_page < 2:
                echo_info(manager_cli.get_msg_info(ECHO_TOTAL_COUNT_SUCCESS) % total_count, MsgStatusTypeEnum.SUCCESS)
                return
            paginate_query(req_url, params, headers, callback, total_page, total_count, params_page_key='page')
    except (EOFError, KeyboardInterrupt, Abort):
        pass
    except Exception:
        echo_exceprtion(ctx)
        echo_info(manager_cli.get_msg_info(QUERY_FAILED_ERROR), MsgStatusTypeEnum.ERROR)


@image.command(cls=HelpOnMissingParamCommand)
@click.option('-n', '--name', help="查询指定名称镜像的详细信息")
@click.option('-u', '--url', help="查询指定URL镜像的详细信息")
@click.option('-p', '--public', is_flag=True, help="查询公共库镜像的详情信息")
@click.pass_context
def info(ctx, name, url, public):
    """查询镜像详细信息"""
    try:
        if not any([name, url]):
            echo_info(manager_cli.get_msg_info(IMAGE_EXEC_INFO_ERROR), MsgStatusTypeEnum.ERROR)
            return click.echo(ctx.get_help())

        # 构造请求参数
        from yarl import URL
        base_url = str(URL(ctx.obj.get('cloud_url')))
        headers = _build_common_headers(ctx, 'access')

        # 增加查询条件
        project = ctx.obj.get('projectId')
        req_list_url, params = _build_list_params(project, base_url, public, url, name)

        # 查询列表信息
        status, response = _safe_request(req_list_url, params=params, headers=headers)
        if not status:
            return echo_info(response, MsgStatusTypeEnum.ERROR)

        # 精准匹配详情信息
        records = filter_records(response['data'], name, url, public)
        if not records:
            return return_info(name, url, public)

        detail_data = get_detail_data(records, name, url, public)
        if not detail_data:
            return return_info(name, url, public)

        # 获取详细信息
        if public:
            req_url = f"{base_url}{URL_DICT.get('image_pubilc_info')}?id={detail_data['oid']}"
        else:
            req_url = f"{base_url}{URL_DICT.get('image_info')}/{detail_data['image_id']}"
        status, response = _safe_request(req_url, params=params, headers=headers)
        if not status:
            return echo_info(response, MsgStatusTypeEnum.ERROR)

        echo_image_describe_table([response['data']], public)

        # 调试信息
        if ctx.obj.get('debug'):
            echo_info(f'req_url: {req_url}')
            echo_info(f'params: {params}')
            echo_info(f'headers: {headers}')
            echo_info(f'Found {1 if response["data"] else 0} matching data entries.')
    except Exception:
        echo_exceprtion(ctx)
        echo_info(manager_cli.get_msg_info(QUERY_FAILED_ERROR), MsgStatusTypeEnum.ERROR)
