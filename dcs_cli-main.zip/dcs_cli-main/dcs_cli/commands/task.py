import json

import click

from dcs_cli.enums import TaskStatusEnum
from dcs_cli.utils import HelpOnInvalidCommand, HelpOnMissingParamCommand


@click.group(cls=HelpOnInvalidCommand)
@click.pass_context
def task(ctx):
    """任务管理"""
    pass


@task.command()
@click.option('-t', '--type', default='w', type=click.Choice(['w', 'a']),
              help='任务类型 w:流程分析任务 a:个性分析离线任务')
@click.option('-u', '--user', help='按创建人查询')
@click.option('-s', '--status', type=click.Choice([i.name for i in TaskStatusEnum]),
              help='任务类型为流程分析任务时，按任务状态查询')
@click.option('-n', '--name', help='按流程名称（type=w）或任务名称（type=a）查询')
@click.option('-i', '--id', help='按任务编号\批次号查询任务列表，多个任务编号用英文逗号分隔')
@click.option('-e', '--entity', help='当运行任务脚本类型为workflow时,按任务实体ID查询任务列表，多个实体ID用英文逗号分隔')
@click.option('--time',
              help='任务类型为流程分析任务时，按任务创建时间查询，格式为【YYYY/mm/dd】、【YYYY/mm/dd~YYYY/mm/dd】、【YYYY/mm/dd~】、【~YYYY/mm/dd】')
@click.option('-a', '--all', is_flag=True, help='查询所有任务')
@click.option('-o', '--output',
              help='输出文件路径，指定全路径如data/work/A.txt,则在work目录下生成名为A的文件，指定目录如data/work/，则在work目录下生成系统命名的文件。')
@click.pass_context
def ls(ctx, type, user, status, name, id, entity, time, all, output):
    """查询项目内的任务列表"""
    from dcs_cli.enums import TaskTypeEnum
    from dcs_cli.utils import process_exist_option

    projectId = ctx.obj.get('projectId')

    if type == TaskTypeEnum.workflow.value:  # 流程分析任务
        from dcs_cli.apis import get_task_api
        if all:
            params = {'page': 1, 'limit': 2000}
        else:
            params = {'page': 1, 'limit': 10}
        payload = {'projectId': projectId}
        process_exist_option(payload, user, 'createUsername')
        process_exist_option(payload, status, 'status')
        process_exist_option(payload, name, 'wfName')
        process_exist_option(payload, id, 'keyword')
        process_exist_option(payload, entity, 'sampleId')
        if time:
            time = time.split('~')
            if len(time) == 1:
                startTime = endTime = time[0]
            elif len(time) == 2:
                startTime, endTime = time
            else:
                raise click.BadParameter('--time参数格式错误')
            process_exist_option(payload, startTime, 'startTime')
            process_exist_option(payload, endTime, 'endTime')
        echo_scTask_response(ctx, get_task_api, params, payload, all=all, output=output)
    elif type == TaskTypeEnum.analysis.value:  # 个性分析离线任务
        from dcs_cli.utils import make_request
        from dcs_cli.apis import get_offline_api
        if status:
            raise click.UsageError('-t/--type a和-s/--status不能同时使用')
        if entity:
            raise click.UsageError('-t/--type a和-e/--entity不能同时使用')
        if time:
            raise click.UsageError('-t/--type a和--time不能同时使用')

        params = {'pageNo': 1, 'pageSize': 10, 'subTask': 0, 'projectId': projectId, 'taskId': id}
        process_exist_option(params, user, 'tpuse')
        process_exist_option(params, name, 'taskName')
        process_exist_option(params, id, 'taskId')
        if all:
            params['pageSize'] = 2000

        response = make_request(ctx, 'GET', get_offline_api, params=params)
        if response.get('result') and response['result']['records']:  # 先查父任务
            echo_note_response(ctx, get_offline_api, params, all=all, output=output)
        else:  # 再查子任务
            params['subTask'] = 1
            echo_note_subtask_response(ctx, get_offline_api, params, all=all, output=output)


@task.command(
    context_settings=dict(terminal_width=200),
    epilog="""
    使用-j投递workflow任务：dcs task run -n Hellodemo -j /data/work/sdk_v8_test.json -o /Files/V8test1

    使用-i投递workflow任务：dcs task run -n Hellodemo -e C04138G3 -i Fastqs_file=[[\\"/Files/SN1_read1.fq.gz\\",\\"/Files/SN1_read2.fq.gz\\"],[\\"/Files/SN2_read1.fq.gz\\",\\"/Files/SN2_read2.fq.gz\\"]] -i Image_file=/Files/C04138G3/image/C04138G3.tar.gz -i Mem=90

    使用--table投递workflow任务：dcs task run -n Hellodemo -v 1.1.3 --table /data/work/Hellodemo.xlsx

    使用-i投递shell脚本：dcs task run --type s -i "sh /data/work/test.sh" -l vf=32g,num_proc=8 --image "stereonote/stereonote_conda_jupyterhub:latest" --output /Files/test0408 -m "/Files/gef/test3_NC.tissue16.gef,/Files/gef/test3_NC.tissue17.gef"

    使用-i投递GPU shell脚本：dcs task run --type s -i /data/work/test.sh -l vf=320g,num_proc=88,gpu=L4 --image "stereonote/stereonote_conda_jupyterhub:latest" --output /Files/test-gpu -m "/Files/gef/test3_NC.tissue16.gef,/Files/gef/test3_NC.tissue17.gef"

    使用-p批量投递shell脚本：dcs task run -t s -p /data/work/test2.sh -l vf=32g,num_proc=8 --image "stereonote/stereonote_conda_jupyterhub:latest" --output /Files/hxx0402 -m "/Files/gef/test3_NC.tissue16.gef,/Files/gef/test3_NC.tissue17.gef"
    
    """
)
@click.option('-t', '--type', default='w', type=click.Choice(['w', 's']),
              help='任务类型 w:流程分析任务 s:个性分析离线任务')
@click.option('-e', '--entity', help='实体ID，任务类型为w时必填，s时不填')
@click.option('-i', '--input', multiple=True,
              help='指定运行任务的输入,当脚本类型为w时，以键值对“parameter=value”传入参数取值，当脚本类型为s时，传入需要执行的命令，如-i=sh data/work test.sh')
@click.option('-j', '--json', 'json_file', help='''当运行workflow任务时，通过传入json指定运行任务的输入参数，json中需包含实体id、参数取值键值对，如
{"entirtyId-1":{"input_field1":"value1","input_field2":"value2"},"entityId-2":{"input_field1":"value1","input_field2":"value2"}}
''')
@click.option('--table', 'table_file',
              help='通过传入表格指定运行任务的输入参数，支持.csv .xlsx，表格表头需要与参数值对应，数组参数填写时需以json形式写入，如[["/Files/SN1_read1.fq.gz","/Files/SN1_read2.fq.gz"],["/Files/SN2_read1.fq.gz","/Files/SN2_read2.fq.gz"]]')
@click.option('-v', '--version', help='当运行务脚本类型为workflow时，指定运行流程的版本')
@click.option('-n', '--name',
              help='当运行任务脚本类型为shell时，指定任务名称；当运行任务脚本类型为workflow时，指定流程名称')
@click.option('-p', '--path', help='离线任务批量投递时，运行指定路径下文件内容，文件中每行命令生成一条任务')
@click.option('-l',
              help='当运行任务脚本类型为shell时，指定申请资源，CPU型【vf=*g,num_proc=*】，GPU型【vf=*g,num_proc=*,gpu=L4/T4...(指定gpu类型)】')
@click.option('--image', help='当运行任务脚本类型为shell时，指定镜像资源，需填写云平台镜像库中url路径')
@click.option('-o', '--output', help='指定任务输出到数据管理的路径')
@click.option('-m', '--mount',
              help='当运行任务脚本类型为shell时，指定分析任务时挂载的数据，使用数据管理的文件路径，多个文件按逗号分隔')
@click.pass_context
def run(ctx, type, entity, input, json_file, table_file, version, name, path, l, image, output, mount):
    """运行任务"""
    import datetime
    from pathlib import Path

    from requests import Session

    from dcs_cli.enums import TaskTypeEnum
    from dcs_cli.utils import make_request

    projectId = ctx.obj.get('projectId')
    zone = ctx.obj.get('zone')
    workspace_id = ctx.obj.get('workspace_id')
    session = Session()

    if output:
        if not output.startswith('/Files/'):
            raise click.ClickException('路径无效，输入/Files/...格式路径')

    if type == TaskTypeEnum.workflow.value:  # 流程分析
        from dcs_cli.utils import sap_hooks
        from dcs_cli.apis import get_billing_api, get_workflow_api, get_expense_api, save_workflow_api

        # 校验余额
        params = {'projectCode': projectId, 'type': 3}
        response = make_request(ctx, 'GET', get_billing_api, params=params, session=session)
        balance = float(response['data'][0]['billing']['balance'])
        if balance <= 0:
            raise click.ClickException('余额不足，操作失败')

        # 解析输入参数
        inputs = {}  # 批量输入参数，{'entity': {输入参数}}
        if input:  # -i/--input的形式，tuple转dict
            d = {}
            for i in input:
                try:
                    key, value = i.split('=')
                except:
                    raise click.BadParameter('参数格式应为 key=value')
                try:
                    value = json.loads(value)
                except json.JSONDecodeError:
                    pass
                d[key] = value
            inputs[entity] = d
        elif json_file:  # --json的形式，读进dict
            try:
                with open(json_file, 'r', encoding='utf-8') as f:
                    inputs = json.load(f)
                    entity = list(inputs.keys())
            except:
                raise click.FileError('不支持该格式JSON文件')
        elif table_file:  # --table的形式，读进dict
            if table_file.endswith('.csv'):
                import csv
                with open(table_file, 'r', newline='', encoding='utf-8') as f:
                    reader = csv.reader(f)
                    rows = list(reader)
                    first_row, rest_rows = rows[0], rows[1:]
            elif table_file.endswith('.tsv'):
                import csv
                with open(table_file, 'r', newline='', encoding='utf-8') as f:
                    reader = csv.reader(f, delimiter='\t')
                    rows = list(reader)
                    first_row, rest_rows = rows[0], rows[1:]
            elif table_file.endswith('.xlsx'):
                from openpyxl import load_workbook
                wb = load_workbook(table_file)
                ws = wb.active
                rows = [[j.value for j in i] for i in ws.rows]
                first_row, rest_rows = rows[0], rows[1:]
            else:
                raise click.FileError('不支持该格式表格文件')

            # 解析表格
            entitys = []
            for row in rest_rows:
                d = {}
                for i, value in enumerate(row):
                    if i == 0:
                        entity = value
                        entitys.append(entity)
                        if not entity:  # 跳过EntityID为空的行
                            continue
                    else:
                        if isinstance(value, str):
                            if value.lower() in {'true', 'false'}:
                                value = value.lower()
                        key = first_row[i]  # 参数名
                        try:
                            value = json.loads(value)
                        except Exception:
                            pass
                        d[key] = value
                if not entity:  # 跳过EntityID为空的行
                    continue
                inputs[entity] = d
            entity = entitys[0] if entitys else None
        else:
            click.echo(ctx.get_help())
            return

        # 基础校验
        if not name:
            click.echo(click.style('Missing parameter: -n/--name', fg='red'))
            click.echo(ctx.get_help())
            return
        if not entity:
            click.echo(click.style('Missing parameter: -e/--entity', fg='red'))
            click.echo(ctx.get_help())
            return

        # 获取项目工作流
        params = {'project': projectId, 'workflow_name': name}
        if version:
            params['version'] = version
        response = make_request(ctx, 'GET', get_workflow_api, params=params, session=session)
        if not response:
            raise ValueError('{} {} {}'.format(projectId, name, 'does not exist'))
        if response.get('message'):
            raise click.ClickException(response['message'])
        workflow_dict = response

        # 校验收费流程时余额需大于一次运行价格
        if workflow_dict.get('billing_type') in (40101, 40102):  # 收费流程
            params = {
                'vendor': 'aliyun',
                'detail.tags': workflow_dict['origin_id'],
                'types': '40101,40102',
                'needDiscountInfo': True
            }
            response = make_request(ctx, 'GET', get_expense_api, params=params, session=session)
            if response.get('data'):
                price = float(response['data'][0]['price'])
                if price > balance:
                    raise click.ClickException('余额不足，操作失败')

        # 是否满足工作流输入的必填参数
        output = output.rstrip('/') if output else '/Files/ResultData/Workflow'
        analyseParams = []
        for entity, input in inputs.items():
            rule_inputs = workflow_dict['inputs']
            for key, rule in rule_inputs.items():
                rule_key = key.split('.')[1]
                if not '(optional)' in rule:  # 必填required
                    if rule_key not in input:
                        raise click.ClickException('必填参数{}'.format(rule_key))
                    if 'String' in rule:  # 转字符串
                        input[rule_key] = str(input[rule_key])

            # 用户输入的参数是否在工作流输入列表里
            exist_keys = {i.split('.')[1]: i for i in rule_inputs.keys()}
            for key, value in input.items():
                if key not in exist_keys:
                    raise click.ClickException('参数非法{}'.format(key))

            final_input = {}
            for key, value in input.items():
                key = exist_keys[key]
                final_input[key] = value

            analyseParam = {
                'entityId': entity,
                'tableRowCount': 1,
                'wfName': workflow_dict['workflowname'],
                'wfVersion': workflow_dict['version'],
                'wfTag': workflow_dict['official_tag'],
                'wfType': '2',
                'inputs': final_input,
                'outputDir': '{}/[taskId]'.format(output.rstrip('/')),
                'workflowTaskType': 'workflow',
            }
            analyseParams.append(analyseParam)

        payload = {
            'projectId': projectId,
            'wfId': workflow_dict['workflowid'],
            'workflowTaskType': 'workflow',
            'batchType': 1,
            'analyseParams': analyseParams,
            'wfName': workflow_dict['workflowname'],
            'wfVersion': workflow_dict['version'],
            'wfTag': workflow_dict['official_tag'],
            'wfType': '2',
        }

        response = make_request(ctx, 'POST', save_workflow_api, json=payload, session=session, hooks=sap_hooks)
        click.echo(response['data'])

    elif type == TaskTypeEnum.shell.value:  # 个性分析离线任务
        from dcs_cli.utils import workflow_hooks
        from dcs_cli.enums import NotebookSettingEnum
        from dcs_cli.apis import get_metadata_api, get_project_api, get_resource_api, save_offline_api

        def encrypt(message, passphrase=b'stereonote'):
            import base64
            from Crypto import Random
            from Crypto.Cipher import AES
            BLOCK_SIZE = 16

            def bytes_to_key(data, salt, output=48):
                from hashlib import md5
                assert len(salt) == 8, len(salt)
                data += salt
                key = md5(data).digest()
                final_key = key
                while len(final_key) < output:
                    key = md5(key + data).digest()
                    final_key += key
                return final_key[:output]

            def pad(data):
                length = BLOCK_SIZE - (len(data) % BLOCK_SIZE)
                return data + (chr(length) * length).encode()

            salt = Random.new().read(8)
            key_iv = bytes_to_key(passphrase, salt, 32 + 16)
            key = key_iv[:32]
            iv = key_iv[32:]
            aes = AES.new(key, AES.MODE_CBC, iv)
            return base64.b64encode(b'Salted__' + salt + aes.encrypt(pad(message))).decode()

        # 基础校验
        if input and path:
            raise click.UsageError('-i/--input和-p/--path不能同时使用')
        if not l:
            raise click.UsageError('-l必填')
        if not image:
            raise click.UsageError('--image必填')
        if path:
            path = Path(path)
            if not path.exists():
                raise click.ClickException('{} 文件不存在'.format(path))
            with path.open('r', encoding='utf-8') as f:
                input = f.read().splitlines()

        # 脚本加密
        shells = [encrypt(i.encode()) for i in input]

        # 获取项目信息
        params = {'code': projectId}
        response = make_request(ctx, 'GET', get_project_api, params=params, session=session)
        projectName = response['data']['name']

        # 解析计算资源
        d = {}
        for i in l.split(','):
            if '=' in i:
                key, value = i.split('=')
                d[key] = value

        cpu = d.get('num_proc')
        mem = d.get('vf', '').rstrip('g')
        gpu = d.get('gpu')
        computingNameTemp = '{}c {}g'.format(cpu, mem)

        if gpu:
            computingNameTemp = '{}*1 '.format(gpu) + computingNameTemp
            resource_type = '7'
        else:
            resource_type = '6'

        # 获取计算资源
        params = {'search_type': '2', 'resource_type': resource_type, 'task_type': 'offline'}
        response = make_request(ctx, 'GET', get_resource_api, params=params, session=session)
        resource_id = None
        for i in response['data']:
            if computingNameTemp == i['model_value']:
                resource_id = i['id']
                break
        if not resource_id:
            message = '匹配不到计算资源 {}'.format(l)
            message += '\n可选择以下机型：\n{}'.format('\n'.join([i['model_value'] for i in response['data']]))
            raise click.ClickException(message)

        output = output if output else '/Files/ResultData/Notebook'
        payload = {
            'taskName': name if name else '{}-{}'.format(projectName, datetime.datetime.now().strftime('%Y%m%d%H%M%S')),
            'taskType': '2',
            'shells': shells,
            'workspaceId': workspace_id,
            'seting': NotebookSettingEnum.NO.value,
            'csFileNmme': '',  # 参数文件配置时的文件名
            'fileParams': [],  # 任务类型为Notebook时才传
            'resource_type': resource_type,  # 计算资源为ALL
            'resource_id': resource_id,  # 计算资源第二个下拉框的第一个选项
            'projectId': projectId,
            'projectName': projectName,
            'imageId': image,
            'computingNameTemp': computingNameTemp,
            'virtualPath': output,
        }

        # 挂载
        if mount:
            mount = mount.split(',')
            not_exist_mount = set(mount)
            menuPathList = set()
            searchNameList = set()
            for path in mount:
                menuPath, searchName = path.rsplit('/', maxsplit=1)
                menuPathList.add(menuPath)
                searchNameList.add(searchName)
            subnet = ctx.obj.get('subnet')
            _payload = {'projectId': projectId, 'zone': zone, 'subnet': subnet, 'menuPathList': list(menuPathList),
                        'searchNameList': list(searchNameList)}
            if subnet == 'dmz':
                _payload['downloadType'] = '0'
            response = make_request(ctx, 'POST', get_metadata_api, json=_payload, session=session)

            mountList = []
            if response.get('data'):
                for i in response['data']['records']:
                    path = i['menuPath'] + '/' + i['searchName']
                    if path in mount:
                        not_exist_mount.remove(path)
                        mountList.append({
                            'id': i.get('id', ''), 'dataType': i.get('dataType', ''),
                            'taskId': i.get('taskId', ''), 'projectId': i.get('projectId', ''),
                            'name': i.get('name', ''), 'menuPath': i.get('menuPath', ''),
                            'resultPath': i.get('path', ''), 'wfName': i.get('wfName', '')
                        })
                payload['mountList'] = mountList

            if not_exist_mount:
                for i in not_exist_mount:
                    click.echo('不存在' + i)
                while True:
                    click.echo('是否继续投递？继续y 退出q', nl=False)
                    c = click.getchar()
                    click.echo()
                    if c == 'y':  # 继续
                        break
                    elif c == 'q':  # 退出
                        raise click.ClickException('{} 文件不存在'.format(' '.join(not_exist_mount)))

        # 模拟页面/offline/save的参数去调/dcs/task/run
        response = make_request(ctx, 'POST', save_offline_api, json=payload, session=session,
                                hooks=workflow_hooks)
        if response['code']:
            raise click.ClickException(response['msg'])
        else:
            click.echo(response['data']['taskId'])


@task.command(cls=HelpOnMissingParamCommand)
@click.argument('id')
@click.pass_context
def info(ctx, id):
    """查看任务的详细信息"""
    from pathlib import Path

    from requests import Session

    from dcs_cli.utils import make_request
    from dcs_cli.apis import task_detail_api, task_ouput_api

    projectId = ctx.obj.get('projectId')

    session = Session()

    # 先查流程分析任务
    params = {'taskId': id}
    response = make_request(ctx, 'GET', task_detail_api, params=params, session=session)
    if response.get('data'):  # 流程分析任务
        from tabulate import tabulate

        # 投递信息
        analysis_time = time_difference(response['data']['createTime'], response['data']['taskFinishTime']) if \
            response['data'].get('taskFinishTime') else ''
        click.echo('任务编号：' + response['data']['taskId'])
        try:
            status = TaskStatusEnum[response['data']['status']].value
        except:
            status = response['data']['status']
        click.echo('任务状态：' + status)
        click.echo('流程名称：' + response['data'].get('wfName', ''))
        click.echo('创建人：' + response['data'].get('createUsername', ''))
        click.echo('分析时长：' + analysis_time)
        click.echo('实体ID：' + response['data'].get('sampleId', ''))
        click.echo('创建时间：' + (response['data'].get('createTime', '')))
        click.echo('完成时间：' + (response['data'].get('taskFinishTime', '')))
        click.echo('费用：' + ('¥' + response['data']['expense'] if response['data'].get('expense') else ''))
        click.echo('备注：' + (response['data'].get('memo', '')))

        # 输入
        inputs = response['data']['taskDetail']
        if inputs.get('req'):
            inputs = inputs['req']
            if inputs.get('wfWorkflow'):
                inputs = inputs['wfWorkflow']['inputs']
                inputs_value_dict = response['data']['taskDetail']['req']['analyseParam']['inputs']
                field_names = ['变量名', '类型', '取值']
                tabular_data = []
                for key, value in inputs.items():
                    variable_name = key.split('.')[1]
                    type = value.replace('?', '').split(' ')[0]
                    value = inputs_value_dict[key] if inputs_value_dict.get(key) else '-'
                    tabular_data.append([variable_name, type, value])
                click.echo('输入：')
                click.echo(tabulate(tabular_data, field_names, tablefmt='plain'))

        # 输出
        params = {'taskId': id}
        response = make_request(ctx, 'GET', task_ouput_api, params=params, session=session)
        if response.get('data'):
            field_names = ['输出文件信息', '文件名称']
            tabular_data = []
            for i in response['data']:
                path = Path(i['name'])
                if '/' in i['name']:
                    first = i['name'].split('/')[0].split('_')[0]
                else:
                    if i.get('fileExtension'):
                        first = i['fileExtension']
                    else:
                        if path.suffix:
                            first = path.suffix.split('.')[1]
                        else:
                            first = i['name']
                tabular_data.append([first, path.name])
            click.echo('输出：')
            click.echo(tabulate(tabular_data, field_names, tablefmt='plain'))
    else:  # 再查个性分析离线任务
        from dcs_cli.apis import get_offline_api, offline_content_api
        # 先查父任务
        params = {'pageSize': 10, 'pageNo': 1, 'subTask': '0', 'projectId': projectId, 'taskId': id}
        response = make_request(ctx, 'GET', get_offline_api, params=params, session=session)
        if response.get('result') and response['result']['records']:
            params['subTask'] = '1'
            params['parentId'] = id
            del params['taskId']
            echo_note_subtask_response(ctx, get_offline_api, params)
        else:  # 再查子任务
            api = f'stereonote/api/dcs/offline/subTask/get/{id}'  # 罗赤锋
            response = make_request(ctx, 'GET', api, session=session)
            if response.get('result'):
                resultPath = response['result']['resultPath']

                if resultPath:
                    params = {'path': resultPath}
                    response = make_request(ctx, 'GET', offline_content_api, params=params, session=session)
                    if response.get('data'):
                        from rich.console import Console
                        from rich.markdown import Markdown
                        console = Console()
                        for i in response['data']['cells']:
                            for j in i['source']:
                                if i['cell_type'] == 'markdown':
                                    console.print(Markdown(j), soft_wrap=True, highlight=True)
                                elif i['cell_type'] == 'code':
                                    j = '```python\n' + j
                                    console.print(Markdown(j), soft_wrap=True, highlight=True)
                                else:
                                    console.print(j, soft_wrap=True, highlight=True)

                            if i.get('outputs'):  # 显示输出
                                for k in i['outputs']:
                                    if k.get('text'):
                                        for text in k['text']:
                                            console.print(text)


@task.command(cls=HelpOnMissingParamCommand)
@click.argument('id')
@click.option('-n', '--name',
              help='查询指定步骤名称的输出日志，与--stdout/--stderr/--script一同使用，多线程时输入name-线程数')
@click.option('--stdout', is_flag=True, help='当任务类型为workflow时，查询指定步骤的stdout文件')
@click.option('--stderr', is_flag=True, help='当任务类型为workflow时，查询指定步骤的stderr文件')
@click.option('--script', is_flag=True, help='当任务类型为workflow时，查询指定步骤的script文件，仅任务投递者本人可查看')
@click.option('-i', '--intermediate', is_flag=True, help='当任务类型为workflow时，查询指定步骤的中间文件')
@click.pass_context
def log(ctx, id, name, stdout, stderr, script, intermediate):
    """查询任务的运行日志"""
    from requests import Session

    from dcs_cli.utils import make_request
    from dcs_cli.apis import task_detail_api, job_step_api, job_step_output_api, job_intermediate_api

    projectId = ctx.obj.get('projectId')
    session = Session()

    # 先查流程分析任务
    params = {'taskId': id}
    response = make_request(ctx, 'GET', task_detail_api, params=params, session=session)
    if response.get('data'):  # 流程分析任务
        from rich.console import Console
        from dcs_cli.utils import sap_hooks

        # 基础校验
        if not name:
            click.echo(click.style('Missing parameter: -n/--name', fg='red'))
            click.echo(ctx.get_help())
            return
        if '-' in name:
            name, index = name.split('-')
            try:
                index = int(index) - 1
            except:
                raise click.ClickException('指定线程数有误')
        else:
            raise click.ClickException('未指定线程数')

        sid = response['data'].get('sid')
        if not sid:
            raise click.ClickException('暂无数据')
        createBy = response['data']['createBy']

        params = {'sid': sid}
        response = make_request(ctx, 'POST', job_step_api, params=params, session=session, hooks=sap_hooks)
        if response.get('msg') not in ('成功', 'Success'):
            raise click.ClickException(response['msg'])

        def get_keyendswith_value(d, s, index, key):
            """获取字典键名以s结尾的索引为index的key值"""
            for step_name, value in d.items():
                if step_name.endswith(s):
                    _range = range(len(value))
                    if index not in _range:
                        raise click.ClickException(
                            '{}的线程数取值范围为{}'.format(step_name, ' '.join([str(i + 1) for i in _range])))
                    return value[index][key]

        console = Console()
        if stdout:
            path = get_keyendswith_value(response['data'], name, index, 'stdout')
            params = {'path': path, 'logtype': 'stdout', 'page': '1', 'limit': '2000'}
            response = make_request(ctx, 'POST', job_step_output_api, params=params, session=session, hooks=sap_hooks)
            if response.get('msg') not in ('成功', 'Success'):
                raise click.ClickException(response['msg'])
            click.echo(response['data']['data'])
        elif stderr:
            path = get_keyendswith_value(response['data'], name, index, 'stderr')
            params = {'path': path, 'logtype': 'stderr', 'page': '1', 'limit': '2000'}
            response = make_request(ctx, 'POST', job_step_output_api, params=params, session=session, hooks=sap_hooks)
            if response.get('msg') not in ('成功', 'Success'):
                raise click.ClickException(response['msg'])
            click.echo(response['data']['data'])
        elif script:
            user_info = ctx.obj.get('user_info')
            if createBy != user_info['sub']:
                raise click.ClickException('仅任务投递者本人可查看')

            path = get_keyendswith_value(response['data'], name, index, 'stdout')
            path = path.replace('stdout', 'script')
            params = {'path': path, 'logtype': 'script', 'page': '1', 'limit': '2000'}
            response = make_request(ctx, 'POST', job_step_output_api, params=params, session=session, hooks=sap_hooks)
            if response.get('msg') not in ('成功', 'Success'):
                raise click.ClickException(response['msg'])
            click.echo(response['data']['data'])
        elif intermediate:
            path = get_keyendswith_value(response['data'], name, index, 'stdout')
            path = path.replace('stdout', '')
            params = {'path': path}
            response = make_request(ctx, 'POST', job_intermediate_api, params=params, session=session, hooks=sap_hooks)
            if response.get('msg') not in ('成功', 'Success'):
                raise click.ClickException(response['msg'])
            if response.get('data'):
                from rich.table import Table
                from rich.style import Style

                from dcs_cli.utils import bytes_to_human_readable

                table = Table()
                blue_style = Style(color='blue')
                for i in ['文件名称', '文件大小']:
                    table.add_column(i)

                hideFileList = {
                    'script', 'script.check', 'script.submit', 'script.yaml', 'rc', 'stderr', 'stderr.check',
                    'stderr.qsub', 'stderr.submit', 'stdout', 'stdout.submit', 'stdout.check',
                    'biocomputing_tat_info', 'biocomputing_stat_info'
                }
                for i in response['data']:
                    if i['fileName'] not in hideFileList:
                        if i['isDirectory']:
                            i['fileName'] = blue_style.render(i['fileName'])
                        table.add_row(i['fileName'], bytes_to_human_readable(i['fileSize']))
                console.print(table)
            else:
                click.echo('您的中间结果文件不存在，可能暂未产生数据或数据已被删除。')

        else:
            import datetime

            from rich.table import Table
            from dcs_cli.enums import WorkflowExecutionStatus

            if not response.get('data'):
                raise click.ClickException('暂无数据')
            table = Table()
            for i in ['步骤', '状态', '核时(H)', '最大内存(GB)', '', '', '', '', '', '']:
                table.add_column(i)

            length = len(response['data'])
            for index, (key, value) in enumerate(
                    sorted(
                        response['data'].items(),
                        key=lambda x: datetime.datetime.fromisoformat(x[1][0].get('submittime', '9999-12-31 23:59:59'))
                    )
            ):
                status = WorkflowExecutionStatus[value[0]['executionStatus']].value if value[0].get(
                    'executionStatus') else '-'
                table.add_row(
                    key.split('.')[1],
                    status,
                    '{:.4f}'.format(value[0]['cpu']) if value[0].get('cpu') else '0',
                    '{:.4f}'.format(value[0]['maxmem']) if value[0].get('maxmem') else '0',
                )
                table.add_row('#', '状态', '开始时间', '完成时间', '总耗时(H)', '核时(H)', '设置内存(GB)',
                              '最大内存(GB)',
                              'IO(GB)', '线程效率(%)')

                for i, x in enumerate(value):
                    if x.get('cpuavg'):
                        thread_efficiency = '{:.4f}'.format(float(x['cpuavg']))
                    elif x.get('cpu') and x.get('elapsedtime') and x.get('proc'):
                        thread_efficiency = '{:.4f}'.format(x['cpu'] / x['elapsedtime'] / x['proc'] * 100)
                    else:
                        thread_efficiency = '-'
                    status = WorkflowExecutionStatus[x['executionStatus']].value if x.get('executionStatus') else '-'
                    table.add_row(
                        str(i + 1),
                        status,
                        x['starttime'] if x.get('starttime') else '-',
                        x['finishtime'] if x.get('finishtime') else '-',
                        '{:.4f}'.format(x['elapsedtime']) if x.get('elapsedtime') else '-',
                        '{:.4f}'.format(x['cpu']) if x.get('cpu') else '0',
                        '{:.4f}'.format(x['virt']) if x.get('virt') else '0',
                        '{:.4f}'.format(x['maxmem']) if x.get('maxmem') else '0',
                        '{:.4f}'.format(x['io']) if x.get('io') else '0',
                        thread_efficiency
                    )

                if index <= length - 2:
                    table.add_row()

            console.print(table)

    else:  # 再查个性分析离线任务
        api = f'stereonote/api/dcs/task/logs/{id}'  # 罗赤锋
        payload = {'projectId': projectId}
        response = make_request(ctx, 'POST', api, json=payload, session=session)
        if response.get('message') and response.get('code') != 500:
            click.echo(response['message'])


@task.command(cls=HelpOnMissingParamCommand)
@click.argument('id')
@click.pass_context
def consume(ctx, id):
    """当任务类型为离线任务时，查询指定任务的资源消耗"""
    import datetime

    import plotext as plt
    from requests import Session

    from dcs_cli.utils import make_request

    session = Session()
    for metric in ['cpu', 'memory']:
        api = f'stereonote/api/dcs/offline/subTask/{metric}Info/{id}'  # 罗赤锋
        response = make_request(ctx, 'POST', api, session=session)
        if response.get('data'):
            x = []
            x_labels = []
            y = []
            for i in response['data']['values']:
                x.append(float(i[0]))
                x_labels.append(datetime.datetime.fromtimestamp(i[0]).strftime('%Y-%m-%d %H:%M'))
                y.append(float(i[1]))
            if float('inf') in y:  # 将inf替换成第二大的值
                second_max = sorted(set(y), reverse=True)[1]
                y = [i if i != float('inf') else second_max for i in y]
            plt.theme('clear')
            plt.plot(x, y, color='blue', marker='*')
            if metric == 'cpu':
                title = 'CPU'
            elif metric == 'memory':
                title = '内存'
            else:
                title = ''
            plt.title(title)
            plt.xlabel('时间')
            plt.ylabel('%')
            plt.xticks(x, x_labels)
            plt.show()
            plt.clf()


@task.command(cls=HelpOnMissingParamCommand)
@click.argument('id')
@click.pass_context
def start(ctx, id):
    """启动指定任务，批量启动逗号隔开"""
    from dcs_cli.utils import make_request

    projectId = ctx.obj.get('projectId')

    ids = id.split(',')

    workflow_ids, offline_ids = get_workflow_offline_ids(ctx, ids)

    if workflow_ids:
        from dcs_cli.utils import sap_hooks
        from dcs_cli.apis import start_task_api

        payload = {'projectId': projectId, 'taskIds': workflow_ids}
        response = make_request(ctx, 'POST', start_task_api, json=payload, hooks=sap_hooks)
        if response.get('data'):
            success = set(workflow_ids) - set(i['taskId'] for i in response['data']['unmatched'])
            click.echo('成功操作{}个任务 {}'.format(response['data']['count'], ' '.join(success)))
            if len(response['data']['unmatched']):
                click.echo('失败操作{}个任务'.format(len(response['data']['unmatched'])))
                for i in response['data']['unmatched']:
                    click.echo('{} {}'.format(i['taskId'], i['msg']))

    if offline_ids:
        from dcs_cli.utils import stereonote_hooks
        from dcs_cli.apis import resume_offline_api
        payload = {'sub_task_id': id}
        response = make_request(ctx, 'POST', resume_offline_api, json=payload, hooks=stereonote_hooks)
        if response.get('msg'):
            click.echo('{} {}'.format(id, response['msg']))


@task.command(cls=HelpOnMissingParamCommand)
@click.argument('id')
@click.pass_context
def cancel(ctx, id):
    """取消指定任务，批量取消逗号隔开"""
    from dcs_cli.utils import make_request

    projectId = ctx.obj.get('projectId')

    ids = id.split(',')

    workflow_ids, offline_ids = get_workflow_offline_ids(ctx, ids)

    if workflow_ids:
        from dcs_cli.utils import sap_hooks
        from dcs_cli.apis import cancel_task_api

        payload = {'projectId': projectId, 'taskIds': workflow_ids}
        response = make_request(ctx, 'POST', cancel_task_api, json=payload, hooks=sap_hooks)
        if response.get('data'):
            success = set(workflow_ids) - set(i['taskId'] for i in response['data']['unmatched'])
            click.echo('成功操作{}个任务 {}'.format(response['data']['count'], ' '.join(success)))
            if len(response['data']['unmatched']):
                click.echo('失败操作{}个任务'.format(len(response['data']['unmatched'])))
                for i in response['data']['unmatched']:
                    click.echo('{} {}'.format(i['taskId'], i['msg']))

    if offline_ids:
        from dcs_cli.utils import stereonote_hooks
        from dcs_cli.apis import cancel_offline_api

        # 要取消子任务ID，且生成任务后要稍微等个几分钟
        payload = {'projectId': projectId, 'taskIds': ','.join(offline_ids)}
        response = make_request(ctx, 'POST', cancel_offline_api, json=payload, hooks=stereonote_hooks)
        successList = response['successList']
        failList = response['failList']
        if successList:
            click.echo('成功操作{}个任务 {}'.format(len(successList), ' '.join(successList)))
        if failList:
            click.echo('失败操作{}个任务 {}'.format(len(failList), ' '.join(i.get('taskId') for i in failList)))


@task.command(cls=HelpOnMissingParamCommand)
@click.argument('id')
@click.pass_context
def rm(ctx, id):
    """删除指定任务，批量删除逗号隔开"""
    from dcs_cli.utils import make_request

    projectId = ctx.obj.get('projectId')

    ids = id.split(',')

    workflow_ids, offline_ids = get_workflow_offline_ids(ctx, ids)

    if workflow_ids:
        from dcs_cli.utils import sap_hooks
        from dcs_cli.apis import delete_task_api

        payload = {'projectId': projectId, 'taskIds': workflow_ids}
        response = make_request(ctx, 'POST', delete_task_api, json=payload, hooks=sap_hooks)
        if response.get('data'):
            success = set(workflow_ids) - set(i['taskId'] for i in response['data']['unmatched'])
            click.echo('成功操作{}个任务 {}'.format(response['data']['count'], ' '.join(success)))
            if len(response['data']['unmatched']):
                click.echo('失败操作{}个任务'.format(len(response['data']['unmatched'])))
                for i in response['data']['unmatched']:
                    click.echo('{} {}'.format(i['taskId'], i['msg']))

    if offline_ids:
        from dcs_cli.utils import stereonote_hooks
        from dcs_cli.apis import delete_offline_api
        payload = {'projectId': projectId, 'taskIds': ','.join(offline_ids)}
        response = make_request(ctx, 'POST', delete_offline_api, json=payload, hooks=stereonote_hooks)
        successList = response['successList']
        failList = response['failList']
        if successList:
            click.echo('成功操作{}个任务 {}'.format(len(successList), ' '.join(successList)))
        if failList:
            click.echo('失败操作{}个任务 {}'.format(len(failList), ' '.join(i.get('taskId') for i in failList)))


def time_difference(start_time_str, end_time_str):
    """计算两个时间字符串之间的时间差

    :param start_time_str: 开始时间字符串，格式为 'YYYY-MM-DD HH:MM:SS'
    :param end_time_str: 结束时间字符串，格式为 'YYYY-MM-DD HH:MM:SS'
    :return: 格式化后的时间差，如'9h 59m 58s'
    """
    import datetime
    time_format = '%Y-%m-%d %H:%M:%S'
    start_time = datetime.datetime.strptime(start_time_str, time_format)
    end_time = datetime.datetime.strptime(end_time_str, time_format)
    delta = end_time - start_time
    total_seconds = int(delta.total_seconds())  # 总秒数
    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60
    return f'{hours}h {minutes}m {seconds}s'


def echo_scTask_response(ctx, api, params, payload, all=False, output=False):
    """请求并输出流程分析任务接口的数据

    :param ctx: 上下文
    :param api: 请求的API地址
    :param params: Query参数
    :param payload: JSON参数
    :param all: 查询所有数据
    :param output: 输出文件路径
    """
    from tabulate import tabulate

    from dcs_cli.utils import paginated_request, create_output

    def callback(response):
        field_names = ['任务编号', '实体ID', '任务状态', '费用', '流程名称', '版本号', '创建人', '创建时间', '总时长',
                       '完成时间', '备注']
        tabular_data = []
        for i in response['data']['records']:
            try:
                duration = time_difference(i['createTime'], i['taskFinishTime'])
            except:
                duration = '-'
            status = TaskStatusEnum[i['status']].value if i.get('status') in TaskStatusEnum.__members__ else i.get(
                'status', '-')
            tabular_data.append([
                i['taskId'],
                i['sampleId'] if i.get('sampleId') else '-',
                status,
                i['expense'] if i.get('expense') else '-',
                i['wfName'] if i.get('wfName') else '-',
                i['wfVersion'] if i.get('wfVersion') else '-',
                i['createUsername'] if i.get('createUsername') else '-',
                i['createTime'] if i.get('createTime') else '-',
                duration,
                i['taskFinishTime'] if i.get('taskFinishTime') else '-',
                i['memo'] if i.get('memo') else '-'
            ])

        table = tabulate(tabular_data, field_names, tablefmt='plain')
        if output:
            click.echo(create_output('task', output, table))
        else:
            click.echo(table)

    paginated_request(ctx, api, params, callback, payload, all=all, output=output)


def echo_note_response(ctx, api, params, all=False, output=False):
    """请求并输出个性分析离线任务接口的数据

    :param ctx: 上下文
    :param api: 请求的API地址
    :param params: Query参数
    :param all: 查询所有数据
    :param output: 输出文件路径
    """
    from tabulate import tabulate

    from dcs_cli.utils import paginated_request, create_output

    def callback(response):
        field_names = ['任务编号', '任务名称', '创建人', '任务数', '创建时间']
        tabular_data = []
        if response.get('result'):
            from collections import defaultdict
            from dcs_cli.enums import AnalysisOfflineTaskStatusEnum
            for i in response['result']['records']:
                subtask_status_dict = defaultdict(int)  # 统计不同状态的子任务数
                total = 0
                for subtask in i['subTasks']:
                    total += subtask['quantity']
                    subtask_status_dict[subtask['status'].lower()] += subtask['quantity']
                tasks = ['总任务: {}'.format(total)]
                for status, name in AnalysisOfflineTaskStatusEnum.items():
                    if subtask_status_dict[status]:
                        tasks.append('{}: {}'.format(name, subtask_status_dict[status]))

                task_num = '; '.join(tasks)
                tabular_data.append([
                    i['taskId'],
                    i['taskName'],
                    i['tpuse'],
                    task_num,
                    i['createTime'],
                ])

            table = tabulate(tabular_data, field_names, tablefmt='plain')
            if output:
                click.echo(create_output('task', output, table))
            else:
                click.echo(table)

    paginated_request(ctx, api, params, callback, method='GET', hooks=None,
                      params_page_key='pageNo', response_data_key='result', all=all, output=output)


def echo_note_subtask_response(ctx, api, params, all=False, output=False):
    """请求并输出个性分析离线任务的子任务接口的数据

    :param ctx: 上下文
    :param api: 请求的API地址
    :param params: Query参数
    :param all: 查询所有数据
    :param output: 输出文件路径
    """
    from tabulate import tabulate

    from dcs_cli.utils import paginated_request, create_output

    def callback(response):
        field_names = ['任务编号', '任务名称', '状态', '项目编号', '代码名称', '创建人', '创建时间', '更新时间',
                       '计算资源', '费用', '分析镜像']
        tabular_data = []
        if response.get('result'):
            for i in response['result']['records']:
                code = '\n'.join(i['shells']) if i['shells'] else i['notebookName']
                tabular_data.append([
                    i['taskId'],
                    i['taskName'],
                    i['status_dictText'],
                    i['projectId'],
                    code,
                    i['tpuse'],
                    i['createTime'],
                    i['updateTime'],
                    i['computingName'],
                    i.get('amount', '-'),
                    i['imageName']
                ])

            table = tabulate(tabular_data, field_names, tablefmt='plain')
            if output:
                click.echo(create_output('task', output, table))
            else:
                click.echo(table)

    paginated_request(ctx, api, params, callback, method='GET', hooks=None,
                      params_page_key='pageNo', response_data_key='result', all=all, output=output)


def get_workflow_offline_ids(ctx, ids):
    """统计流程分析和个性分析离线任务"""
    from requests import Session

    from dcs_cli.utils import make_request
    from dcs_cli.apis import task_detail_api
    session = Session()
    workflow_ids = set()
    offline_ids = set()
    for id in ids:
        params = {'taskId': id}
        response = make_request(ctx, 'GET', task_detail_api, params=params, session=session)
        if response.get('data'):
            workflow_ids.add(id)
        else:
            offline_ids.add(id)
    return list(workflow_ids), list(offline_ids)
