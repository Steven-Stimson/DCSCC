import base64
import io
import json
import os
import re
import tarfile
import zipfile
from math import ceil
from pathlib import Path
from typing import Dict
from typing import List
from typing import Tuple
from urllib.parse import urljoin

import click
from click import Abort
from colorama import Fore
from colorama import Style

from yarl import URL

from dcs_cli.common import MAX_DIRECT_PRINT_PAGESIZE
from dcs_cli.common import MAX_OUTPUT_PAGESIZE
from dcs_cli.common import URL_DICT
from dcs_cli.common import echo_info
from dcs_cli.enums import MsgStatusTypeEnum
from dcs_cli.utils import HelpOnInvalidCommand
from dcs_cli.utils import HelpOnMissingParamCommand
from dcs_cli.utils import _build_common_headers
from dcs_cli.utils import _build_common_params
from dcs_cli.utils import _safe_request
from dcs_cli.utils import check_file
from dcs_cli.utils import create_dir
from dcs_cli.utils import echo_debug_info
from dcs_cli.utils import echo_exceprtion
from dcs_cli.utils import echo_table_info
from dcs_cli.utils import format_datetime
from dcs_cli.utils import get_user_perm
from dcs_cli.utils import handle_msg
from dcs_cli.utils import handle_output
from dcs_cli.utils import output_file
from dcs_cli.utils import paginate_query
from dcs_cli.utils import safe_decode
from src.codes.app_codes import *
from src.codes.common_codes import CLOUD_SERVICE_ERROR
from src.codes.common_codes import ECHO_TOTAL_COUNT_SUCCESS
from src.codes.common_codes import FILE_GENERATION_ERROR
from src.codes.common_codes import FILE_GENERATION_SUCCESS
from src.codes.common_codes import FILE_INVALID_ERROR
from src.codes.common_codes import INPUT_VALID_NUMBER_ERROR
from src.codes.common_codes import QUERY_FAILED_ERROR
from src.codes.manager import manager_cli

WORKFLOW_IMPORT_PERM = 'codeTree:project_management:workflow_analysis:workflow:import'
WORKFLOW_EDIT_PERM = 'codeTree:project_management:workflow_analysis:workflow:edit'
WORKFLOW_EXPORT_PERM = 'codeTree:project_management:workflow_analysis:workflow:export'
WORKFLOW_UPDATE_PERM = 'codeTree:project_management:workflow_analysis:workflow:update'
WORKFLOW_DETAIL_PERM = 'codeTree:project_management:workflow_analysis:workflow:detail'
WORKFLOW_COPY_PERM = 'codeTree:project_management:workflow_analysis:workflow:copy'


def validate_file_format(path, file_suffix):
    """检查文件是否符合格式"""
    file_name = os.path.basename(path)
    if not file_name.endswith(file_suffix):
        return False
    return True


def base64_info(wdl_path):
    """读取wdl文件并在转化为base64"""
    with open(wdl_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def read_file(path, mode='rb'):
    """读取文件"""
    with open(path, mode) as f:
        return f.read()


def list_zip_files(zip_path):
    """读取zip文件列表"""
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        # 获取所有文件名列表
        return zip_ref.namelist()


def list_tar_files(tar_path):
    """读取tar文件列表"""
    # 根据后缀自动识别压缩格式
    mode = 'r'
    if tar_path.endswith('.tar.gz'):
        mode = 'r:gz'
    elif tar_path.endswith('.tar.bz2'):
        mode = 'r:bz2'

    with tarfile.open(tar_path, mode) as tar_ref:
        # 获取所有文件名列表
        files = tar_ref.getnames()
        return files


def list_archive_files(archive_path):
    """获取压缩包内容列表，无需解压文件"""
    if zipfile.is_zipfile(archive_path):
        return list_zip_files(archive_path)
    elif tarfile.is_tarfile(archive_path):
        return list_tar_files(archive_path)
    else:
        return []


def get_dependency_filename(file_path: str):
    """
    流式读取 WDL 文件，依赖包的文件名
    :param file_path: WDL文件路径
    """
    import_line = ''
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            if line.lstrip().startswith('import'):
                import_line = line.rstrip('\n')
                break

    regex = re.compile(r'^\s*import\s+"([^"]+)"\s+as\s+')
    match = regex.match(import_line)

    return match.groups()[0] if match else ''


def get_wdl_and_zip_path(wdl_path):
    """读取wdl文件，如果有依赖返回依赖所对应的zip文件路径"""
    zip_file_dict = {}
    dependency_filename = get_dependency_filename(wdl_path)
    dir_path = os.path.dirname(wdl_path)
    for file_name in os.listdir(dir_path):
        file_path = os.path.join(dir_path, file_name)
        if file_path.endswith('.zip') or file_path.endswith('.tar'):
            zip_file_dict[file_path] = list_archive_files(file_path)

    dependency_zip_path = ''
    if dependency_filename:
        for path, file_list in zip_file_dict.items():
            if dependency_filename in str(file_list):
                dependency_zip_path = path

    return wdl_path, dependency_zip_path


def get_app_bill(ctx, origin_id, billing_type, return_type=None):
    params = {
        'vendor': 'aliyun',  # 厂商，固定 aliyun
        'detail.tags': origin_id,  # 流程 id
        'supportedTypes': billing_type,
        'needDiscountInfo': True if str(billing_type) == '40101' else False
    }
    base_url = str(URL(ctx.obj.get('cloud_url')))
    req_url = urljoin(base_url, URL_DICT.get('app_bill'))
    headers = _build_common_headers(ctx, 'access')
    status, response = _safe_request(req_url, params=params, headers=headers)
    if return_type:
        return status, response
    else:
        if not status:
            return 0
        return response['data'][0]['price'] if response['data'] else 0


def get_app_bill_discount(ctx, tag):
    headers = _build_common_headers(ctx, 'access')
    req_url = urljoin(str(URL(ctx.obj.get('cloud_url'))), URL_DICT.get('app_bill_discount'))
    status, response = _safe_request(req_url, params={'detail.tags': tag}, headers=headers)
    if not status:
        return False, response
    return True, response['data'][0]['rules']


def get_origin_id(info):
    """ 获取查询价格的Workflow id
    :param info: Workflow信息
    :return: Workflow id
    """
    # 如果有来源，并且没有编辑过，则获取的是 origin_id，否则，获取的是 id
    if info['origin_type'] and info.get('is_edit', -1) == 0:
        return info['origin_id']
    return info['id']


def get_other_info(ctx, data, public):
    """查询额外的信息"""
    workflow_tag, official_tag, price = '', '', ''
    if public:
        official_tag = 'DCS' if str(data.get('isSto', '-1')) == '1' else ''
        price = handle_price(data.get('originalPrice', ''))
    else:
        if data.get('version_list'):
            info = data['version_list'][0]
            official_tag = 'DCS' if info.get('official_workflow', '') == 'yes' else ''
            workflow_tag = info.get('workflow_tag')
            origin_id = get_origin_id(data)
            price = 'free' if not data.get('billing_type') else get_app_bill(ctx, origin_id, info['billing_type'])
            price = handle_price(price)

    return [workflow_tag, official_tag, price]


def get_origin_project_name(ctx, info):
    """获取源项目名称
    origin_type为public，直接设置为“公共库”
    origin_type为"",设置为"项目内创建"
    其他情况，需要请求获取项目名称
    """
    project_name = ''
    origin_type = info.get('origin_type')
    if not origin_type:
        project_name = "项目内创建"
    elif origin_type == 'public':
        project_name = "公共库"
    else:
        try:
            origin_project = info.get('origin_project')
            if not origin_project:
                return project_name
            base_url = str(URL(ctx.obj.get('cloud_url')))
            headers = _build_common_headers(ctx, 'access')
            req_url = urljoin(base_url, URL_DICT.get('app_get_project_info'))
            status, response = _safe_request(req_url, params={'codes[0]': origin_project}, headers=headers)
            if not status:
                echo_exceprtion(ctx)
                return project_name
            project_name = response['data']['records'][0]['name']
        except Exception:
            echo_exceprtion(ctx)
    return project_name


def _build_app_workflow_table(ctx, data, public):
    # 展示字段：流程名称、流程创建人、创建时间、流程标签、官方标签DCS（有的话返回，没有不显示），流程价格（付费流程显示，免费流程不显示）
    from rich.table import Table
    from rich.text import Text
    table = Table(show_header=True, header_style="bold black", show_lines=True)
    table.add_column("流程名称", width=35, overflow='fold')
    table.add_column("流程创建人", width=35, overflow='fold')
    table.add_column("创建时间", width=35, overflow='fold')
    table.add_column("来源", width=35, overflow='fold')
    table.add_column("流程标签", width=35, overflow='fold')
    table.add_column("流程价格", width=35, overflow='fold')
    if public:
        for info in data:
            other_info = get_other_info(ctx, info, public)
            text = Text()
            text.append(info.get("name", '') + " ")
            text.append(f"{Fore.BLUE}{other_info[1]}{Style.RESET_ALL}", style="bold blue")
            table.add_row(
                text,
                info.get("createdBy", ''),
                format_datetime(timestamp_ms=int(info["resCreatedAt"])),
                info.get('srcProjectId', ''),
                ','.join([tag for tag in info['tags'] if tag is not None]) if info.get("tags") else '',
                other_info[2],
            )
    else:
        for info in data:
            other_info = get_other_info(ctx, info, public)
            text = Text()
            text.append(info.get("name", '') + " ")
            text.append(f"{Fore.BLUE}{other_info[1]}{Style.RESET_ALL}", style="bold blue")
            table.add_row(
                text,
                info.get("user_name", ''),
                format_datetime(iso_str=info.get("create_at")),
                get_origin_project_name(ctx, info),
                other_info[0],
                other_info[2],
            )
    return table


def save_and_extract_zip(zip_bytes: bytes, output_dir: str):
    """
    将二进制 ZIP 数据保存到本地并递归解压所有嵌套 ZIP
    :param zip_bytes: 二进制 ZIP 数据
    :param output_dir: 解压根目录，默认为当前目录下的 output 文件夹
    """
    # 创建输出目录
    output_path = Path(output_dir).absolute()

    # 递归解压函数
    def _recursive_unzip(zip_data: bytes, base_path: Path, depth=0):
        if depth > 10:  # 防止无限递归
            raise RuntimeError("递归深度超过安全限制(10)")

        with zipfile.ZipFile(io.BytesIO(zip_data)) as zip_ref:
            for file_info in zip_ref.infolist():
                # 处理文件名编码
                orig_name = file_info.filename
                try:
                    # 转换 ZIP 文件名编码
                    safe_name = orig_name.encode('cp437').decode('utf-8')
                except UnicodeDecodeError:
                    safe_name = orig_name  # 回退方案

                # 构建安全路径
                full_path = base_path / safe_name
                parent_dir = full_path.parent
                parent_dir.mkdir(parents=True, exist_ok=True)

                # 如果是目录则创建
                if file_info.is_dir():
                    parent_dir.mkdir(exist_ok=True)
                    continue

                # 写入文件内容
                with open(full_path, 'wb') as f:
                    f.write(zip_ref.read(file_info))

                # 如果文件是 ZIP 则递归解压，_dep.zip为结尾的依赖包不解压。
                if safe_name.lower().endswith('.zip'):
                    if safe_name.lower().endswith('_dep.zip'):
                        continue
                    nested_zip = zip_ref.read(file_info)
                    nested_dir = full_path.with_suffix('')  # 创建同名目录存放嵌套内容
                    _recursive_unzip(nested_zip, nested_dir, depth + 1)

    # 开始处理根ZIP
    _recursive_unzip(zip_bytes, output_path)
    return output_path


def validate_input(input_str: str, valid_numbers: set):
    """
    严格校验用户输入是否为有效数字

    参数：
    - input_str: 用户输入的字符串，多个值用逗号分隔
    - valid_numbers: 有效数字集合，示例 {1, 2, 3}

    返回：
    (是否有效, 错误描述)
    """
    # 拆分输入并过滤空值
    invalid_items = []
    for item in [item.strip() for item in input_str.split(',') if item.strip()]:
        # 检查是否在有效数字范围内
        if item not in valid_numbers:
            invalid_items.append(item)

    # 生成校验结果
    if not invalid_items:
        return True, "ok"
    else:
        error_msg = manager_cli.get_msg_info(APP_INPUT_ERROR) % (len(invalid_items), ', '.join(invalid_items))
        return False, error_msg


def get_dict_str(repeat_dict):
    """打印字典"""
    s = ''
    for k, v in repeat_dict.items():
        s += f"{k}: {v}\n"

    return s


def _build_list_params(project, base_url, public, name, user=None, tag=None, page_size=10):
    """构建请求参数"""
    if public:
        params = _build_common_params(key='limit', page_size=page_size)
        req_url = urljoin(base_url, URL_DICT.get('app_public_list'))
        if name and user:
            params.update({"types": "workflow", "name": name, "user": user})
        elif name:
            params.update({"types": "workflow", "in": 'name', "kw": name})
        elif user:
            params.update({"types": "workflow", "in": 'createdBy', "kw": user})
        else:
            params.update({"types": "workflow"})

        if tag:
            params.update({"types": "workflow", 'tags': tag})
    else:
        params = {'offset': 0, 'page_size': page_size, 'project': project}
        req_url = urljoin(base_url, URL_DICT.get('app_list'))
        if name:
            params['name'] = name
        if user:
            params['user_name'] = user
        if tag:
            params['workflow_tag'] = tag

    return req_url, params


def pull_tool_to_project(ctx, headers, name):
    # 查询公共库流程
    res = []
    base_url = str(URL(ctx.obj.get('cloud_url')))
    req_public_url = urljoin(base_url, URL_DICT.get('app_public_list'))
    list_params = {"types": "workflow", "in": 'name', "kw": name, 'exc': True}
    status, response = _safe_request(req_public_url, method='POST', json=list_params, headers=headers)
    if not status:
        echo_info(response, MsgStatusTypeEnum.ERROR)
        return False, res
    if not response.get('data', {}).get('records', []):
        echo_info(manager_cli.get_msg_info(APP_PUBLIC_NOT_FOUND_BY_NAME_ERROR) % name, MsgStatusTypeEnum.ERROR)
        return False, res

    # 从公共库复制到项目中
    copy_params = {
        "appId": response['data']['records'][0]['oid'],
        "name": name, "projectIds": [ctx.obj.get('projectId')]
    }
    req_copy_url = urljoin(base_url, URL_DICT.get('app_copy'))
    status, response = _safe_request(req_copy_url, method="POST", json=copy_params, headers=headers)
    if not status:
        echo_info(response, MsgStatusTypeEnum.ERROR)
        return False, res

    # 查询复制后的name和version信息
    req_url, params = _build_list_params(ctx.obj.get('projectId'), base_url, '', '')
    params['workflow_id'] = response['data']['workflow_id_list'][0]
    status, response = _safe_request(req_url, params=params, headers=headers)
    if not status:
        echo_info(response, MsgStatusTypeEnum.ERROR)
        return False, res
    if len(response.get('workflow_list', [])) != 1:
        echo_info(manager_cli.get_msg_info(PULL_APP_FAILED_ERROR) % name, MsgStatusTypeEnum.ERROR)
        return False, res

    app_obj = response['workflow_list'][0]
    version_list = [app_obj['name'], [info['version'] for info in app_obj['version_list']]]
    return True, version_list


def get_overwrite_data(repeat_dict: Dict, operate_flag: bool):
    """ 根据用户的选择处理需要覆盖的数据"""
    while True:
        tips_msg = get_dict_str(repeat_dict).strip('\n')
        overwrite_list, rename_list = [], []
        input_str = click.prompt(
            text=click.style(
                f"\n选择以下可被覆盖的工作流（无法覆盖系统预制和无编辑权限的工作流），未选择或不可覆盖的工作流导入后将生成副本\n"
                f"{tips_msg}\n"
                "【返回上一层请输入b】\n"
                "请选择序号，多个序号使用“,”隔开", fg='yellow'), type=str
        )
        input_str = input_str.replace('，', ',')
        if input_str.strip() == 'b':
            break
        check_status, msg = validate_input(input_str, set(repeat_dict.keys()))
        if check_status:
            selected_ids = set(input_str.split(','))
            for id, name in repeat_dict.items():
                if id in selected_ids:
                    overwrite_list.append(name)
                else:
                    rename_list.append(name)
            operate_flag = False
            break
        else:
            echo_info(msg, MsgStatusTypeEnum.WARNING)

    return overwrite_list, rename_list, operate_flag


def handle_repeat_data(data: List[dict], overwrite_list: List[str], rename_list: List[str], repeat_count: int
                       ) -> Tuple[List[str], List[str]]:
    """根据用户输入处理重复工作流

    Args:
        data: 待处理的工作流数据列表
        overwrite_list: 需要覆盖的工作流名称列表（会被修改）
        rename_list: 需要重命名的工作流名称列表（会被修改）

    Returns:
        更新后的覆盖列表和重命名列表
    """
    # 上传文件，包含两种情况：覆盖或者生成一个新的副本
    repeat_dict = {str(index): info['name'] for index, info in enumerate(data, 1)}
    operate_flag, operate = True, 0
    while operate_flag:
        operate = click.prompt(
            text=click.style(
                f"\n项目中存在 {repeat_count} 个重名工作流\n"
                "1. 覆盖目标工作流（无法覆盖系统预制和无编辑权限的工作流）\n"
                "2. 跳过并生成副本\n"
                "3. 让我决定每个工作流\n"
                "请选择1、2或者3，默认是", fg='black'), default='3'
        )

        operate = str(operate).strip()
        if operate not in ['1', '2', '3']:
            echo_info(manager_cli.get_msg_info(INPUT_VALID_NUMBER_ERROR), MsgStatusTypeEnum.ERROR)
            continue
        if operate == '3':
            overwrite_list, rename_list, operate_flag = get_overwrite_data(repeat_dict, operate_flag)
        elif operate in ['1', '2']:
            break

    if operate == '1':
        # 覆盖
        overwrite_list += list(repeat_dict.values())
    elif operate == '2':
        # 生成新的副本
        rename_list += list(repeat_dict.values())

    return overwrite_list, rename_list


def get_update_ids(data):
    """根据用户输入匹配需要更新的流程信息"""
    id_list, repeat_dict, name_to_id = [], {}, {}
    for index, info in enumerate(data, 1):
        name = info['name']
        id = info['id']
        repeat_dict[str(index)] = name
        name_to_id[name] = id
    while True:
        tips_msg = get_dict_str(repeat_dict).strip('\n')
        input_str = click.prompt(
            text=click.style(
                f"共有 {len(repeat_dict)} 条流程可更新，更新后，将获取源流程的最新版本数据\n"
                f"{tips_msg}\n"
                "【全部更新请输入：all】\n"
                "请选择需要更新的序号，多个用“,”隔开,如【1,2】", fg='black'), type=str)
        # 全量更新
        if input_str.strip() == 'all':
            return [name_to_id[name] for id, name in repeat_dict.items()]

        # 批量更新
        check_status, msg = validate_input(input_str, set(repeat_dict.keys()))
        if check_status:
            for id, name in repeat_dict.items():
                if str(id) in input_str:
                    id_list.append(name_to_id[name])
            break
        else:
            echo_info(msg, MsgStatusTypeEnum.WARNING)

    return id_list


def get_version_list(project, base_url, headers, name):
    """根据name获取版本信息"""
    req_url, params = _build_list_params(project, base_url, '', name)
    params['accurate'] = True  # 精准查询
    status, response = _safe_request(req_url, params=params, headers=headers)
    if not status:
        return False, echo_info(response, MsgStatusTypeEnum.ERROR)

    if len(response["workflow_list"]) != 1:
        return False, echo_info(manager_cli.get_msg_info(APP_NOT_FOUND_BY_NAME_ERROR) % name, MsgStatusTypeEnum.ERROR)

    version_list = [info['version'] for info in response['workflow_list'][0]['version_list']]
    return True, version_list


def handle_special_data(perm_list, req_data, user_info):
    """提前处理无法覆盖系统预制和无编辑权限的工作流
    1、属于系统的无权限覆盖；
    2、属于公共库的无法覆盖；
    3、只要是自己的都可以覆盖；
    4、有project_management:workflow_analysis:workflow:edit权限的，除了1、2情况都可以覆盖。
    """
    rename_list, new_data, own_list = [], [], []
    # 过滤系统获取来自公共库的数据
    for info in req_data:
        if info['user_name'] == user_info.get('username'):
            own_list.append(info)
        elif ((info['is_sys'] and info['is_sys'] == '1') or
              info['is_subscribe'] == 'yes' and info['origin_type'] == 'public'):
            rename_list.append(info)
        else:
            new_data.append(info)

    if not new_data:
        return new_data + own_list, rename_list

    # 如果有编辑权限，不是自己也可以编辑，否则没权限编辑
    if WORKFLOW_EDIT_PERM not in perm_list:
        rename_list, new_data = new_data + rename_list, []
    return new_data + own_list, rename_list


def return_info(name, version, public):
    """打印提示信息"""
    if public:
        if name and version:
            return echo_info(manager_cli.get_msg_info(APP_PUBLIC_NOT_FOUND_BY_NAME_AND_VERSION_ERROR) % (name, version),
                             msg_status=MsgStatusTypeEnum.ERROR)
        else:
            return echo_info(manager_cli.get_msg_info(APP_PUBLIC_NOT_FOUND_BY_NAME_ERROR) % name,
                             msg_status=MsgStatusTypeEnum.ERROR)
    else:
        if name and version:
            return echo_info(manager_cli.get_msg_info(APP_NOT_FOUND_BY_NAME_AND_VERSION_ERROR) % (name, version),
                             msg_status=MsgStatusTypeEnum.ERROR)
        else:
            return echo_info(manager_cli.get_msg_info(APP_NOT_FOUND_BY_NAME_ERROR) % name,
                             msg_status=MsgStatusTypeEnum.ERROR)


def parse_type(string: str, target: str) -> dict:
    """ 解析类型字符串并提取结构化信息
    targetKey => 参数
    type=>类型，需要组合显示，逻辑如下：【
        row.deepType ? `Array[Array[${row.itemType}]]` : row.type === 'Array' ? `${row.type}[${row.itemType}]`:row.type
    】
    required=>是否必填
    def=>推荐取值
    description=>参数描述，需要组合渲染【input_desc[$key].param_des】
    """
    copy = string
    result = {
        'type': '',
        'required': True,
        'optional': False,
        'def': '',
        'itemType': '',
        'deepType': '',
        'targetKey': target
    }

    # 提取基础类型 (例如 Array/Map)
    st_match = re.match(r'^[a-zA-Z]+', copy)
    st = st_match.group(0) if st_match else ''
    copy = copy.replace(st, '', 1) if st else copy

    # 检测是否包含 Array 类型
    dt_match = re.search(r'\bArray\b', copy)
    dt = dt_match.group(0) if dt_match else ''
    if dt:
        copy = copy.replace(dt, '', 1)

    # 提取元素类型（例如 [T] 或 [[T]]）
    w1, ist = '', ''
    if dt == 'Array':
        array_match = re.match(r'^\[\[([a-zA-Z?]+)\]\]', copy)
        if array_match:
            w1, ist = array_match.group(0), array_match.group(1).replace('?', '')
            copy = copy.replace(w1, '', 1)
    else:
        item_match = re.match(r'^\[([a-zA-Z?]+)\]', copy)
        if item_match:
            w1, ist = item_match.group(0), item_match.group(1).replace('?', '')
            copy = copy.replace(w1, '', 1)

    # 处理可选标记 (?)
    required_match = re.match(r'^(\?)?', copy)
    required = required_match.group(1) if required_match else ''
    copy = copy.replace(required, '', 1) if required else copy
    result['required'] = not bool(required)

    # 处理 optional 标记
    optional = False
    if st == 'Map':
        optional_match = re.search(r'(optional)', copy)
        if optional_match:
            optional = True
            copy = copy.replace(optional_match.group(0), '', 1)
    else:
        optional_match = re.match(r'^\s*\((optional)', copy)
        if optional_match:
            optional = True
            copy = copy.replace(optional_match.group(0), '', 1)
    result['optional'] = optional

    # 提取默认值
    default_match = re.search(r'default\s*=\s*([^)]+)', copy)
    if default_match:
        result['def'] = default_match.group(1).strip()
        copy = copy.replace(default_match.group(0), '', 1)

    # 处理特殊 Array -> Map 的情况
    if st == 'Array' and not ist:
        default_map_match = re.search(r'default\s*=\s*([^)]+)', copy)
        if default_map_match:
            result['def'] = default_map_match.group(1).strip()
        st = 'Map'
        optional_map_match = re.search(r'(optional)', copy)
        result['optional'] = bool(optional_map_match)

    # 最终赋值
    result['type'] = st
    result['itemType'] = ist
    result['deepType'] = dt

    return result


def get_type_str(row: dict) -> str:
    """根据数据结构生成类型描述字符串

    Args:
        row (dict): 包含类型信息的字典，需要包含以下键：
                    - deepType (bool): 是否嵌套数组
                    - type (str): 基础类型名
                    - itemType (str): 数组元素类型

    Returns:
        str: 生成的类型描述字符串
    """
    # 安全获取字段值，避免KeyError
    deep_type = row.get('deepType', False)
    base_type = row.get('type', 'UnknownType')
    item_type = row.get('itemType', 'UnknownType')

    if deep_type:
        # 处理嵌套数组类型 (e.g. Array[Array[int]])
        return f"Array[Array[{item_type}]]"
    elif base_type == 'Array':
        # 处理一维数组类型 (e.g. Array[str])
        return f"Array[{item_type}]"
    else:
        # 返回基础类型 (e.g. str/int)
        return base_type


def handle_none(info):
    """处理字符串，如果为空，返回-"""
    return '-' if not info else info


def echo_detail_table(raw_data, input_desc, info_type='input'):
    from rich.table import Table
    table = Table(show_header=True, header_style="bold black", show_lines=True)
    table.add_column("参数", width=35, overflow='fold')
    table.add_column("类型", width=35, overflow='fold')
    table.add_column("是否必填", width=35, overflow='fold')
    if info_type == 'input':
        table.add_column("推荐取值", width=35, overflow='fold')
        table.add_column("参数描述", width=35, overflow='fold')
    for name, value in raw_data.items():
        temp_info = parse_type(value, name)
        target_key = temp_info['targetKey'].split('.')[-1]
        if info_type == 'input':
            table.add_row(
                target_key,
                handle_none(get_type_str(temp_info)),
                handle_none('是' if temp_info['required'] else '否'),
                handle_none(temp_info['def']),
                handle_none(input_desc.get(temp_info['targetKey'], {}).get('param_des')),
            )
        else:
            table.add_row(
                target_key,
                handle_none(get_type_str(temp_info)),
                handle_none('是' if temp_info['required'] else '否')
            )

    return table


def multiply(a, b):
    """
    乘法函数，支持 str/int/float 输入，返回结果自动省略末尾的零

    参数:
        a (str/int/float): 第一个乘数
        b (str/int/float): 第二个乘数

    返回:
        float 或 int: 自动优化格式的结果

    示例:
        >>> multiply(2, 3)
        6
        >>> multiply("2.5", 3)
        7.5
        >>> multiply(1.234, 5.678)
        7.01
        >>> multiply(0.5, 4)
        2
    """
    try:
        num1 = float(a)
        num2 = float(b)
    except (ValueError, TypeError):
        raise ValueError("输入必须是可转换为数字的str、int或float类型")

    result = round(num1 * num2 / 10, 2)

    # 处理末尾的零
    if result == int(result):
        return int(result)  # 如 6.0 → 6
    else:
        # 用字符串格式化去除末尾的零（如 7.50 → 7.5）
        return float("{:.2f}".format(result).rstrip('0').rstrip('.') if '.' in "{:.2f}".format(result) else result)


def handle_price(msg):
    """如果0.00统一转化为free"""
    free = 'free'
    if not msg:
        if str(msg) == '0':
            return free
        return ''
    return str(free if str(msg) in ['0.00', '0', '0.0'] else msg)


def echo_price_row(table, discount_rules, single_use_fee):
    flag_num = 0
    length = len(discount_rules)
    for index, rule in enumerate(discount_rules, 1):
        if flag_num == 0 and int(rule["start"]) > 1:
            start_str = f'1 - {int(rule["start"]) - 1}'
            table.add_row(
                '1' if start_str == '1 - 1' else start_str, '-', str(multiply(single_use_fee, 10))
            )
        if index == length:
            table.add_row(
                f'≥ {rule["start"]}', f'{rule["discount"]}折',
                str(multiply(single_use_fee, rule['discount']))
            )
        else:
            table.add_row(
                f'{rule["start"]} - {rule["end"]}', f'{rule["discount"]}折',
                str(multiply(single_use_fee, rule['discount']))
            )
        flag_num += 1
    echo_info(table)


def echo_price_table(ctx, public, info, raw_info=None):
    from rich.table import Table
    table = Table(show_header=True, header_style="bold black", show_lines=True)
    table.add_column("运行次数", width=35, overflow='fold')
    table.add_column("折扣优惠", width=35, overflow='fold')
    table.add_column("单价", width=35, overflow='fold')
    fixed_price_msg = '此工作流需付费使用，每个任务按单价一口价收费，若任务失败将不收取任务费用，运行任务所需费用将从您所在的计费组扣除。' \
                      '具体信息可参考《计费说明文档》。\n工作流使用的次数与对应的折扣、费用信息参考下述表格'
    discount_price_msg = (
        '此工作流需订阅使用，订阅工作流运行一次的任务费用由订阅费用与任务运行的资源消耗费用组成。当您提交了一条需订阅使用的任务，若任务失败，'
        '将不会收取您的费用，运行成功任务所需费用将从您所在的计费组扣除。\n'
        '若工作流设置了折扣梯度，计费组使用工作流的次数达到累计数值后，订阅费用将会按照折扣收取。具体信息可参考《计费说明文档》。\n工作流使用'
        '的次数与对应的折扣、费用信息参考下述表格')
    # billingType != 40101情况下，即为订阅一口价模式。
    if public:
        item_info = info
        if raw_info['billing_type'] == 40101:
            # 梯度价格
            sub_plan = json.loads(item_info['subPlan'])
            echo_price_row(table, sub_plan['discount_rules'], sub_plan['single_use_fee'])
        else:
            # 一口价
            echo_info(fixed_price_msg)
            table.add_row(
                '-', '-', handle_price(str(multiply(item_info['originalPrice'], 10)))
            )
            echo_info(table)
    else:
        origin_id = get_origin_id(info)
        if info['billing_type'] == 40101:
            # 获取价格
            status, bill_info = get_app_bill(ctx, origin_id, info['billing_type'], return_type='origin')
            if not status:
                return
            if not bill_info.get('data'):
                return
            echo_info(discount_price_msg)
            bill_data = bill_info['data'][0]
            # 获取梯度价格
            status, discounts_info = get_app_bill_discount(ctx, tag=origin_id)
            if not status:
                return
            echo_price_row(table, discounts_info, bill_data['price'])
        else:
            # 一口价
            echo_info(fixed_price_msg)
            table.add_row(
                '-', '-', str(multiply(get_app_bill(ctx, origin_id, info['billing_type']), 10))
            )
            echo_info(table)


def get_origin_workflow_info(ctx, data, is_private=False, is_public=False, is_free=True):
    """查询原流程信息"""
    base_url = str(URL(ctx.obj.get('cloud_url')))
    msg = manager_cli.get_msg_info(CLOUD_SERVICE_ERROR)
    default_user_info = {'user_name': ctx.obj.get('user_info')['username']} if is_free else {'user_name': ''}
    headers = _build_common_headers(ctx, 'access')

    def get_workflow_info(id):
        req_url = urljoin(base_url, URL_DICT.get('app_list'))
        status, response = _safe_request(req_url, params={'ids': id}, headers=headers)
        if not status:
            return False, msg
        if not response.get('workflow_list'):
            return True, default_user_info
        return True, {'user_name': response.get('workflow_list')[0].get('user_name')}

    if is_private:
        return get_workflow_info(data['origin_id'])
    elif is_public:
        # 查询listapp信息
        req_url = urljoin(base_url, URL_DICT.get('app_detail_get_public_app'))
        status, response = _safe_request(req_url, method="POST", json={"dstAppIds": [data['origin_id']]},
                                         headers=headers)
        if not status:
            return False, msg
        if not response.get('data'):
            return True, default_user_info

        # 查询原始Workflow信息
        return get_workflow_info(response['data'][0].get('srcAppId'))


def check_view_wdl_prem(ctx, info):
    """
    前提条件有编辑，查看权限,收费的is_subscribe=yes
    is_public_wdl=no不公开
         origin_type为null（原始的收费工作流）：
            仅创建人可以编辑查看，其余人无法编辑查看
        origin_type不为null
            is_subscribe=yes:
                 origin_type有值（public或者private）收费的工作流，创建人可以查看，无法编辑，其余人人无法编辑查看
            is_subscribe=no:
                免费的不公开的工作流
                仅创建人可以编辑查看，其余人无法编辑查看

    is_public_wdl=yes公开
        所有人可以编辑查看
    """
    try:
        user_info = ctx.obj.get('user_info')
        current_user_name = user_info['username']
        current_workflow_user_name = info['user_name']

        def check_name(workflow_user_name, current_user_name):
            if workflow_user_name == current_user_name:
                return True
            else:
                return False

        billing_type = info.get('billing_type')
        origin_type = info.get('origin_type')
        if info.get('is_public_wdl') == 'yes':
            return True
        else:
            if not origin_type:
                return current_user_name == current_workflow_user_name
            if info.get('is_subscribe') == 'yes':
                if billing_type:
                    status, origin_info = get_origin_workflow_info(ctx, info, is_private=True, is_free=False)
                    if not status:
                        return False
                    return check_name(origin_info['user_name'], current_user_name)
                else:
                    return current_user_name == current_workflow_user_name
            else:
                if origin_type == 'public':
                    status, origin_info = get_origin_workflow_info(ctx, info, is_public=True)
                else:
                    status, origin_info = get_origin_workflow_info(ctx, info, is_private=True)
                if not status:
                    return False
                return check_name(origin_info['user_name'], current_user_name)
    except Exception:
        return False


def get_detail_images(ctx, info, public=False):
    headers = _build_common_headers(ctx, 'access')
    if public:
        params = {'id': info['oid'], 'ver': info['versionNumbers']}
        req_url = urljoin(str(URL(ctx.obj.get('cloud_url'))), URL_DICT.get('app_detail_get_public_image'))
        status, response = _safe_request(req_url, params=params, headers=headers)
        if not status:
            return False
        records = response.get('data', {}).get('records', [])
        if not len(records):
            return False
        return True
    else:
        payload = {
            "image_urls": info['images'],
            "zone": ctx.obj.get('zone')
        }
        req_url = urljoin(str(URL(ctx.obj.get('cloud_url'))), URL_DICT.get('app_detail_get_image'))
        status, response = _safe_request(req_url, method='POST', json=payload, headers=headers, return_type='origin')
        if not status:
            return False
        return [info for info in response if info]


def is_sub(ctx, info):
    """判断是否为订阅工作流

        :param ctx: 上下文对象
        :param info: 详情信息
        :return: bool 是否为订阅工作流
        """
    # 检查是否可编辑
    if int(info.get('is_edit')) != 0:
        return False

    # 在公共库中查找匹配项
    public_library_list = []
    if info.get('origin_id'):
        base_url = str(URL(ctx.obj.get('cloud_url')))
        headers = _build_common_headers(ctx, 'access')
        req_url = urljoin(base_url, URL_DICT.get('app_detail_get_public_app'))
        status, response = _safe_request(req_url, method="POST", json={"dstAppIds": [info['origin_id']]},
                                         headers=headers)
        if not response.get('data'):
            public_library_list = response.get('data')

    find_item = [item for item in public_library_list if item.get('dstAppId') == info.get('origin_id')]
    if not find_item:
        # 不在公共库时的逻辑
        origin_type = info.get('origin_type')
        origin_project = info.get('origin_project')
        is_subscribe = info.get('is_subscribe')

        # 私有项目复制过来的情况
        if origin_type == 'private' and origin_project:
            return is_subscribe == 'yes'

        # 公共库订阅情况
        return is_subscribe == 'yes' and origin_type == 'public'
    else:
        item = find_item[0]
        # 公共库存在匹配项时的逻辑
        sub_plan = item.get('subPlan')
        sub_plan_type = item.get('subPlanType')

        # 同时存在订阅计划和订阅类型
        return bool(sub_plan and sub_plan_type)


def is_show_related_links(ctx, info, public=False):
    if public:
        # 首先必须是非订阅模式，然后就是镜像接口返回的数据为空
        if info['subPlan']:
            return False
        return get_detail_images(ctx, info, public=True)
    else:
        # 1.如果是付费工作流，如果源流程不是自己，直接屏蔽
        # 2.如果不是收费源流程，则看看是否有关联镜像【 dockerList 不为空】，如果有则展示
        other_flag = info['user_name'] == ctx.obj.get('user_info').get('username') if info.get(
            'is_subscribe') == 'yes' else True
        return not is_sub(ctx, info) and (
                len(info.get('toolbox_id_list', [])) > 0 or get_detail_images(ctx, info)) and other_flag


def echo_app_describe_table(ctx, info, public):
    """渲染数据"""
    from rich.text import Text
    if public:
        item = info['data']['item']
        raw = info['data']['raw']
        official_tag = 'DCS' if str(info.get('isSto', '-1')) == '1' else ''
        text = Text()
        text.append(item.get("appName", '') + " ")
        text.append(official_tag, style="bold blue")
        echo_info('工作流名称：' + handle_msg(str(text)))
        echo_info('工作流版本：' + handle_msg(item.get('versionNumbers')))
        echo_info('创建时间：' + handle_msg(item.get("createTime")))
        echo_info('更新时间：' + handle_msg(item.get("updateTime")))
        echo_info('流程创建人：' + handle_msg(item.get("createByName")))
        echo_info('标签：' + handle_msg(','.join([i['name'] for i in item.get('tagList', [])])))
        echo_info('流程描述：' + handle_msg('\n' + raw['description'] if raw.get('description') else ''))
        echo_info('来源：' + handle_msg(item.get('srcProjectId')))
        echo_info('参数【输入】：')
        echo_info(echo_detail_table(raw.get('inputs', {}), raw['input_desc']))
        echo_info('参数【输出】：')
        echo_info(echo_detail_table(raw.get('outputs', {}), raw['input_desc'], 'output'))
        billing_type = raw.get('billing_type')
        if not billing_type:
            echo_info('流程价格：' + handle_price('free'))
        else:
            echo_info('费用说明：')
            echo_price_table(ctx, public, item, raw_info=raw)
        if is_show_related_links(ctx, item, public=True):
            echo_info('相关链接：' + handle_msg(raw['images'][0] if raw.get('images') else '-'))
        if raw['is_public_wdl'] == 'yes':
            script_info = handle_msg(raw.get('source_content'))
            if script_info:
                echo_info('脚本信息：')
                echo_info(script_info, MsgStatusTypeEnum.INFO)
    else:
        official_tag = 'DCS' if info.get('official_workflow', '') == 'yes' else ''
        text = Text()
        text.append(info.get("name", '') + " ")
        text.append(official_tag, style="bold blue")
        echo_info('工作流名称：' + handle_msg(str(text)))
        echo_info('工作流版本：' + handle_msg(info.get('version')))
        echo_info('创建时间：' + handle_msg(format_datetime(iso_str=info.get("create_ts"))))
        echo_info('更新时间：' + handle_msg(format_datetime(iso_str=info.get("update_at"))))
        echo_info('流程创建人：' + handle_msg(info.get("user_name")))
        echo_info('标签：' + handle_msg(info.get('workflow_tag')))
        echo_info('流程描述：' + handle_msg('\n' + info['description'] if info.get('description') else ''))
        echo_info('来源：' + get_origin_project_name(ctx, info))
        echo_info('参数【输入】：')
        echo_info(echo_detail_table(info.get('inputs', {}), info['input_desc']))
        echo_info('参数【输出】：')
        echo_info(echo_detail_table(info.get('outputs', {}), info['input_desc'], 'output'))
        billing_type = info.get('billing_type')
        if not billing_type:
            echo_info('流程价格：' + handle_price('free'))
        else:
            echo_info('费用说明：')
            echo_price_table(ctx, public, info)
        if is_show_related_links(ctx, info):
            echo_info('相关链接：' + handle_msg(info['images'][0] if info.get('images') else '-'))
        if check_view_wdl_prem(ctx, info):
            script_info = handle_msg(info.get('source_content'))
            if script_info:
                echo_info('脚本信息：')
                echo_info(script_info, MsgStatusTypeEnum.INFO)


@click.group(cls=HelpOnInvalidCommand)
def app():
    """流程管理"""
    pass


@app.command(cls=HelpOnMissingParamCommand)
@click.option('-p', '--path', required=True, help="""
将指定文件路径的workflow工具传到到云平台，工具需按照以下目录规则打包到压缩包中\n
/path/to/hello.zip / \n
    ├── hello.yaml       # 工作流基本信息文件\n
    ├── hello.wdl        # WDL脚本主文件\n
    └── my_workflow.tar  # WDL工作流依赖工具包（如有依赖包）""")
@click.pass_context
def push(ctx, path):
    """将workflow工具推送到云平台，需要指定要推送的工具路径"""
    try:
        # 校验文件是否异常
        status, msg = check_file(path)
        if not status:
            return echo_info(msg, msg_status=MsgStatusTypeEnum.ERROR)

        if not validate_file_format(path, '.zip'):
            return echo_info(manager_cli.get_msg_info(FILE_INVALID_ERROR) % (path, '.zip'),
                             msg_status=MsgStatusTypeEnum.ERROR)

        # 检查用户是否有导入权限
        status, perm_list = get_user_perm(ctx)
        if not status:
            return echo_info(perm_list, MsgStatusTypeEnum.ERROR)

        if not perm_list or WORKFLOW_IMPORT_PERM not in perm_list:
            return echo_info(manager_cli.get_msg_info(NO_WORKFLOW_IMPORT_ERROR))

        # 构建请求参数
        base_url = str(URL(ctx.obj.get('cloud_url')))
        zone = ctx.obj.get('zone')
        headers = _build_common_headers(ctx, 'access')
        user_info = ctx.obj.get('user_info')
        # 校验zip文件
        payload = {
            "project": ctx.obj.get('projectId'),
            "user_name": user_info.get('username'),
            "zone": zone,
        }
        files = {
            "target": read_file(path)
        }
        req_url = urljoin(base_url, URL_DICT.get('app_zip_validate'))
        status, response = _safe_request(req_url, method='POST', data=payload, files=files, headers=headers,
                                         return_type='origin')
        if not status:
            return echo_info(response, MsgStatusTypeEnum.ERROR)

        if response.get('code', -1) != 0 and 'message' in response:
            return echo_info(response['message'], MsgStatusTypeEnum.ERROR)

        req_data = response['data']['repeat_list']
        repeat_count = len(req_data)
        # 匹配用户无法过滤的数据信息
        renames = []
        if req_data:
            req_data, renames = handle_special_data(perm_list, req_data, user_info)

        # 处理重复逻辑
        overwrite_list, rename_list = [], []
        if req_data:
            overwrite_list, rename_list = handle_repeat_data(req_data, overwrite_list, rename_list, repeat_count)

        # 构建请求参数
        rename_list += (response['data']['normal_list'] + [info['name'] for info in renames])
        payload['option'] = json.dumps({"overwrite": overwrite_list, "rename": rename_list})
        req_url = urljoin(base_url, URL_DICT.get('app_push'))

        # 调试信息
        if ctx.obj.get('debug'):
            echo_info(f'req_url: {req_url}')
            echo_info(f'headers: {headers}')
            echo_info(f'payload: {payload}')

        status, response = _safe_request(req_url, method='POST', data=payload, files=files, headers=headers)
        if not status:
            return echo_info(response, MsgStatusTypeEnum.ERROR)

        if response['data'].get('failed_list', []):
            error_msg = '\n'.join([info['name'] for info in response['data'].get('failed_list', [])])
            return echo_info(manager_cli.get_msg_info(LOAD_FAILED_ERROR) + '\n' + error_msg, MsgStatusTypeEnum.ERROR)

        return echo_info(manager_cli.get_msg_info(REGISTER_SUCCESS), MsgStatusTypeEnum.SUCCESS)
    except (EOFError, KeyboardInterrupt, Abort):
        pass
    except Exception:
        echo_exceprtion(ctx)
        return echo_info(manager_cli.get_msg_info(REGISTER_FAILED_ERROR), MsgStatusTypeEnum.ERROR)


@app.command(cls=HelpOnMissingParamCommand)
@click.option('-p', '--path', required=True, help="校验指定文件路径下的脚本语法正确性")
@click.pass_context
def validate(ctx, path):
    """校验指定脚本类型语法正确性，当前支持校验脚本类型为wdl"""
    try:
        status, msg = check_file(path)
        if not status:
            return echo_info(msg, msg_status=MsgStatusTypeEnum.ERROR)

        if not validate_file_format(path, '.wdl'):
            return echo_info(manager_cli.get_msg_info(FILE_INVALID_ERROR) % (path, '.wdl'),
                             msg_status=MsgStatusTypeEnum.ERROR)

        # 构造请求参数
        base_url = str(URL(ctx.obj.get('cloud_url')))
        req_url = urljoin(base_url, URL_DICT.get('app_wld_validate'))
        headers = _build_common_headers(ctx, 'access')
        wdl_path, dependency_zip_path = get_wdl_and_zip_path(path)
        payload = {'source_content': base64_info(wdl_path), 'project': ctx.obj.get('projectId')}
        files = {"dependencies": read_file(dependency_zip_path)} if dependency_zip_path else {}

        # 调试信息
        if ctx.obj.get('debug'):
            echo_info(f'req_url: {req_url}')
            echo_info(f'headers: {headers}')
            echo_info(f'payload: {payload}')
        status, response = _safe_request(req_url, method='POST', data=payload, files=files, headers=headers,
                                         return_type='origin')
        if not status:
            return echo_info(response, MsgStatusTypeEnum.ERROR)
        if response.get('code') == 0:
            return echo_info(manager_cli.get_msg_info(VERIFICATION_SUCCESS) % wdl_path,
                             msg_status=MsgStatusTypeEnum.SUCCESS)
        else:
            if 'error_infos' in response:
                for info in response['error_infos']:
                    wdl_msg = json.dumps(info['errorMsg']).strip("\"")
                    if 'row' in info:
                        msg = (f"filename: {path} row: {info['row']} col: {info['col']}\n"
                               f'WDLError: {safe_decode(wdl_msg)}')
                    else:
                        msg = (f"filename: {path}\nWDLError: {safe_decode(wdl_msg)}")
                    return echo_info(msg, MsgStatusTypeEnum.ERROR)
            else:
                return echo_info(manager_cli.get_msg_info(VERIFICATION_FAILED_ERROR) % wdl_path,
                                 MsgStatusTypeEnum.ERROR)
    except Exception:
        echo_exceprtion(ctx)
        return echo_info(manager_cli.get_msg_info(VERIFICATION_FAILED_ERROR) % path, MsgStatusTypeEnum.ERROR)


@app.command(cls=HelpOnMissingParamCommand)
@click.option('-n', '--name', help="按流程名称查询workflow工具，可模糊查询")
@click.option('-u', '--user', help="按流程创建者查询workflow工具，可模糊查询")
@click.option('-p', '--public', is_flag=True, help="查询公共库的workflow工具")
@click.option('-t', '--tag', help="按流程标签查询workflow工具，多个标签使用“,”分割")
@click.option('-a', '--all', is_flag=True, help="查询所有工具")
@click.option('-o', '--output',
              help="输出文件路径，指定全路径如data/work/A.txt，则在work目录下生成名为A的文件；指定目录如data/work/，则在work目录下生成系统命名的文件")
@click.pass_context
def ls(ctx, name, user, public, tag, all, output):
    """查看工具列表"""
    try:
        # 处理output参数
        if isinstance(output, str):
            output = handle_output(output)

        # 构造请求参数
        base_url = str(URL(ctx.obj.get('cloud_url')))
        req_url = urljoin(base_url, URL_DICT.get('app_list'))
        headers = _build_common_headers(ctx, 'access')

        def _request_data(page_size):
            # 添加查询条件
            req_url, params = _build_list_params(ctx.obj.get('projectId'), base_url, public, name, user, tag, page_size)

            # 查询列表信息
            status, response = _safe_request(req_url, params=params, headers=headers)
            return status, response, req_url, params

        if all and output:
            init_page_size = MAX_OUTPUT_PAGESIZE
        elif all:
            init_page_size = MAX_DIRECT_PRINT_PAGESIZE
        else:
            init_page_size = 10
        status, response, req_url, params = _request_data(page_size=init_page_size)
        if not status:
            return echo_info(response, MsgStatusTypeEnum.ERROR)
        # 当返回数量<1000时，直接返回，当返回数量>1000时，查询结果将保存在指定目录下
        total_count = response['count'] if not public else response['data']['total']

        # if all and total_count > init_page_size:
        #     if total_count < MAX_DIRECT_PRINT_PAGESIZE:
        #         page_size = MAX_DIRECT_PRINT_PAGESIZE
        #     else:
        #         page_size = MAX_OUTPUT_PAGESIZE
        #         output = output if output else './'
        #
        #     status, response, req_url, params = _request_data(page_size=page_size)
        #     if not status:
        #         return echo_info(response, MsgStatusTypeEnum.ERROR)

        def callback(response):
            data = response['data']["records"] if public else response["workflow_list"]
            # echo_info(_build_app_workflow_table(ctx, data, public))
            echo_table_info(_build_app_workflow_table(ctx, data, public))
            echo_debug_info(ctx, req_url, params, headers, data)

        if output:
            # 将数据输出为文件
            data = response['data']["records"] if public else response["workflow_list"]
            echo_debug_info(ctx, req_url, params, headers, data)
            table_data = _build_app_workflow_table(ctx, data, public)
            status, msg = output_file(output, table_data, 'app')
            if status:
                return echo_info(manager_cli.get_msg_info(FILE_GENERATION_SUCCESS) % msg)
            else:
                return echo_info(manager_cli.get_msg_info(FILE_GENERATION_ERROR) % msg, MsgStatusTypeEnum.ERROR)

        else:
            # 渲染数据，并且构建翻页信息
            callback(response)
            page_size = params['page_size'] if not public else params['limit']
            total_page = ceil(total_count / page_size)
            if all or total_page < 2:
                echo_info(manager_cli.get_msg_info(ECHO_TOTAL_COUNT_SUCCESS) % total_count, MsgStatusTypeEnum.SUCCESS)
                return
            if public:
                paginate_query(req_url, params, headers, callback, total_page, total_count,
                               params_page_key='page', page_size=page_size)
            else:
                paginate_query(req_url, params, headers, callback, total_page, total_count,
                               params_page_key='offset', params_page_offset=1, page_size=page_size, is_multiply=True)
    except (EOFError, KeyboardInterrupt, Abort):
        pass
    except Exception:
        echo_exceprtion(ctx)
        return echo_info(manager_cli.get_msg_info(QUERY_FAILED_ERROR), MsgStatusTypeEnum.ERROR)


@app.command(cls=HelpOnMissingParamCommand)
@click.option('-n', '--name', required=True, help="查询指定名称的工作流详情")
@click.option('-v', '--version', help="查询指定版本的工作流详情，默认最新版本")
@click.option('-p', '--public', is_flag=True, help="查询公共库工作流的详情信息")
@click.pass_context
def info(ctx, name, version, public):
    """查询应用详细信息"""
    try:
        # 构造请求参数
        base_url = str(URL(ctx.obj.get('cloud_url')))
        headers = _build_common_headers(ctx, 'access')
        project_id = ctx.obj.get('projectId')
        # 添加查询条件
        if public:
            req_url, params = _build_list_params(project_id, base_url, public, name)
            params['exc'] = True

            # 查询列表信息
            status, response = _safe_request(req_url, params=params, headers=headers)
            if not status:
                return echo_info(response, MsgStatusTypeEnum.ERROR)

            if not response['data']['total']:
                return return_info(name, version, public)

            req_url = urljoin(base_url, URL_DICT.get('app_public_info') + f"{response['data']['records'][0]['oid']}/")
            params = {'projectId': project_id}
            if version:
                params['ver'] = version

            status, response = _safe_request(req_url, params=params, headers=headers)
            if not status:
                return echo_info(response, MsgStatusTypeEnum.ERROR)

            if not response:
                return return_info(name, version, public)
            if not response.get('data', {}).get('raw', {}).get('id'):
                return return_info(name, version, public)
            echo_app_describe_table(ctx, response, public)
            echo_debug_info(ctx, req_url, params, headers, [response])
        else:
            # 检查用户是否有导入权限
            status, info = get_user_perm(ctx)
            if not status:
                return echo_info(info, MsgStatusTypeEnum.ERROR)

            if not info or WORKFLOW_DETAIL_PERM not in info:
                return echo_info(manager_cli.get_msg_info(NO_WORKFLOW_DETAIL_ERROR))

            req_url = urljoin(base_url, URL_DICT.get('app_info'))
            params = {'project': project_id}
            if version:
                params['version'] = version
            if name:
                params['workflow_name'] = name

            # 查询列表信息
            status, response = _safe_request(req_url, params=params, headers=headers, return_type='origin')
            if not status:
                return echo_info(response, MsgStatusTypeEnum.ERROR)

            if 'error_type' in response:
                return echo_info(response['message'], MsgStatusTypeEnum.ERROR)

            if not response:
                return return_info(name, version, public)

            echo_app_describe_table(ctx, response, public)
            echo_debug_info(ctx, req_url, params, headers, [response])
    except Exception:
        echo_exceprtion(ctx)
        echo_info(manager_cli.get_msg_info(QUERY_FAILED_ERROR), MsgStatusTypeEnum.ERROR)


@app.command(cls=HelpOnMissingParamCommand)
@click.option('-n', '--name', required=True, help="指定拉取的工具名称")
@click.option('-v', '--version', help="指定拉取的工具版本，与-n、-p参数一同使用")
@click.option('-p', '--path', help="拉取的工具到终端的目标路径，默认为【当前路径】")
@click.option('--public', is_flag=True, help="从公共库复制到项目中，并拉取到终端的指定路径")
@click.pass_context
def pull(ctx, name, version, path, public):
    """拉取项目中的工具代码到终端中"""
    try:
        version = re.sub(r'^version\.', '', version.strip(), flags=re.IGNORECASE) if version else version
        # 参数和版本号不可以共用
        if version and public:
            return echo_info(manager_cli.get_msg_info(PUBLIC_AND_VERSION_ERROR), MsgStatusTypeEnum.ERROR)

        # 创建文件夹信息
        path = handle_output(path)
        path = './' if not path else path
        status, msg = create_dir(path, dir_flag=True)
        if not status:
            return echo_info(msg, MsgStatusTypeEnum.ERROR)

        # 检查用户是否有导出权限
        status, info = get_user_perm(ctx)
        if not status:
            return echo_info(info, MsgStatusTypeEnum.ERROR)

        if not info or WORKFLOW_EXPORT_PERM not in info:
            return echo_info(manager_cli.get_msg_info(NO_WORKFLOW_EXPORT_ERROR))

        if WORKFLOW_COPY_PERM not in info:
            return echo_info(manager_cli.get_msg_info(NO_WORKFLOW_COPY_ERROR))

        # 构造请求参数
        base_url = str(URL(ctx.obj.get('cloud_url')))
        project = ctx.obj.get('projectId')
        headers = _build_common_headers(ctx, 'access')
        if public:
            status, app_info = pull_tool_to_project(ctx, headers, name)
            if not status:
                return
            name, version_list = app_info
        else:
            status, version_list = get_version_list(ctx.obj.get('projectId'), base_url, headers, name)
            if not status:
                return
            if version:
                if version not in version_list:
                    return echo_info(
                        manager_cli.get_msg_info(APP_NOT_FOUND_BY_NAME_AND_VERSION_ERROR) % (name, version),
                        MsgStatusTypeEnum.ERROR)
                version_list = [version]
        # 构建拉取工具的参数
        req_pull_url = urljoin(base_url, URL_DICT.get('app_pull'))
        payload = {"project": project, "target": {name: version_list}}
        # 调试信息
        if ctx.obj.get('debug'):
            echo_info(f'req_url: {req_pull_url}')
            echo_info(f'headers: {headers}')
            echo_info(f'payload: {payload}')

        status, response = _safe_request(req_pull_url, method='POST', json=payload, headers=headers,
                                         return_type='origin')
        if not status:
            return echo_info(response, MsgStatusTypeEnum.ERROR)

        if 'error_type' in response:
            return echo_info(response['message'], MsgStatusTypeEnum.ERROR)

        save_path = save_and_extract_zip(response.content, path)
        return echo_info(manager_cli.get_msg_info(DOWNLOAD_SUCCESS) % save_path, MsgStatusTypeEnum.SUCCESS)
    except Exception:
        echo_exceprtion(ctx)
        return echo_info(manager_cli.get_msg_info(PULL_FAILED_ERROR), MsgStatusTypeEnum.ERROR)


@app.command(cls=HelpOnMissingParamCommand)
@click.option('-n', '--name', help="更新项目内指定名称的工作流，执行后获取关联的最新工作流覆盖当前工作流")
@click.pass_context
def update(ctx, name):
    """更新项目内工作流"""
    try:
        # 检查用户是否有导出权限
        status, info = get_user_perm(ctx)
        if not status:
            return echo_info(info, MsgStatusTypeEnum.ERROR)

        if not info or WORKFLOW_UPDATE_PERM not in info:
            return echo_info(manager_cli.get_msg_info(NO_WORKFLOW_UPDATE_ERROR))

        # 构建请求参数
        base_url = str(URL(ctx.obj.get('cloud_url')))
        headers = _build_common_headers(ctx, 'access')
        req_url = urljoin(base_url, URL_DICT.get('app_update_list'))
        project_id = ctx.obj.get('projectId')
        params = {"project": project_id, "page_size": 100, "offset": 0, "pre_view": 0, "sort_type": "run_ts",
                  "need_batch_refresh": 1}
        status, response = _safe_request(req_url, params=params, headers=headers)
        if not status:
            return echo_info(response, MsgStatusTypeEnum.ERROR)

        if response['count'] == 0:
            return echo_info(manager_cli.get_msg_info(GET_UPDATE_LIST_EMPTY_ERROR), MsgStatusTypeEnum.ERROR)

        id_list = get_update_ids(response['workflow_list'])

        # 调试信息
        if ctx.obj.get('debug'):
            echo_info(f'req_url: {req_url}')
            echo_info(f'headers: {headers}')
            echo_info(f'Found {len(id_list)} matching data entries.')

        # 更新项目中的流程
        req_url = urljoin(base_url, URL_DICT.get('app_update'))
        payload = {"project": project_id, "workflow_ids": ','.join(id_list)}
        status, response = _safe_request(req_url, method='PUT', json=payload, headers=headers)
        if not status:
            return echo_info(response, MsgStatusTypeEnum.ERROR)
        return echo_info(manager_cli.get_msg_info(UPDATE_SUCCESS), MsgStatusTypeEnum.SUCCESS)
    except (EOFError, KeyboardInterrupt, Abort):
        pass
    except Exception:
        echo_exceprtion(ctx)
        return echo_info(manager_cli.get_msg_info(UPDATE_FAILED_ERROR), MsgStatusTypeEnum.ERROR)
