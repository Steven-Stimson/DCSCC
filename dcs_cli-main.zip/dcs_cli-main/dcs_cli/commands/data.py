import click

from dcs_cli.utils import HelpOnInvalidCommand, HelpOnMissingParamCommand

CURRENT_DIR = '/Files'


@click.group(cls=HelpOnInvalidCommand)
@click.pass_context
def data(ctx):
    """数据管理"""
    pass


@data.command(cls=HelpOnMissingParamCommand)
@click.argument('path', default='')
@click.option('-t', '--type', type=click.Choice(['f', 'd']), help='文件类型 f文件 d文件夹')
@click.option('-n', '--name', help='文件或目录名，多个用逗号分隔')
@click.option('-s', '--size', help='根据文件大小递归查找文件')
@click.option('--entity', help='实体ID编号，多个用逗号分隔')
@click.option('--sample', help='样本编号，多个用逗号分隔')
@click.option('--sn', help='芯片号，多个用逗号分隔')
@click.option('--task', help='任务号，多个用逗号分隔')
@click.option('--workflow', help='流程名称及版本号（版本号选填），用逗号分隔')
@click.option('-u', '--user', help='用户名，多个用逗号分隔')
@click.option('--time',
              help='开始时间和结束时间，格式为【YYYY-mm-dd】、【YYYY-mm-dd~YYYY-mm-dd】、【YYYY-mm-dd~】、【~YYYY-mm-dd】')
@click.option('-a', '--all', is_flag=True, help='查询所有数据')
@click.option('-o', '--output', help='输出文件路径')
@click.pass_context
def find(ctx, path, type, name, size, entity, sample, sn, task, workflow, user, time, all, output):
    """列出当前目录下的子目录和文件（递归）"""
    from dcs_cli.enums import DataTypeEnum
    from dcs_cli.apis import get_metadata_api

    projectId = ctx.obj.get('projectId')
    zone = ctx.obj.get('zone')

    if all:
        params = {'page': 1, 'limit': 2000}
    else:
        params = {'page': 1, 'limit': 10}

    current_path = get_current_path()
    if path:
        current_path = cd_like(current_path, path)
    father_path, last_path = current_path.rstrip('/').rsplit('/', maxsplit=1)
    payload = {'projectId': projectId, 'zone': zone, 'recursion': '0',
               'menuPathRegexpMany': [father_path], 'searchNameRegexpMany': [last_path]}

    if type == 'f':
        payload['dataType'] = DataTypeEnum.FILE.value
    elif type == 'd':
        payload['dataType'] = DataTypeEnum.DIRECTORY.value

    if name:
        payload['menuPathRegexpMany'] = []
        payload['searchNameRegexpMany'] = []
        for i in name.split(','):
            father_path, last_path = cd_like(current_path, i).rstrip('/').rsplit('/', maxsplit=1)
            payload['menuPathRegexpMany'].append(father_path)
            payload['searchNameRegexpMany'].append(last_path)

    process_exclusive_option(payload, entity, 'sampleId', 'sampleIdList')
    process_exclusive_option(payload, sample, 'sampleNum', 'sampleNumList')
    process_exclusive_option(payload, sn, 'snId', 'snIdList')
    process_exclusive_option(payload, task, 'taskId', 'taskIdList')
    process_coexistent_option(payload, workflow, 'processId', 'processVersion')
    process_exclusive_option(payload, user, 'creator', 'creatorList')

    if size:
        from dcs_cli.utils import human_readable_to_bytes
        fileSize = human_readable_to_bytes(size)
        if size.startswith('+'):
            payload['fileSizeRangeGt'] = fileSize
        elif size.startswith('-'):
            payload['fileSizeRangeLt'] = fileSize
        else:
            payload['fileSizeRangeEq'] = fileSize

    if time:
        import datetime

        from dcs_cli.utils import process_exist_option
        def normalize_date(date_str):
            """将日期字符串标准化为YYYY-mm-dd"""
            try:
                date_obj = datetime.datetime.strptime(date_str, '%Y-%m-%d')
            except Exception:
                try:
                    date_obj = datetime.datetime.strptime(date_str, '%Y/%m/%d')
                except Exception:
                    raise click.ClickException(f'日期格式错误: {date_str}')
            return date_obj.strftime('%Y-%m-%d')

        time = time.split('~')
        if len(time) == 1:
            startQueryTime = endQueryTime = time[0]
        elif len(time) == 2:
            startQueryTime, endQueryTime = time
        else:
            raise click.ClickException(f'日期格式错误: {time}')
        if startQueryTime:
            startQueryTime = '{} 00:00:00'.format(normalize_date(startQueryTime))
        if endQueryTime:
            endQueryTime = '{} 23:59:59'.format(normalize_date(endQueryTime))
        process_exist_option(payload, startQueryTime, 'startQueryTime')
        process_exist_option(payload, endQueryTime, 'endQueryTime')

    echo_scData_response(ctx, get_metadata_api, params, payload, table=True, human_readable=True, all=all,
                         output=output)


@data.command()
@click.argument('path', nargs=-1)
@click.option('-a', '--all', is_flag=True, help='查询所有数据')
@click.option('-o', '--output', help='输出文件路径')
@click.option('-l', is_flag=True, help='列出当前目录下文件和子目录的详细信息，输出包括文件大小、创建时间、文件名或目录名')
@click.option('-S', is_flag=True, help='按照文件大小排序，默认从大到小')
@click.option('-r', is_flag=True, help='从小到大排序')
@click.option('-h', '--human-readable', is_flag=True, help='与-l一起使用，以人类可读的格式打印文件大小（如1KB、234MB）')
@click.option('-t', is_flag=True, help='按照文件修改时间排序，默认从最新到最旧')
@click.option('-tb', '--table', is_flag=True, help='列出所有表格，或按表格名称列出')
@click.pass_context
def ls(ctx, path, all, output, l, s, r, human_readable, t, table):
    """列出当前目录下或指定目录下的文件和子目录（不递归），仅支持通配符*和?"""
    projectId = ctx.obj.get('projectId')

    if table:  # 表格
        from dcs_cli.utils import make_request
        from dcs_cli.apis import get_excel_api
        if l:
            raise click.UsageError('-l和-tb/--table不能同时使用')
        params = {'projectId': projectId}
        if path:
            params['name'] = path[0]  # 暂时只取第一个
        response = make_request(ctx, 'GET', get_excel_api, params=params)
        echo_excel_response(response)
    else:  # 文件
        from dcs_cli.apis import get_metadata_api
        from dcs_cli.utils import process_exist_option
        from dcs_cli.enums import DataTypeEnum, DataStatusEnum, DataDelFlagEnum, DataSameTypeEnum

        payload = {'projectId': projectId, 'recursion': '0', 'sameType': DataSameTypeEnum.DIR.value,
                   'status': DataStatusEnum.EXIST.value, 'delFlag': DataDelFlagEnum.EXIST.value}

        current_path = get_current_path()

        if len(path) == 0:  # 没传path置空，相当于取当前路径
            path = ['']

        menuPathRegexpMore = []
        searchNameRegexpMore = []
        for i in path:
            father_path, last_path = cd_like(current_path, i).rstrip('/').rsplit('/', maxsplit=1)
            menuPathRegexpMore.append(father_path)
            searchNameRegexpMore.append(last_path)
        process_exist_option(payload, menuPathRegexpMore, 'menuPathRegexpMore')
        process_exist_option(payload, searchNameRegexpMore, 'searchNameRegexpMore')

        if all:
            params = {'page': 1, 'limit': 2000}
        else:
            params = {'page': 1, 'limit': 10}

        if s and t:
            raise click.ClickException('-S和-t不能同时使用')
        if s:
            payload['sortList'] = [{'field': 'fileSize', 'sortOrder': 'DESC'}]
            if r:
                payload['sortList'][0]['sortOrder'] = 'ASC'
        if t:
            payload['sortList'] = [{'field': 'createTime', 'sortOrder': 'DESC'}]
            if r:
                payload['sortList'][0]['sortOrder'] = 'ASC'

        echo_scData_response(ctx, get_metadata_api, params, payload, table=l, human_readable=human_readable, all=all,
                             output=output)


@data.command(cls=HelpOnMissingParamCommand)
@click.argument('path')
@click.pass_context
def cd(ctx, path):
    """目录切换"""
    from dcs_cli.utils import sap_hooks, make_request

    current_path = get_current_path()
    new_path = cd_like(current_path, path)

    if new_path == '/':  # 最顶层目录重定向为/Files
        new_path = '/Files'
        set_current_path(new_path)
        click.echo(new_path)
    else:
        from dcs_cli.apis import get_metadata_api
        from dcs_cli.enums import DataTypeEnum, DataStatusEnum, DataDelFlagEnum, DataPreciseQueryEnum
        father_path, last_path = new_path.rstrip('/').rsplit('/', maxsplit=1)

        params = {'page': 1, 'limit': 10}
        payload = {
            'projectId': ctx.obj.get('projectId'),
            'recursion': '0',
            'dataType': DataTypeEnum.DIRECTORY.value,
            'status': DataStatusEnum.EXIST.value,
            'delFlag': DataDelFlagEnum.EXIST.value,
            'menuPath': father_path,
            'menuName': last_path,
            'preciseQuery': DataPreciseQueryEnum.YES.value,
        }

        response = make_request(ctx, 'POST', get_metadata_api, params=params, json=payload, hooks=sap_hooks)
        if response['data']['total']:
            set_current_path(new_path)
            click.echo(new_path)
        else:
            click.echo('No such file or directory')


@data.command()
def pwd():
    """显示当前目录"""
    click.echo(get_current_path())


@data.command(cls=HelpOnMissingParamCommand)
@click.argument('path')
@click.pass_context
def info(ctx, path):
    """显示文件或文件夹的元数据信息"""
    from dcs_cli.apis import get_metadata_api
    from dcs_cli.utils import sap_hooks, make_request
    from dcs_cli.enums import DataTypeEnum, DataPreciseQueryEnum, DataStatusEnum, DataDelFlagEnum
    projectId = ctx.obj.get('projectId')
    zone = ctx.obj.get('zone')

    params = {'page': 1, 'limit': 1}
    father_path, last_path = cd_like(get_current_path(), path).rstrip('/').rsplit('/', maxsplit=1)
    payload = {
        'projectId': projectId,
        'recursion': '0',
        'menuPath': father_path,
        'searchName': last_path,
        'preciseQuery': DataPreciseQueryEnum.YES.value,
        'status': DataStatusEnum.EXIST.value,
        'delFlag': DataDelFlagEnum.EXIST.value
    }

    response = make_request(ctx, 'POST', get_metadata_api, params=params, json=payload, hooks=sap_hooks)
    if response['data']['total']:
        i = response['data']['records'][0]
        if i['dataType'] == DataTypeEnum.DIRECTORY.value:  # 目录
            click.echo('文件夹名称：' + i.get('menuName', ''))
            click.echo('文件夹路径：' + i.get('menuPath', '') + '/' + i.get('menuName', ''))
            click.echo('文件夹标签：' + i.get('menuLabel', '').replace(',', '  '))
        elif i['dataType'] == DataTypeEnum.FILE.value:  # 文件
            click.echo('文件名称：' + i.get('name', ''))
            click.echo('实体ID：' + i.get('sampleId', ''))
            click.echo()

            click.echo('样本信息')
            click.echo('样本编号：' + i.get('sampleNum', ''))
            click.echo('样本名称：' + i.get('sampleName', ''))
            click.echo('组学：' + i.get('omicsType', ''))
            click.echo('物种：' + i.get('species', ''))
            click.echo('组织：' + i.get('tissue', ''))
            click.echo('样品类型：' + i.get('sampleType', ''))
            click.echo('样品完整性：' + i.get('sampleIntegrity', ''))
            click.echo('样品结果说明：' + i.get('resultNote', ''))
            click.echo()

            click.echo('实验信息')
            click.echo('染色类型：' + i.get('dyeType', ''))
            click.echo('芯片编号：' + i.get('snId', ''))
            click.echo('芯片类型：' + i.get('chipCategory', ''))
            click.echo('芯片规格：' + i.get('chipSpecs', ''))
            click.echo('试剂盒：' + i.get('productKit', ''))
            click.echo('CB length：' + i.get('cbLength', ''))
            click.echo('CB start：' + i.get('cbStart', ''))
            click.echo('CID length：' + i.get('barcodeLen', ''))
            click.echo('MID(UMI) length：' + i.get('umiLen', ''))
            click.echo('CID start：' + i.get('barcodeStart', ''))
            click.echo('MID(UMI) start：' + i.get('umiStartPos', ''))
            click.echo('MID(UMI) location：' + i.get('umiLocation', ''))
            click.echo('Read length：' + i.get('readLen', ''))
            click.echo('fq测序类型：' + i.get('fastqType', ''))
            click.echo('顺序：' + str(i.get('sequence', '')))
            click.echo('SplitNum：' + i.get('splitCount', ''))
            click.echo('文库类型：' + i.get('libraryType', ''))
            click.echo('文库编号：' + i.get('libraryNum', ''))
            click.echo('子文库号：' + i.get('subLibraryNum', ''))
            click.echo('Slide：' + i.get('slide', ''))
            click.echo('lane号：' + i.get('lane', ''))
            click.echo('Barcode：' + i.get('barcode', ''))
            click.echo('碱基质量体系：' + i.get('basicQualityValue', ''))
            click.echo('Q30(%)：' + i.get('q30', ''))
            click.echo('Q20(%)：' + i.get('q20', ''))
            click.echo('ReadNum(G)：' + i.get('readNum', ''))
            click.echo('BaseNum(Gbp)：' + i.get('baseNum', ''))
            click.echo('EstErr(%)：' + i.get('estErr', ''))
            click.echo('测序类型：' + i.get('sequenceType', ''))
            click.echo('测序平台：' + i.get('sequencePlatform', ''))
            click.echo('下机时间：' + i.get('seqDownTime', ''))
            click.echo('实验过程：' + i.get('experimentProcess', ''))
            if i['isMicroscopeFile'] == '1':
                i['isMicroscopeFile'] = '是'
            elif i['isMicroscopeFile'] == '0':
                i['isMicroscopeFile'] = '否'
            click.echo('是否用于分析：' + i.get('isMicroscopeFile', ''))
            click.echo('QC Resultfile：' + i.get('qcResultFile', ''))
            click.echo('图像工具类型：' + i.get('imageToolType', ''))
            click.echo('FileVersion：' + i.get('iprVersion', ''))
            click.echo('Manufacture：' + i.get('manufacture', ''))
            click.echo('StitchedImage：' + i.get('stitchedImage', ''))
            click.echo('ImageQCVersion：' + i.get('imageQcVersion', ''))
            if i['trackCrossQcPassFlag'] == '1':
                i['trackCrossQcPassFlag'] = 'True'
            elif i['trackCrossQcPassFlag'] == '0':
                i['trackCrossQcPassFlag'] = 'False'
            click.echo('TrackCrossQCPassFlag：' + i.get('trackCrossQcPassFlag', ''))
            click.echo('StereoResepSwitch：' + i.get('stereoResepSwitch', ''))
            click.echo()

            click.echo('任务信息')
            click.echo('流程名称：' + i.get('processId', ''))
            click.echo('流程版本号：' + i.get('processVersion', ''))
            click.echo('参考基因组：' + i.get('refrenece', ''))
            click.echo('任务ID：' + i.get('taskId', ''))
            click.echo('父任务ID：' + i.get('pid', ''))
            click.echo('创建人：' + i.get('creator', ''))
            click.echo('投递时间：' + i.get('deliveryTime', ''))
            click.echo('备注：' + i.get('memo'))


@data.command(cls=HelpOnMissingParamCommand)
@click.argument('src')
@click.argument('dest', default='')
@click.option('-tb', '--table', is_flag=True, help='将个人目录的表格传到云平台表格页面')
@click.pass_context
def push(ctx, src, dest, table):
    """将个人目录的文件传到云平台数据管理文件页面，批量文件或目录逗号隔开，一次只能上传一个表格。
    注意：只支持上传/data/work和/data/share-personal下的文件

    :param src: 本地文件路径
    :param dest: 云平台路径
    """
    import platform
    from pathlib import Path

    from dcs_cli.utils import make_request

    projectId = ctx.obj.get('projectId')

    if table:
        from dcs_cli.apis import upload_excel_api

        file = Path(src)
        name = dest if dest else Path(src).stem

        if not file.exists():
            raise click.ClickException('文件不存在 {}'.format(file))
        if ',' in src:
            raise click.ClickException('一次只能上传一个表格')
        if len(name) > 100:
            raise click.ClickException('表格名称为100个字节以内，字母、数字、"_"、"-"和"."，且不能重复')

        files = {
            'projectId': (None, projectId),
            'name': (None, name),
            'file': open(src, 'rb'),
        }
        response = make_request(ctx, 'POST', upload_excel_api, files=files)

        if response.get('msg'):
            click.echo(response['msg'])
        else:
            click.echo('上传成功')
    else:
        def validate_file(file):
            """校验文件名"""
            if platform.system() != 'Windows':
                if not file.exists():
                    raise click.ClickException('文件不存在 {}'.format(file))

            path = file.resolve().as_posix()
            if not any(path.startswith(prefix) for prefix in ('/data/work', '/data/share-personal')):
                click.echo('只支持上传/data/work和/data/share-personal下的文件，已跳过{}'.format(path))
                return False

            name = file.name
            if len(name) > 150:
                raise click.ClickException('限制150个字符 {}'.format(name))
            for c in {' ', '<', '>', '/', '\\', '|', ':', '*', '?', '#', '$', '￥', '&', '+', '《', '》', '。', '【', '】',
                      '[', ']', '=', ';', '~'}:
                if c in name:
                    click.echo('文件名不能包含 {}，已跳过{}'.format(c, path))
                    return False
            for suffix in {'.cmd', '.asp', '.jsp', '.php', '.bat', '.cgi', '.htm', '.html', '.aspx', '.exe', '.py',
                           '.pl', '.rb', '.sh'}:
                if name.endswith(suffix):
                    click.echo('不支持文件类型 {}，已跳过{}'.format(suffix, path))
                    return False
            return True

        zone = ctx.obj.get('zone')
        data_work_path = ctx.obj.get('data_work_path')
        share_presonal_path = ctx.obj.get('share_presonal_path')
        if not dest:
            click.echo(click.style('Missing parameter: dest', fg='red'))
            click.echo(ctx.get_help())
            return
        if not dest.startswith('/Files/'):
            raise click.ClickException('路径无效，输入/Files/...格式路径')

        # 遍历所有文件并校验文件名
        files = set()
        error_paths = set()
        paths = src.split(',')
        for path in paths:
            path = Path(path)
            if path.is_dir():  # 目录
                path = list(path.rglob('*'))
            else:
                path = [path]

            for file in path:
                if file.is_file():  # 文件
                    if validate_file(file):
                        files.add(file.resolve().as_posix())  # 绝对路径
                    else:
                        error_paths.add(file.resolve().as_posix())

        # 校验目标文件夹名称
        import re
        pattern = r'^[a-zA-Z0-9_.\-\\/]{1,50}$'  # 字母、数字、_、-、.，且长度1-50
        for part in Path(dest).parts:
            if not re.fullmatch(pattern, part):
                raise click.ClickException('文件夹名称只支持字母、数字、"_"、"-"和"."，文件夹名称不能超过50个字符')

        srcFilePathList = []
        for file in files:
            path = file.replace('/data/work', data_work_path, 1)
            path = path.replace('/data/share-personal', share_presonal_path, 1)
            srcFilePathList.append(path)
        payload = {
            'srcFilePathList': srcFilePathList,
            'projectId': projectId,
            'menuPath': dest,
            'dataCategory': 'sdk',
            'sourceZone': zone,
            'targetZone': zone,
            'sourceSubnet': 'hpc',
        }
        from dcs_cli.apis import upload_directory_api
        response = make_request(ctx, 'POST', upload_directory_api, json=payload)
        click.echo(response['msg'])


@data.command(cls=HelpOnMissingParamCommand)
@click.argument('src')
@click.argument('dest', default='/data/work')
@click.option('-tb', '--table', is_flag=True, help='将云平台表格页面的表格传到个人目录')
@click.pass_context
def pull(ctx, src, dest, table):
    """将云平台数据管理的文件拷贝到work目录

    :param src: 云平台路径
    :param dest: 本地文件路径
    """
    from dcs_cli.utils import make_request

    projectId = ctx.obj.get('projectId')
    zone = ctx.obj.get('zone')

    if table:
        from pathlib import Path
        from dcs_cli.apis import get_excel_api, download_excel_api
        params = {'projectId': projectId, 'name': src}
        response = make_request(ctx, 'GET', get_excel_api, params=params)
        if not response.get('data'):
            raise click.ClickException('未找到表格名称为 {}'.format(src))

        id = None
        for i in response['data']:
            if i['name'] == src:
                id = i['id']
                break
        if not id:
            raise click.ClickException('未找到表格名称为 {}'.format(src))
        payload = {'id': id, 'columns': []}
        response = make_request(ctx, 'POST', download_excel_api, json=payload, raw=True)
        response.raise_for_status()
        if dest.endswith(('/', '\\')) or not dest.endswith('.zip'):  # 目录路径则用回原文件名
            path = Path(dest) / '{}.zip'.format(src)
        else:  # 文件路径直接使用用户提供的路径
            path = Path(dest)
        path.parent.mkdir(parents=True, exist_ok=True)  # 确保目录存在
        with path.open('wb') as f:
            f.write(response.content)
        click.echo('已保存到 {}'.format(path.resolve()))
    else:
        from dcs_cli.apis import download_directory_api
        payload = {
            'srcFilePathList': [src],
            'projectId': projectId,
            'zone': zone
        }
        response = make_request(ctx, 'POST', download_directory_api, json=payload)
        for path in response['data']:
            click.echo(path)


@data.command(cls=HelpOnMissingParamCommand)
@click.argument('path')
@click.pass_context
def rm(ctx, path):
    """删除指定文件夹或文件，批量删除逗号隔开，系统文件夹不允许删除"""
    from dcs_cli.utils import make_request
    from dcs_cli.apis import remove_directory_api

    projectId = ctx.obj.get('projectId')
    zone = ctx.obj.get('zone')

    paths = path.split(',')

    current_path = get_current_path()
    paths = [cd_like(current_path, i) for i in paths]

    payload = {'srcFilePathList': paths, 'projectId': projectId, 'zone': zone, 'interfaceType': 'count'}
    response = make_request(ctx, 'POST', remove_directory_api, json=payload)

    if int(response.get('data', 0)):
        if click.confirm('{}个您有权限的文件将被删除，删除后无法再找回，是否确认删除？'.format(response['data']),
                         default=False):
            del payload['interfaceType']
            response = make_request(ctx, 'POST', remove_directory_api, json=payload)
            if response['code']:
                click.echo(response['msg'])
            else:
                click.echo('正在删除{}个文件（含文件夹）'.format(response['data']))
        else:
            click.echo('已取消删除')
    else:
        click.echo('没有找到文件或无权限 {}'.format(path))


def set_current_path(new_path):
    """将当前目录保存到文件"""
    import os
    import pickle

    with CURRENT_DIR_FILE.open('wb') as f:
        pickle.dump(new_path, f)
    os.chmod(CURRENT_DIR_FILE, 0o777)


def get_current_path():
    """从文件中加载当前目录"""
    import pickle
    import platform
    from pathlib import Path

    global CURRENT_DIR_FILE
    if platform.system() == 'Windows':
        CURRENT_DIR_FILE = Path('current_dir.pkl')
    else:
        CURRENT_DIR_FILE = Path('/data/work/.dcs/current_dir.pkl')
    CURRENT_DIR_FILE.parent.mkdir(mode=0o777, exist_ok=True)

    global CURRENT_DIR
    if CURRENT_DIR_FILE.exists():
        with CURRENT_DIR_FILE.open('rb') as f:
            CURRENT_DIR = pickle.load(f)
    return CURRENT_DIR


def cd_like(current_path, target_path):
    """根据给定路径实现类似cd后的路径

    :param current_path: 当前路径
    :param target_path: 绝对路径或相对路径

    >>> cd_like('/home/user/documents', 'projects/project1')
    '/home/user/documents/projects/project1'
    >>> cd_like('/home/user/documents', '../music')
    '/home/user/music'
    >>> cd_like('/home/user/documents', '/var/log')
    '/var/log'
    """
    import os
    from pathlib import Path
    current_path = current_path if isinstance(current_path, Path) else Path(current_path)
    target_path = target_path if isinstance(target_path, Path) else Path(target_path)
    if target_path.is_absolute():  # 绝对路径
        new_path = target_path
    else:  # 相对路径
        new_path = current_path / target_path
    new_path = os.path.normpath(new_path).replace('\\', '/')
    return new_path


def process_exclusive_option(payload, option, key_single, key_list):
    """处理命令行选项添加到payload，单个放在key_single，多个放在key_list

    :param payload: 要修改的payload
    :param option: 要处理的选项
    :param key_single: 单个的key
    :param key_list: 多个的key
    """
    if option:
        option_list = option.split(',')
        if len(option_list) == 1:
            payload[key_single] = option_list[0]
        else:
            payload[key_list] = option_list


def process_coexistent_option(payload, option, key_first, key_second, sep=','):
    """处理命令行选项添加到payload，第一个放在key_first，若有第二个则放在key_second

    :param payload: 要修改的payload
    :param option: 要处理的选项
    :param key_first: 第一个的key
    :param key_second: 第二个的key
    :param sep: 分隔符
    """
    if option:
        option_list = option.split(sep)
        payload[key_first] = option_list[0]
        if len(option_list) == 2:
            payload[key_second] = option_list[1]


def echo_scData_response(ctx, api, params, payload, table=False, human_readable=False, all=False,
                         output=False):
    """请求并输出数据管理接口的数据

    :param ctx: 上下文
    :param api: 请求的API地址
    :param params: Query参数
    :param payload: JSON参数
    :param table: 以表格形式输出
    :param human_readable: 以人类可读格式输出
    :param all: 查询所有数据
    :param output: 输出文件路径
    """
    from dcs_cli.enums import DataTypeEnum
    from dcs_cli.utils import paginated_request, sap_hooks

    def callback(response):
        # 输出数据管理接口的数据
        if table:
            from tabulate import tabulate

            from dcs_cli.utils import bytes_to_human_readable

            field_names = ['文件名称', '文件路径', '文件大小', '创建时间', '实体ID', 'SN', '样本ID']
            content = []
            for i in response['data']['records']:
                name = i.get('name')
                if i['dataType'] == DataTypeEnum.DIRECTORY.value:  # 目录的名字取menuName
                    if output:
                        name = i['menuName']
                    else:
                        name = click.style(i['menuName'], fg='blue')

                if i.get('fileSize'):
                    if i['fileSize'] != '-':
                        if human_readable:
                            i['fileSize'] = bytes_to_human_readable(i['fileSize'])
                        else:
                            i['fileSize'] = i['fileSize'] + 'B'
                else:
                    i['fileSize'] = '-'

                content.append([
                    name,
                    i['menuPath'],
                    i['fileSize'],
                    i['createTime'],
                    i['sampleId'] if i.get('sampleId') else '-',
                    i['snId'] if i.get('snId') else '-',
                    i['sampleNum'] if i.get('sampleNum') else '-'
                ])
            if content:
                content = tabulate(content, field_names, tablefmt='plain')
        else:
            content = []
            for i in response['data']['records']:
                if i['dataType'] == DataTypeEnum.DIRECTORY.value:  # 目录
                    if not output:
                        i['menuName'] = click.style(i['menuName'], fg='blue')
                    content.append(i['menuName'])
                else:
                    content.append(i['name'])
            content = '  '.join(content)

        if not content:
            raise click.ClickException('No such file or directory')

        if output:
            from dcs_cli.utils import create_output
            click.echo(create_output('data', output, content))
        else:
            click.echo(content)

    paginated_request(ctx, api, params, callback, payload, hooks=sap_hooks, all=all, output=output)


def echo_excel_response(response):
    """输出表格接口的数据"""
    from tabulate import tabulate
    field_names = ['表格名称', '创建人', '创建时间']
    tabular_data = []
    for i in response['data']:
        tabular_data.append([
            i.get('name'),
            i.get('createBy'),
            i.get('createTime'),
        ])
    click.echo(tabulate(tabular_data, field_names, tablefmt='plain'))
