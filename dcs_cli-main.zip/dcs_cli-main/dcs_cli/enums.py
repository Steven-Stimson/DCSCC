import enum


class DataTypeEnum(enum.Enum):
    """数据管理文件类型"""
    FILE = '0'
    DIRECTORY = '1'


class ImageSearchTypeEnum(enum.Enum):
    """ 镜像类型
    自定义镜像:1, 公共镜像:2 ,共享镜像:3
    """
    CUSTOM = 1  # 自定义镜像
    PUBLIC = 2  # 公共镜像
    SHARED = 3  # 共享镜像


class MsgStatusTypeEnum(enum.Enum):
    """定义输出的消息类型"""
    SUCCESS = 'success'
    WARNING = 'warning'
    ERROR = 'error'
    INFO = 'info'


class TaskStatusEnum(enum.Enum):
    """云平台任务状态"""
    waiting = '待分析'
    running = '运行中'
    completed = '完成'
    error = '失败'
    pause = '暂停'
    cancel = '取消'
    # deleted = '已删除'
    warning = '异常'
    # invalid = '已失效'
    store_error = '入仓失败'
    completed_no_store = '完成（无文件入仓）'
    storeing = '入仓中'
    Submitted = '已提交'


AnalysisOfflineTaskStatusEnum = dict(
    invalid='已失效',
    warning='异常',
    waiting='待分析',
    running='运行中',
    pause='暂停',
    error='失败',
    cancel='取消',
    completed='完成',
    undefined='',
    pending='待提交',
    aborted='取消',
    failed='失败',
    upload_failed='上传失败',
    submitted='已提交',
)  # 个性分析离线任务任务状态


class TaskTypeEnum(enum.Enum):
    """任务类型"""
    workflow = 'w'
    shell = 's'
    analysis = 'a'


class NotebookSettingEnum(enum.Enum):
    """参数配置"""
    NO = '0'  # 无参数
    ADD = '1'  # 添加参数
    FILE = '2'  # 参数文件配置


class WorkflowExecutionStatus(enum.Enum):
    """Workflow任务运行日志状态"""
    Done = '完成'
    Failed = '失败'
    Running = '运行中'
    Aborted = '暂停'


class DataDelFlagEnum(enum.IntEnum):
    """数据被删除的状态"""
    EXIST = 0  # 存在


class DataStatusEnum(enum.IntEnum):
    """数据状态"""
    EXIST = 0  # 正常
    DELETED = 1  # 已删除


class DataSameTypeEnum(enum.Enum):
    """文件和文件夹重名时显示哪个"""
    FILE = 'file'
    DIR = 'dir'


class DataPreciseQueryEnum(enum.IntEnum):
    """是否精准查询"""
    NO = 0  # 模糊
    YES = 1  # 精准
