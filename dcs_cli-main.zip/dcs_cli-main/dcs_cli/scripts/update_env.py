import os
from pathlib import Path

import requests
from dotenv import load_dotenv, dotenv_values, set_key

dotenv_path = Path('../../.env')
if not dotenv_path.exists():
    raise Exception('.env不存在')

load_dotenv(override=True)

response = requests.post(
    'https://test-cloud.stomics.tech/api/user/auth/loginApiUser',
    data={'username': os.getenv('USERNAME'), 'password': os.getenv('PASSWORD')}
)
DCS_X_ACCESS_TOKEN = response.json()['data']

config = dotenv_values()
config['DCS_X_ACCESS_TOKEN'] = DCS_X_ACCESS_TOKEN
print(config)
for key, value in config.items():
    set_key(dotenv_path, key, value)
