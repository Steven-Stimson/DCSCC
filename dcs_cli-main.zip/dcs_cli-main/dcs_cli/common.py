from dcs_cli.enums import MsgStatusTypeEnum

# 使用all的时候使用查询的条数
MAX_DIRECT_PRINT_PAGESIZE = 2000  # 直接打印的阈值
MAX_OUTPUT_PAGESIZE = 10000  # 最多返回1W条数据

URL_DICT = {
    'image_list': '/stereonote/api/dcs/image/list',  # 查询镜像列表
    'image_info': '/stereonote/api/dcs/image/info',  # 查询指定名称镜像的详细信息
    'image_pubilc_info': '/api/publib/dcsImg/detail',  # 查询指定名称镜像的详细信息
    'app_bill': '/api/billing/dcsSpecification/listRecord',  # 查询计费信息
    'app_bill_discount': '/api/billing/dcsDiscount/listRecord',  # 查询计费信息折扣信息
    'app_list': '/workflow/api/v1/workflows/',  # 查询流程
    'app_info': '/workflow/api/v1/workflows/findWorkflowDetail/',  # 查询流程详情
    'app_public_info': '/api/publib/dcsApp/workflow/detail/',  # 查询流程详情
    'app_public_list': '/api/publib/dcsRes/search',  # 查询公共库流程
    'app_push': '/workflow/api/v1/workflows/load/',  # 注册流程
    'app_pull': '/workflow/api/v1/workflows/exportWorkflowByParam/',  # 拉取项目中的工具代码到终端中
    'app_update_list': '/workflow/api/v1/workflows/',  # 查询更新项目内工作流
    'app_update': '/workflow/api/v1/workflows/BatchRefresh/',  # 更新更新项目内工作流
    'app_wld_validate': '/workflow/api/v1/workflows/wdlValidate/',  # 校验指定路径下的脚本语法正确性
    'app_zip_validate': '/workflow/api/v1/workflows/validate/',
    'app_copy': '/api/publib/dcsApp/copy',  # 从公共库复制到项目中
    'app_get_user_perm': '/api/user/dcsSubjectBizPerm/getUserPermTree',  # 查询用户权限信息
    'app_detail_get_public_app': '/api/publib/dcsApp/listApp',  # 查询公共库app
    'app_detail_get_image': '/workflow/api/v1/workflows/getImages',  # 查询images
    'app_detail_get_public_image': '/api/publib/dcsApp/pageImage',  # 查询images
    'app_get_project_info': '/api/project/dcsProject/pageRecord',  # 查询项目信息
}


def echo_info(msg, msg_status=None):
    from rich.console import Console
    from rich.theme import Theme
    # 初始化带主题的 Console
    theme = Theme({
        "success": "green bold",
        "warning": "yellow bold",
        "error": "red bold",
        "info": "blue bold"
    })
    console = Console(theme=theme)
    if msg_status == MsgStatusTypeEnum.WARNING:
        console.print(msg, style="warning")
    elif msg_status == MsgStatusTypeEnum.ERROR:
        console.print(msg, style="error")
    elif msg_status == MsgStatusTypeEnum.INFO:
        console.print(msg, style="info")
    elif msg_status == MsgStatusTypeEnum.SUCCESS:
        console.print(msg, style="success")
    else:
        console.print(msg)

    return msg
