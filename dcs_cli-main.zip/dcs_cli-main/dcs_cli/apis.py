# 云平台接口
get_metadata_api = 'api/data/file/meta/query'  # 获取数据管理文件（黄世爵）
get_excel_api = 'api/data/dcsExcel/excelList/cli'  # 获取表格列表（李佳）
upload_excel_api = 'api/data/dcsExcel/addExcelOrContent'  # 上传表格（李佳）
download_excel_api = 'api/data/dcsExcel/downloadCsvSync/cli'  # 下载表格（李佳）
upload_directory_api = 'api/data/file/uploadDirectory'  # 上传目录（廖开威）
download_directory_api = 'api/data/file/downloadDirectory'  # 下载目录（廖开威）
remove_directory_api = 'api/data/file/removeDirectory'  # 删除目录（廖开威）
get_task_api = 'api/task/dcsTask/userPageTasks'  # 任务列表（别君羊）
get_billing_api = 'api/billing/dcsBillingProject/listRecord'  # 校验余额（吴宝辉）
get_expense_api = 'api/billing/dcsSpecification/listRecord'  # 获取流程费用（吴宝辉）
save_workflow_api = 'api/task/dcsTask/saveBatchWorkflow'  # 批量运行Workflow任务（别君羊）
start_task_api = 'api/task/dcsTask/startTasks'  # 启动Workflow任务（方小春）
cancel_task_api = 'api/task/dcsTask/cancelTasks'  # 取消Workflow任务（方小春）
delete_task_api = 'api/task/dcsTask/deleteTasks'  # 删除Workflow任务（方小春）
get_project_api = 'api/project/dcsProject/getDetailByCode'  # 项目信息（别君羊）
task_detail_api = 'api/task/dcsTask/getUserTaskById'  # 任务详情（别君羊）
task_ouput_api = 'api/task/dcsTask/getOldTaskOutput'  # 任务输出（别君羊）
job_step_api = 'api/task/bioc/getJobStepInfo'  # 任务步骤（别君羊）
job_step_output_api = 'api/task/bioc/queryJobStepOutput'  # 任务步骤输出（别君羊）
job_intermediate_api = 'api/task/bioc/getFiles'  # 任务中间文件（别君羊）

# 个性分析接口
get_offline_api = 'stereonote/api/dcs/offline/page'  # 个性分析离线任务列表（罗赤锋）
save_offline_api = 'stereonote/api/dcs/task/run'  # 运行个性分析离线任务（罗赤锋）
resume_offline_api = 'stereonote/api/dcs/offline/subTask/resume'  # 启动个性分析离线任务（罗赤锋）
get_resource_api = 'stereonote/api/workspace/get/resource/cfg'  # 获取计算资源（罗赤锋）
offline_content_api = 'stereonote/api/ipynb/content'  # 个性分析离线任务脚本（罗赤锋）
cancel_offline_api = 'stereonote/api/dcs/task/batchCancel'  # 取消个性分析离线任务（罗赤锋）
delete_offline_api = 'stereonote/api/dcs/task/batchDelete'  # 删除个性分析离线任务（罗赤锋）

# Workflow接口
get_workflow_api = 'workflow/api/v1/workflows/findWorkflowDetail/'  # 通过名称获取项目流程（方小春）
