from dcs_cli.common import MAX_DIRECT_PRINT_PAGESIZE
from dcs_cli.common import MAX_OUTPUT_PAGESIZE
from dcs_cli.common import URL_DICT

mock_image_list = {
    'code': 0,
    'data': {
        'page': 1, 'page_size': 10, 'record': [
            {'base_image_id': '99dcfaa45d8a48dc81bb5aec0900e7c9', 'base_image_type': '1', 'build_type': 'bash',
             'create_time': '2023-11-17 10:46:31', 'file_url': None, 'image_bash': 'ls ', 'image_desc': None,
             'image_env': '[]',
             'image_id': '03f4f1aa907e4b03945d699d16f10310', 'image_name': 'scATAC-seq analysis pipeline v3.0.2',
             'image_size': '4609314677', 'image_tags': '', 'image_toolkit': '{"latest": {"R": [], "Python3": []}}',
             'image_url': 'harbor.cngb.org/stereonote_hpc/mawen3_99dcfaa45d8a48dc81bb5aec0900e7c9_private',
             'language': 'R,python', 'official_tag': None, 'root_type': '1', 'share_status': '0', 'tools': None,
             'username': 'mawen3', 'version': 'latest'},
            {'base_image_id': None, 'base_image_type': '1', 'build_type': None, 'create_time': '2022-12-08 10:14:22',
             'file_url': None, 'image_bash': None,
             'image_desc': 'stereonote image with basic R & python essentials without conda', 'image_env': None,
             'image_id': '093dcf0c8ec8fb8f1b_qy', 'image_name': 'stereonote_cuda_jupyterhub',
             'image_size': '4508884975',
             'image_tags': 'jupyter', 'image_toolkit': None,
             'image_url': 'harbor.cngb.org/stereonote/stereonote_cuda_jupyterhub', 'language': 'R,python',
             'official_tag': None,
             'root_type': '1', 'share_status': '0',
             'tools': '{"R": [{"name": "BiocManager", "version": "1.30.23"}, {"name": "IRdisplay", "version": "1.1"}, '
                      '{"name": "IRkernel", "version": "1.3.2"}, {"name": "KernSmooth", "version": "2.23-20"},'
                      ' {"name": "spatial", "version": "7.3-16"}, {"name": "splines", "version": "4.3.0"}],'
                      ' "ENV": [{"name": "GCC", "version": "4.8.5"}]}',
             'username': 'system', 'version': 'latest'},
            {'base_image_id': None, 'base_image_type': '1', 'build_type': None, 'create_time': '2022-12-08 10:14:22',
             'file_url': None, 'image_bash': None,
             'image_desc': 'stereonote image with basic R & python essentials without conda', 'image_env': None,
             'image_id': '093dcf0c8ec8fb8f1b53a56190b68e0374ac4511fae15d88a7bff3e63255a8c8',
             'image_name': 'Python 3 and R image', 'image_size': '1260045831', 'image_tags': 'jupyter',
             'image_toolkit': None,
             'image_url': 'harbor.cngb.org/stereonote/stereonote_non_conda_git', 'language': 'R,python',
             'official_tag': None,
             'root_type': '1', 'share_status': '0',
             'tools': '{"R": [{"name": "askpass", "version": "1.1"}]}',
             'username': 'system', 'version': 'latest'}
        ], 'total': 3
    }
}

mock_image_list_by_name = {
    'code': 0,
    'data': {
        'page': 1, 'page_size': 10, 'record': [
            {'base_image_id': '99dcfaa45d8a48dc81bb5aec0900e7c9', 'base_image_type': '1', 'build_type': 'bash',
             'create_time': '2023-11-17 10:46:31', 'file_url': None, 'image_bash': 'ls ', 'image_desc': None,
             'image_env': '[]',
             'image_id': '03f4f1aa907e4b03945d699d16f10310', 'image_name': 'test analysis pipeline v3.0.2',
             'image_size': '4609314677', 'image_tags': '', 'image_toolkit': '{"latest": {"R": [], "Python3": []}}',
             'image_url': 'harbor.cngb.org/stereonote_hpc/mawen3_99dcfaa45d8a48dc81bb5aec0900e7c9_private',
             'language': 'R,python', 'official_tag': None, 'root_type': '1', 'share_status': '0', 'tools': None,
             'username': 'mawen3', 'version': 'latest'},
        ], 'total': 1
    }
}

mock_image_list_by_all_demo_1 = {
    'code': 0,
    'data': {
        'page': 1, 'page_size': 10,
        'record': [
                      {'base_image_id': '99dcfaa45d8a48dc81bb5aec0900e7c9',
                       'base_image_type': '1', 'build_type': 'bash',
                       'create_time': '2023-11-17 10:46:31', 'file_url': None,
                       'image_bash': 'ls ', 'image_desc': None,
                       'image_env': '[]',
                       'image_id': '03f4f1aa907e4b03945d699d16f10310',
                       'image_name': 'test analysis pipeline v3.0.2',
                       'image_size': '4609314677', 'image_tags': '',
                       'image_toolkit': '{"latest": {"R": [], "Python3": []}}',
                       'image_url': 'harbor.cngb.org/stereonote_hpc/mawen3_99dcfaa45d8a48dc81bb5aec0900e7c9_private',
                       'language': 'R,python', 'official_tag': None, 'root_type': '1',
                       'share_status': '0', 'tools': None,
                       'username': 'mawen3', 'version': 'latest'},
                  ] * 10, 'total': 13
    }
}

mock_image_list_by_all_demo_2 = {
    'code': 0,
    'data': {
        'page': 1, 'page_size': 10,
        'record': [
                      {'base_image_id': '99dcfaa45d8a48dc81bb5aec0900e7c9',
                       'base_image_type': '1', 'build_type': 'bash',
                       'create_time': '2023-11-17 10:46:31', 'file_url': None,
                       'image_bash': 'ls ', 'image_desc': None,
                       'image_env': '[]',
                       'image_id': '03f4f1aa907e4b03945d699d16f10310',
                       'image_name': 'test analysis pipeline v3.0.2',
                       'image_size': '4609314677', 'image_tags': '',
                       'image_toolkit': '{"latest": {"R": [], "Python3": []}}',
                       'image_url': 'harbor.cngb.org/stereonote_hpc/mawen3_99dcfaa45d8a48dc81bb5aec0900e7c9_private',
                       'language': 'R,python', 'official_tag': None, 'root_type': '1',
                       'share_status': '0', 'tools': None,
                       'username': 'mawen3', 'version': 'latest'},
                  ] * 13, 'total': 13
    }
}

mock_image_list_by_all_max_direct_print = {
    'code': 0,
    'data': {
        'page': 1, 'page_size': MAX_DIRECT_PRINT_PAGESIZE,
        'record': [
                      {'base_image_id': '99dcfaa45d8a48dc81bb5aec0900e7c9',
                       'base_image_type': '1', 'build_type': 'bash',
                       'create_time': '2023-11-17 10:46:31', 'file_url': None,
                       'image_bash': 'ls ', 'image_desc': None,
                       'image_env': '[]',
                       'image_id': '03f4f1aa907e4b03945d699d16f10310',
                       'image_name': 'test analysis pipeline v3.0.2',
                       'image_size': '4609314677', 'image_tags': '',
                       'image_toolkit': '{"latest": {"R": [], "Python3": []}}',
                       'image_url': 'harbor.cngb.org/stereonote_hpc/mawen3_99dcfaa45d8a48dc81bb5aec0900e7c9_private',
                       'language': 'R,python', 'official_tag': None, 'root_type': '1',
                       'share_status': '0', 'tools': None,
                       'username': 'mawen3', 'version': 'latest'},
                  ] * 1888,
        'total': 1888
    }
}

mock_image_list_by_all_max_direct_print_ii = {
    'code': 0,
    'data': {
        'page': 1, 'page_size': MAX_DIRECT_PRINT_PAGESIZE,
        'record': [
                      {'base_image_id': '99dcfaa45d8a48dc81bb5aec0900e7c9',
                       'base_image_type': '1', 'build_type': 'bash',
                       'create_time': '2023-11-17 10:46:31', 'file_url': None,
                       'image_bash': 'ls ', 'image_desc': None,
                       'image_env': '[]',
                       'image_id': '03f4f1aa907e4b03945d699d16f10310',
                       'image_name': 'test analysis pipeline v3.0.2',
                       'image_size': '4609314677', 'image_tags': '',
                       'image_toolkit': '{"latest": {"R": [], "Python3": []}}',
                       'image_url': 'harbor.cngb.org/stereonote_hpc/mawen3_99dcfaa45d8a48dc81bb5aec0900e7c9_private',
                       'language': 'R,python', 'official_tag': None, 'root_type': '1',
                       'share_status': '0', 'tools': None,
                       'username': 'mawen3', 'version': 'latest'},
                  ] * MAX_DIRECT_PRINT_PAGESIZE,
        'total': 2088
    }
}

mock_image_list_by_all_demo_max_output = {
    'code': 0,
    'data': {
        'page': 1, 'page_size': MAX_OUTPUT_PAGESIZE,
        'record': [
                      {'base_image_id': '99dcfaa45d8a48dc81bb5aec0900e7c9',
                       'base_image_type': '1', 'build_type': 'bash',
                       'create_time': '2023-11-17 10:46:31', 'file_url': None,
                       'image_bash': 'ls ', 'image_desc': None,
                       'image_env': '[]',
                       'image_id': '03f4f1aa907e4b03945d699d16f10310',
                       'image_name': 'test analysis pipeline v3.0.2',
                       'image_size': '4609314677', 'image_tags': '',
                       'image_toolkit': '{"latest": {"R": [], "Python3": []}}',
                       'image_url': 'harbor.cngb.org/stereonote_hpc/mawen3_99dcfaa45d8a48dc81bb5aec0900e7c9_private',
                       'language': 'R,python', 'official_tag': None, 'root_type': '1',
                       'share_status': '0', 'tools': None,
                       'username': 'mawen3', 'version': 'latest'},
                  ] * 2003, 'total': 2003
    }
}

mock_image_list_by_url = {
    'code': 0,
    'data': {
        'page': 1, 'page_size': 10, 'record': [
            {'base_image_id': '99dcfaa45d8a48dc81bb5aec0900e7c9', 'base_image_type': '1', 'build_type': 'bash',
             'create_time': '2023-11-17 10:46:31', 'file_url': None, 'image_bash': 'ls ', 'image_desc': None,
             'image_env': '[]', 'more': {'url': '168168'},
             'image_id': '03f4f1aa907e4b03945d699d16f10310', 'image_name': 'test analysis pipeline v3.0.2',
             'image_size': '4609314677', 'image_tags': '', 'image_toolkit': '{"latest": {"R": [], "Python3": []}}',
             'image_url': 'test_url',
             'language': 'R,python', 'official_tag': None, 'root_type': '1', 'share_status': '0', 'tools': None,
             'username': 'mawen3', 'version': 'latest'},
        ], 'total': 1
    }
}

mock_image_list_by_public = {
    "code": 0,
    "msg": "成功",
    "data": {
        "records": [
            {
                "did": "GCkPapUB5SPxi-7IQMUq",
                "oid": "idqYvn0vzKgZJ",
                "rawId": "426",
                "resType": "img",
                "labels": [
                    "img"
                ],
                "name": "new-test_image",
                "tags": [
                    "Metabolomics",
                    "Proteomics",
                    "Single-cell omics",
                    "Microbiomics"
                ],
                "more": {
                    'url': '1681681864864864'
                },
                "fullTags": [
                    "Omics:Metabolomics",
                    "Omics:Proteomics",
                    "Omics:Microbiomics",
                    "Omics:Single-cell omics"
                ],
                "intro": "测试镜像是否还同步",
                "resDesc": None,
                "createdBy": "huangxingxin",
                "resCreatedAt": "1737540494000",
                "resUpdatedAt": "1737540494000",
                "updatedBy": "huangxingxin",
                "updatedById": "user_b59088297dcd7e432dd3fd41223a7901",
                "createdById": "user_b59088297dcd7e432dd3fd41223a7901",
                "isSto": 0,
                "subPlanType": -1,
                "zoneToStatus": {
                    "st": "succeed",
                    "qd": "succeed",
                    "sz_ztron": "succeed",
                    "sz": "succeed",
                    "cq": "succeed",
                    "ali": "succeed"
                },
                "srcZone": "sz",
                "srcProjectId": "",
                "starsScore": 0,
                "numCommentsVotes": "0",
                "numGoods": "0",
                "numRef": "0",
                "numClicks": "0",
                "datasetType": 11,
                "version": "latest",
                "coverKey": "",
                "progEnv": 1,
                "billingType": None,
                "originalPrice": None,
                "deleted": 0,
                "myFeedback": None,
                "myNumCp": 0,
                "highlightFields": {},
                "score": "NaN",
                "coverUrl": None
            }],
        "total": 1,
    }
}

mock_build_list_params = [
    # ----------------------------
    # public=True 的测试用例
    # ----------------------------
    # 1. 公共库查询，提供 url
    (
        'P1600787473158537217',
        "https://test-cloud.stomics.tech/",
        True,
        "image.url",
        None,
        "https://test-cloud.stomics.tech/api/customer/pubLib/res/search",
        {
            'page': 1,
            'limit': 10,
            'types': 'img',
            'in': 'url',
            'kw': 'image.url',
            'exc': True
        }
    ),
    # 2. 公共库查询，提供 name
    (
        'P1600787473158537217',
        "https://test-cloud.stomics.tech/",
        True,
        None,
        "test_image",
        "https://test-cloud.stomics.tech/api/customer/pubLib/res/search",
        {
            'page': 1,
            'limit': 10,
            'types': 'img',
            'in': 'name',
            'kw': 'test_image'
        }
    ),
    # 3. 公共库查询，无 url 和 name
    (
        'P1600787473158537217',
        "https://test-cloud.stomics.tech/",
        True,
        None,
        None,
        "https://test-cloud.stomics.tech/api/customer/pubLib/res/search",
        {
            'page': 1,
            'limit': 10,
            'types': 'img'
        }
    ),
    # 4. 公共库查询，同时提供 url 和 name（url 优先级更高）
    (
        'P1600787473158537217',
        "https://test-cloud.stomics.tech/",
        True,
        "image.url",
        "test_image",
        "https://test-cloud.stomics.tech/api/customer/pubLib/res/search",
        {
            'page': 1,
            'limit': 10,
            'types': 'img',
            'in': 'url',
            'kw': 'image.url',
            'exc': True
        }
    ),

    # ----------------------------
    # public=False 的测试用例
    # ----------------------------
    # 5. 私有库查询，提供name和url
    (
        "P1600787473158537217",
        "https://test-cloud.stomics.tech/",
        False,
        "image.url",
        "test_image",
        URL_DICT['image_list'],
        {
            'page': 1,
            'page_size': 10,
            'project_id': 'P1600787473158537217',
            'image_name': 'test_image',
            'image_url': 'image.url'
        }
    ),
    # 6. 私有库查询，仅提供name
    (
        "P1600787473158537217",
        "https://test-cloud.stomics.tech/",
        False,
        None,
        "test_image",
        URL_DICT['image_list'],
        {
            'page': 1,
            'page_size': 10,
            'project_id': 'P1600787473158537217',
            'image_name': 'test_image'
        }
    ),
    # 7. 私有库查询，仅提供url
    (
        "P1600787473158537217",
        "https://test-cloud.stomics.tech/",
        False,
        "image.url",
        None,
        URL_DICT['image_list'],
        {
            'page': 1,
            'page_size': 10,
            'project_id': 'P1600787473158537217',
            'image_url': 'image.url'
        }
    )
]

mock_prompt_update_data = {'1001': '流程A', '1002': '流程B', '1003': '流程C'}

mock_get_update_ids = [
    # 正常输入单个序号
    ("1", ['1001']),
    ("1,1", ['1001']),
    # 正常输入多个序号
    ("1,3", ['1001', '1003']),
    # 带空格输入
    (" 2 , 1 ", ['1002', '1001']),
    # 无效输入后接有效输入
    (["invalid", "2"], ['1002']),
    # 全量更新指令
    ("all", ['1001', '1002', '1003'])
]

mock_workflow_list = [
    {'name': 'workflow1'},
    {'name': 'workflow2'},
    {'name': 'workflow3'}
]

P20250328172629834_name_list = [
    'zhenbin_test_20250309', 'stereonote-code-basic', 'Stomics analysis image',
    'scRNA-seq analysis pipeline v3.1.5', 'scATAC-seq analysis pipeline v3.0.2',
    'Stomics analysis image', 'Python 3 and R image', 'stereonote_cuda_jupyterhub',
    'stereonote-vscode', 'code-server', 'stereonote', 'saw-05.5.3', 'saw-06.0.2', 'debian-7',
    'ubuntu-23.10', 'centos-7']

public_name_list = [
    'SAW_v5.6.0_fix',
    'sif_busybox',
    'test_docker_centos',
    'r包和python包的混合镜像',
    'test-centos',
    'testzhuzhejun',
    'quanying镜像',
    'workflow测试镜像',
    'flask推送测试',
    '离线鉴权测试',
    'python4456',
    '离线230202',
    '离线pub',
    'demo-R-20230206666',
]

mock_project_app_list_by_all_demo_1 = {
    "count": 13,
    "index": 0,
    "workflow_list": [
                         {
                             "project": "P1871461072416366593",
                             "origin_project": None,
                             "pre_tag": "0",
                             "is_edit": 0,
                             "origin_type": None,
                             "type": "private",
                             "id": "677662d373633b2c3fd330c1",
                             "subscribe_content": {},
                             "version_list": [
                                 {
                                     "avatar_source": None,
                                     "origin_name": None,
                                     "tag": "",
                                     "toolbox_id_list": [],
                                     "images": [
                                         "public-library/xueqinwen_20393bf7b3c74636ab472a7d5fb277ad_public:latest",
                                         "stereonote_hpc/xueqinwen_8ee86cfa16754f1793f46e97cd554ad0_private:latest"
                                     ],
                                     "workflowid": "1874756667516190721",
                                     "origin_project": None,
                                     "pre_tag": "0",
                                     "old_is_public_wdl": None,
                                     "inside": 0,
                                     "is_edit": 0,
                                     "origin_type": None,
                                     "is_public_wdl": "yes",
                                     "workflow_tag": "",
                                     "input_desc": {
                                         "LUSH2_build_index.ReferenceName": {
                                             "param_des": ""
                                         },
                                         "LUSH2_build_index.ReferenceFasta": {
                                             "param_des": ""
                                         },
                                         "LUSH2_build_index.KnownSiteVcfs": {
                                             "param_des": ""
                                         },
                                         "LUSH2_build_index.Species": {
                                             "param_des": ""
                                         }
                                     },
                                     "outputs": {
                                         "LUSH2_build_index.ref": "File"
                                     },
                                     "is_draft": "no",
                                     "inputs": {
                                         "LUSH2_build_index.ReferenceName": "String",
                                         "LUSH2_build_index.ReferenceFasta": "File? (optional)",
                                         "LUSH2_build_index.KnownSiteVcfs": "Array[File]? (optional)",
                                         "LUSH2_build_index.Species": "String"
                                     },
                                     "is_subscribe": "no",
                                     "official_workflow": "yes",
                                     "update_at": "2025-01-02T17:56:35.835000",
                                     "description": "",
                                     "status": "checked",
                                     "origin_id": None,
                                     "version": "1.0.0",
                                     "is_sys": None,
                                     "name": "LUSH2_build_index(1)",
                                     "official_tag": "LUSH2_build_index"
                                 }
                             ],
                             "is_subscribe": "no",
                             "billing_type": None,
                             "update_time": "2025-01-02 17:56:35",
                             "update_name": "",
                             "publish_time": None,
                             "origin_id": None,
                             "create_at": "2025-01-02T17:56:35.835000",
                             "publish_name": None,
                             "is_sys": None,
                             "user_name": "luya",
                             "old_publish_time": None,
                             "publish_status": 0,
                             "subscribe_run_count": None,
                             "name": "LUSH2_build_index(1)",
                             "install_number": 0
                         }
                     ] * 10
}

# response['count'] if not public else response['data']['total']
mock_project_app_list_by_all_demo = {
    "count": 1,
    "index": 0,
    "workflow_list": [
        {
            "project": "P1871461072416366593",
            "origin_project": None,
            "pre_tag": "0",
            "is_edit": 0,
            "origin_type": None,
            "type": "private",
            "id": "677662d373633b2c3fd330c1",
            "subscribe_content": {},
            "version_list": [
                {
                    "avatar_source": None,
                    "origin_name": None,
                    "tag": "",
                    "toolbox_id_list": [],
                    "images": [
                        "public-library/xueqinwen_20393bf7b3c74636ab472a7d5fb277ad_public:latest",
                        "stereonote_hpc/xueqinwen_8ee86cfa16754f1793f46e97cd554ad0_private:latest"
                    ],
                    "workflowid": "1874756667516190721",
                    "origin_project": None,
                    "pre_tag": "0",
                    "old_is_public_wdl": None,
                    "inside": 0,
                    "is_edit": 0,
                    "origin_type": None,
                    "is_public_wdl": "yes",
                    "workflow_tag": "",
                    "input_desc": {
                        "LUSH2_build_index.ReferenceName": {
                            "param_des": ""
                        },
                        "LUSH2_build_index.ReferenceFasta": {
                            "param_des": ""
                        },
                        "LUSH2_build_index.KnownSiteVcfs": {
                            "param_des": ""
                        },
                        "LUSH2_build_index.Species": {
                            "param_des": ""
                        }
                    },
                    "outputs": {
                        "LUSH2_build_index.ref": "File"
                    },
                    "is_draft": "no",
                    "inputs": {
                        "LUSH2_build_index.ReferenceName": "String",
                        "LUSH2_build_index.ReferenceFasta": "File? (optional)",
                        "LUSH2_build_index.KnownSiteVcfs": "Array[File]? (optional)",
                        "LUSH2_build_index.Species": "String"
                    },
                    "is_subscribe": "no",
                    "official_workflow": "yes",
                    "update_at": "2025-01-02T17:56:35.835000",
                    "description": "",
                    "status": "checked",
                    "origin_id": None,
                    "version": "1.0.0",
                    "is_sys": None,
                    "name": "LUSH2_build_index(1)",
                    "official_tag": "LUSH2_build_index"
                }
            ],
            "is_subscribe": "no",
            "billing_type": None,
            "update_time": "2025-01-02 17:56:35",
            "update_name": "",
            "publish_time": None,
            "origin_id": None,
            "create_at": "2025-01-02T17:56:35.835000",
            "publish_name": None,
            "is_sys": None,
            "user_name": "luya",
            "old_publish_time": None,
            "publish_status": 0,
            "subscribe_run_count": None,
            "name": "LUSH2_build_index(1)",
            "install_number": 0
        }
    ]
}

mock_project_app_list_by_all_demo_2 = {
    "count": 13,
    "index": 0,
    "workflow_list": [
                         {
                             "project": "P1871461072416366593",
                             "origin_project": None,
                             "pre_tag": "0",
                             "is_edit": 0,
                             "origin_type": None,
                             "type": "private",
                             "id": "677662d373633b2c3fd330c1",
                             "subscribe_content": {},
                             "version_list": [
                                 {
                                     "avatar_source": None,
                                     "origin_name": None,
                                     "tag": "",
                                     "toolbox_id_list": [],
                                     "images": [
                                         "public-library/xueqinwen_20393bf7b3c74636ab472a7d5fb277ad_public:latest",
                                         "stereonote_hpc/xueqinwen_8ee86cfa16754f1793f46e97cd554ad0_private:latest"
                                     ],
                                     "workflowid": "1874756667516190721",
                                     "origin_project": None,
                                     "pre_tag": "0",
                                     "old_is_public_wdl": None,
                                     "inside": 0,
                                     "is_edit": 0,
                                     "origin_type": None,
                                     "is_public_wdl": "yes",
                                     "workflow_tag": "",
                                     "input_desc": {
                                         "LUSH2_build_index.ReferenceName": {
                                             "param_des": ""
                                         },
                                         "LUSH2_build_index.ReferenceFasta": {
                                             "param_des": ""
                                         },
                                         "LUSH2_build_index.KnownSiteVcfs": {
                                             "param_des": ""
                                         },
                                         "LUSH2_build_index.Species": {
                                             "param_des": ""
                                         }
                                     },
                                     "outputs": {
                                         "LUSH2_build_index.ref": "File"
                                     },
                                     "is_draft": "no",
                                     "inputs": {
                                         "LUSH2_build_index.ReferenceName": "String",
                                         "LUSH2_build_index.ReferenceFasta": "File? (optional)",
                                         "LUSH2_build_index.KnownSiteVcfs": "Array[File]? (optional)",
                                         "LUSH2_build_index.Species": "String"
                                     },
                                     "is_subscribe": "no",
                                     "official_workflow": "yes",
                                     "update_at": "2025-01-02T17:56:35.835000",
                                     "description": "",
                                     "status": "checked",
                                     "origin_id": None,
                                     "version": "1.0.0",
                                     "is_sys": None,
                                     "name": "LUSH2_build_index(1)",
                                     "official_tag": "LUSH2_build_index"
                                 }
                             ],
                             "is_subscribe": "no",
                             "billing_type": None,
                             "update_time": "2025-01-02 17:56:35",
                             "update_name": "",
                             "publish_time": None,
                             "origin_id": None,
                             "create_at": "2025-01-02T17:56:35.835000",
                             "publish_name": None,
                             "is_sys": None,
                             "user_name": "luya",
                             "old_publish_time": None,
                             "publish_status": 0,
                             "subscribe_run_count": None,
                             "name": "LUSH2_build_index(1)",
                             "install_number": 0
                         }
                     ] * 13
}

mock_project_app_list_by_all_max_output = {
    "count": 2003,
    "index": 0,
    "workflow_list": [
                         {
                             "project": "P1871461072416366593",
                             "origin_project": None,
                             "pre_tag": "0",
                             "is_edit": 0,
                             "origin_type": None,
                             "type": "private",
                             "id": "677662d373633b2c3fd330c1",
                             "subscribe_content": {},
                             "version_list": [
                                 {
                                     "avatar_source": None,
                                     "origin_name": None,
                                     "tag": "",
                                     "toolbox_id_list": [],
                                     "images": [
                                         "public-library/xueqinwen_20393bf7b3c74636ab472a7d5fb277ad_public:latest",
                                         "stereonote_hpc/xueqinwen_8ee86cfa16754f1793f46e97cd554ad0_private:latest"
                                     ],
                                     "workflowid": "1874756667516190721",
                                     "origin_project": None,
                                     "pre_tag": "0",
                                     "old_is_public_wdl": None,
                                     "inside": 0,
                                     "is_edit": 0,
                                     "origin_type": None,
                                     "is_public_wdl": "yes",
                                     "workflow_tag": "",
                                     "input_desc": {
                                         "LUSH2_build_index.ReferenceName": {
                                             "param_des": ""
                                         },
                                         "LUSH2_build_index.ReferenceFasta": {
                                             "param_des": ""
                                         },
                                         "LUSH2_build_index.KnownSiteVcfs": {
                                             "param_des": ""
                                         },
                                         "LUSH2_build_index.Species": {
                                             "param_des": ""
                                         }
                                     },
                                     "outputs": {
                                         "LUSH2_build_index.ref": "File"
                                     },
                                     "is_draft": "no",
                                     "inputs": {
                                         "LUSH2_build_index.ReferenceName": "String",
                                         "LUSH2_build_index.ReferenceFasta": "File? (optional)",
                                         "LUSH2_build_index.KnownSiteVcfs": "Array[File]? (optional)",
                                         "LUSH2_build_index.Species": "String"
                                     },
                                     "is_subscribe": "no",
                                     "official_workflow": "yes",
                                     "update_at": "2025-01-02T17:56:35.835000",
                                     "description": "",
                                     "status": "checked",
                                     "origin_id": None,
                                     "version": "1.0.0",
                                     "is_sys": None,
                                     "name": "LUSH2_build_index(1)",
                                     "official_tag": "LUSH2_build_index"
                                 }
                             ],
                             "is_subscribe": "no",
                             "billing_type": None,
                             "update_time": "2025-01-02 17:56:35",
                             "update_name": "",
                             "publish_time": None,
                             "origin_id": None,
                             "create_at": "2025-01-02T17:56:35.835000",
                             "publish_name": None,
                             "is_sys": None,
                             "user_name": "luya",
                             "old_publish_time": None,
                             "publish_status": 0,
                             "subscribe_run_count": None,
                             "name": "LUSH2_build_index(1)",
                             "install_number": 0
                         }
                     ] * 2003
}

mock_project_app_list_by_all_demo_3 = {
    "count": 1888,
    "index": 0,
    "workflow_list": [
                         {
                             "project": "P1871461072416366593",
                             "origin_project": None,
                             "pre_tag": "0",
                             "is_edit": 0,
                             "origin_type": None,
                             "type": "private",
                             "id": "677662d373633b2c3fd330c1",
                             "subscribe_content": {},
                             "version_list": [
                                 {
                                     "avatar_source": None,
                                     "origin_name": None,
                                     "tag": "",
                                     "toolbox_id_list": [],
                                     "images": [
                                         "public-library/xueqinwen_20393bf7b3c74636ab472a7d5fb277ad_public:latest",
                                         "stereonote_hpc/xueqinwen_8ee86cfa16754f1793f46e97cd554ad0_private:latest"
                                     ],
                                     "workflowid": "1874756667516190721",
                                     "origin_project": None,
                                     "pre_tag": "0",
                                     "old_is_public_wdl": None,
                                     "inside": 0,
                                     "is_edit": 0,
                                     "origin_type": None,
                                     "is_public_wdl": "yes",
                                     "workflow_tag": "",
                                     "input_desc": {
                                         "LUSH2_build_index.ReferenceName": {
                                             "param_des": ""
                                         },
                                         "LUSH2_build_index.ReferenceFasta": {
                                             "param_des": ""
                                         },
                                         "LUSH2_build_index.KnownSiteVcfs": {
                                             "param_des": ""
                                         },
                                         "LUSH2_build_index.Species": {
                                             "param_des": ""
                                         }
                                     },
                                     "outputs": {
                                         "LUSH2_build_index.ref": "File"
                                     },
                                     "is_draft": "no",
                                     "inputs": {
                                         "LUSH2_build_index.ReferenceName": "String",
                                         "LUSH2_build_index.ReferenceFasta": "File? (optional)",
                                         "LUSH2_build_index.KnownSiteVcfs": "Array[File]? (optional)",
                                         "LUSH2_build_index.Species": "String"
                                     },
                                     "is_subscribe": "no",
                                     "official_workflow": "yes",
                                     "update_at": "2025-01-02T17:56:35.835000",
                                     "description": "",
                                     "status": "checked",
                                     "origin_id": None,
                                     "version": "1.0.0",
                                     "is_sys": None,
                                     "name": "LUSH2_build_index(1)",
                                     "official_tag": "LUSH2_build_index"
                                 }
                             ],
                             "is_subscribe": "no",
                             "billing_type": None,
                             "update_time": "2025-01-02 17:56:35",
                             "update_name": "",
                             "publish_time": None,
                             "origin_id": None,
                             "create_at": "2025-01-02T17:56:35.835000",
                             "publish_name": None,
                             "is_sys": None,
                             "user_name": "luya",
                             "old_publish_time": None,
                             "publish_status": 0,
                             "subscribe_run_count": None,
                             "name": "LUSH2_build_index(1)",
                             "install_number": 0
                         }
                     ] * 1888
}

mock_project_app_list_by_all_demo_4 = {
    "count": 2003,
    "index": 0,
    "workflow_list": [
                         {
                             "project": "P1871461072416366593",
                             "origin_project": None,
                             "pre_tag": "0",
                             "is_edit": 0,
                             "origin_type": None,
                             "type": "private",
                             "id": "677662d373633b2c3fd330c1",
                             "subscribe_content": {},
                             "version_list": [
                                 {
                                     "avatar_source": None,
                                     "origin_name": None,
                                     "tag": "",
                                     "toolbox_id_list": [],
                                     "images": [
                                         "public-library/xueqinwen_20393bf7b3c74636ab472a7d5fb277ad_public:latest",
                                         "stereonote_hpc/xueqinwen_8ee86cfa16754f1793f46e97cd554ad0_private:latest"
                                     ],
                                     "workflowid": "1874756667516190721",
                                     "origin_project": None,
                                     "pre_tag": "0",
                                     "old_is_public_wdl": None,
                                     "inside": 0,
                                     "is_edit": 0,
                                     "origin_type": None,
                                     "is_public_wdl": "yes",
                                     "workflow_tag": "",
                                     "input_desc": {
                                         "LUSH2_build_index.ReferenceName": {
                                             "param_des": ""
                                         },
                                         "LUSH2_build_index.ReferenceFasta": {
                                             "param_des": ""
                                         },
                                         "LUSH2_build_index.KnownSiteVcfs": {
                                             "param_des": ""
                                         },
                                         "LUSH2_build_index.Species": {
                                             "param_des": ""
                                         }
                                     },
                                     "outputs": {
                                         "LUSH2_build_index.ref": "File"
                                     },
                                     "is_draft": "no",
                                     "inputs": {
                                         "LUSH2_build_index.ReferenceName": "String",
                                         "LUSH2_build_index.ReferenceFasta": "File? (optional)",
                                         "LUSH2_build_index.KnownSiteVcfs": "Array[File]? (optional)",
                                         "LUSH2_build_index.Species": "String"
                                     },
                                     "is_subscribe": "no",
                                     "official_workflow": "yes",
                                     "update_at": "2025-01-02T17:56:35.835000",
                                     "description": "",
                                     "status": "checked",
                                     "origin_id": None,
                                     "version": "1.0.0",
                                     "is_sys": None,
                                     "name": "LUSH2_build_index(1)",
                                     "official_tag": "LUSH2_build_index"
                                 }
                             ],
                             "is_subscribe": "no",
                             "billing_type": None,
                             "update_time": "2025-01-02 17:56:35",
                             "update_name": "",
                             "publish_time": None,
                             "origin_id": None,
                             "create_at": "2025-01-02T17:56:35.835000",
                             "publish_name": None,
                             "is_sys": None,
                             "user_name": "luya",
                             "old_publish_time": None,
                             "publish_status": 0,
                             "subscribe_run_count": None,
                             "name": "LUSH2_build_index(1)",
                             "install_number": 0
                         }
                     ] * 2000
}

mock_public_app_list_by_all_demo = {
    "code": 0,
    "msg": "成功",
    "data": {
        "records": [
            {
                "did": "vikPapUB5SPxi-7IQL4p",
                "oid": "WF0120231115LqP1",
                "rawId": "1085",
                "resType": "workflow",
                "labels": [
                    "app"
                ],
                "name": "SAW-ST-V6-reregist",
                "tags": [],
                "fullTags": [],
                "intro": "SAW reregist, upgraded to v6.1, is for generating tissue-coverage spatial expression "
                         "and cell expression data based on manual registration (may or may",
                "resDesc": None,
                "createdBy": "meizhiying",
                "resCreatedAt": "1700012460000",
                "resUpdatedAt": "1703733151000",
                "updatedBy": "meizhiying",
                "updatedById": "user_ae3a70a77d10d5c9b944eaa28d189224",
                "createdById": "user_ae3a70a77d10d5c9b944eaa28d189224",
                "isSto": 1,
                "subPlanType": 0,
                "zoneToStatus": {
                    "sz": "succeed"
                },
                "srcZone": "sz",
                "srcProjectId": "P1645666176522661889",
                "starsScore": 0,
                "numCommentsVotes": "0",
                "numGoods": "1",
                "numRef": "2",
                "numClicks": "9",
                "datasetType": -1,
                "version": "4.0.0",
                "coverKey": "",
                "progEnv": 0,
                "billingType": -1,
                "originalPrice": "0.00",
                "more": {
                    'url': '123456'
                },
                "deleted": 0,
                "myFeedback": None,
                "myNumCp": 0,
                "highlightFields": {},
                "score": 3.3048167,
                "coverUrl": None
            },
        ],
        "total": 1,
        "size": 16,
        "current": 1,
        "orders": [],
        "optimizeCountSql": True,
        "searchCount": True,
        "optimizeJoinOfCountSql": True,
        "maxLimit": None,
        "countId": None,
        "typeToCount": None,
        "pages": 1
    },
    "currentTime": "2025-03-24 21:17:05.171"
}

mock_public_app_list_by_all_demo_1 = {
    "code": 0,
    "msg": "成功",
    "data": {
        "records": [
                       {
                           "did": "vikPapUB5SPxi-7IQL4p",
                           "oid": "WF0120231115LqP1",
                           "rawId": "1085",
                           "resType": "workflow",
                           "labels": [
                               "app"
                           ],
                           "name": "SAW-ST-V6-reregist",
                           "tags": [],
                           "fullTags": [],
                           "intro": "SAW reregist, upgraded to v6.1, is for generating tissue-coverage spatial "
                                    "expression and cell expression data based on manual registration (may or may",
                           "resDesc": None,
                           "createdBy": "meizhiying",
                           "resCreatedAt": "1700012460000",
                           "resUpdatedAt": "1703733151000",
                           "updatedBy": "meizhiying",
                           "updatedById": "user_ae3a70a77d10d5c9b944eaa28d189224",
                           "createdById": "user_ae3a70a77d10d5c9b944eaa28d189224",
                           "isSto": 1,
                           "subPlanType": 0,
                           "zoneToStatus": {
                               "sz": "succeed"
                           },
                           "srcZone": "sz",
                           "srcProjectId": "P1645666176522661889",
                           "starsScore": 0,
                           "numCommentsVotes": "0",
                           "numGoods": "1",
                           "numRef": "2",
                           "numClicks": "9",
                           "datasetType": -1,
                           "version": "4.0.0",
                           "coverKey": "",
                           "progEnv": 0,
                           "billingType": -1,
                           "originalPrice": "0.00",
                           "more": {
                               'url': '123456'
                           },
                           "deleted": 0,
                           "myFeedback": None,
                           "myNumCp": 0,
                           "highlightFields": {},
                           "score": 3.3048167,
                           "coverUrl": None
                       },
                   ] * 10,
        "total": 13,
        "size": 16,
        "current": 1,
        "orders": [],
        "optimizeCountSql": True,
        "searchCount": True,
        "optimizeJoinOfCountSql": True,
        "maxLimit": None,
        "countId": None,
        "typeToCount": None,
        "pages": 1
    },
    "currentTime": "2025-03-24 21:17:05.171"
}

mock_public_app_list_by_all_demo_2 = {
    "code": 0,
    "msg": "成功",
    "data": {
        "records": [
                       {
                           "did": "vikPapUB5SPxi-7IQL4p",
                           "oid": "WF0120231115LqP1",
                           "rawId": "1085",
                           "resType": "workflow",
                           "labels": [
                               "app"
                           ],
                           "name": "SAW-ST-V6-reregist",
                           "tags": [],
                           "fullTags": [],
                           "intro": "SAW reregist, upgraded to v6.1, is for generating tissue-coverage spatial "
                                    "expression and cell expression data based on manual registration (may or may",
                           "resDesc": None,
                           "createdBy": "meizhiying",
                           "resCreatedAt": "1700012460000",
                           "resUpdatedAt": "1703733151000",
                           "updatedBy": "meizhiying",
                           "updatedById": "user_ae3a70a77d10d5c9b944eaa28d189224",
                           "createdById": "user_ae3a70a77d10d5c9b944eaa28d189224",
                           "isSto": 1,
                           "subPlanType": 0,
                           "zoneToStatus": {
                               "sz": "succeed"
                           },
                           "srcZone": "sz",
                           "srcProjectId": "P1645666176522661889",
                           "starsScore": 0,
                           "numCommentsVotes": "0",
                           "numGoods": "1",
                           "numRef": "2",
                           "numClicks": "9",
                           "datasetType": -1,
                           "version": "4.0.0",
                           "coverKey": "",
                           "progEnv": 0,
                           "billingType": -1,
                           "originalPrice": "0.00",
                           "more": {
                               'url': '123456'
                           },
                           "deleted": 0,
                           "myFeedback": None,
                           "myNumCp": 0,
                           "highlightFields": {},
                           "score": 3.3048167,
                           "coverUrl": None
                       },
                   ] * 13,
        "total": 13,
        "size": 16,
        "current": 1,
        "orders": [],
        "optimizeCountSql": True,
        "searchCount": True,
        "optimizeJoinOfCountSql": True,
        "maxLimit": None,
        "countId": None,
        "typeToCount": None,
        "pages": 1
    },
    "currentTime": "2025-03-24 21:17:05.171"
}

mock_public_app_list_by_all_max_print = {
    "code": 0,
    "msg": "成功",
    "data": {
        "records": [
                       {
                           "did": "vikPapUB5SPxi-7IQL4p",
                           "oid": "WF0120231115LqP1",
                           "rawId": "1085",
                           "resType": "workflow",
                           "labels": [
                               "app"
                           ],
                           "name": "SAW-ST-V6-reregist",
                           "tags": [],
                           "fullTags": [],
                           "intro": "SAW reregist, upgraded to v6.1, is for generating tissue-coverage spatial "
                                    "expression and cell expression data based on manual registration (may or may",
                           "resDesc": None,
                           "createdBy": "meizhiying",
                           "resCreatedAt": "1700012460000",
                           "resUpdatedAt": "1703733151000",
                           "updatedBy": "meizhiying",
                           "updatedById": "user_ae3a70a77d10d5c9b944eaa28d189224",
                           "createdById": "user_ae3a70a77d10d5c9b944eaa28d189224",
                           "isSto": 1,
                           "subPlanType": 0,
                           "zoneToStatus": {
                               "sz": "succeed"
                           },
                           "srcZone": "sz",
                           "srcProjectId": "P1645666176522661889",
                           "starsScore": 0,
                           "numCommentsVotes": "0",
                           "numGoods": "1",
                           "numRef": "2",
                           "numClicks": "9",
                           "datasetType": -1,
                           "version": "4.0.0",
                           "coverKey": "",
                           "progEnv": 0,
                           "billingType": -1,
                           "originalPrice": "0.00",
                           "more": {
                               'url': '123456'
                           },
                           "deleted": 0,
                           "myFeedback": None,
                           "myNumCp": 0,
                           "highlightFields": {},
                           "score": 3.3048167,
                           "coverUrl": None
                       },
                   ] * 2000,
        "total": 2003,
        "size": 16,
        "current": 1,
        "orders": [],
        "optimizeCountSql": True,
        "searchCount": True,
        "optimizeJoinOfCountSql": True,
        "maxLimit": None,
        "countId": None,
        "typeToCount": None,
        "pages": 1
    },
    "currentTime": "2025-03-24 21:17:05.171"
}

mock_public_app_list_by_all_max_print_ii = {
    "code": 0,
    "msg": "成功",
    "data": {
        "records": [
                       {
                           "did": "vikPapUB5SPxi-7IQL4p",
                           "oid": "WF0120231115LqP1",
                           "rawId": "1085",
                           "resType": "workflow",
                           "labels": [
                               "app"
                           ],
                           "name": "SAW-ST-V6-reregist",
                           "tags": [],
                           "fullTags": [],
                           "intro": "SAW reregist, upgraded to v6.1, is for generating tissue-coverage spatial "
                                    "expression and cell expression data based on manual registration (may or may",
                           "resDesc": None,
                           "createdBy": "meizhiying",
                           "resCreatedAt": "1700012460000",
                           "resUpdatedAt": "1703733151000",
                           "updatedBy": "meizhiying",
                           "updatedById": "user_ae3a70a77d10d5c9b944eaa28d189224",
                           "createdById": "user_ae3a70a77d10d5c9b944eaa28d189224",
                           "isSto": 1,
                           "subPlanType": 0,
                           "zoneToStatus": {
                               "sz": "succeed"
                           },
                           "srcZone": "sz",
                           "srcProjectId": "P1645666176522661889",
                           "starsScore": 0,
                           "numCommentsVotes": "0",
                           "numGoods": "1",
                           "numRef": "2",
                           "numClicks": "9",
                           "datasetType": -1,
                           "version": "4.0.0",
                           "coverKey": "",
                           "progEnv": 0,
                           "billingType": -1,
                           "originalPrice": "0.00",
                           "more": None,
                           "deleted": 0,
                           "myFeedback": None,
                           "myNumCp": 0,
                           "highlightFields": {},
                           "score": 3.3048167,
                           "coverUrl": None
                       },
                   ] * 1888,
        "total": 2003,
        "size": 16,
        "current": 1,
        "orders": [],
        "optimizeCountSql": True,
        "searchCount": True,
        "optimizeJoinOfCountSql": True,
        "maxLimit": None,
        "countId": None,
        "typeToCount": None,
        "pages": 1
    },
    "currentTime": "2025-03-24 21:17:05.171"
}

mock_public_app_list_by_all_output_path = {
    "code": 0,
    "msg": "成功",
    "data": {
        "records": [
                       {
                           "did": "vikPapUB5SPxi-7IQL4p",
                           "oid": "WF0120231115LqP1",
                           "rawId": "1085",
                           "resType": "workflow",
                           "labels": [
                               "app"
                           ],
                           "name": "SAW-ST-V6-reregist",
                           "tags": [],
                           "fullTags": [],
                           "intro": "SAW reregist, upgraded to v6.1, is for generating tissue-coverage spatial "
                                    "expression and cell expression data based on manual registration (may or may",
                           "resDesc": None,
                           "createdBy": "meizhiying",
                           "resCreatedAt": "1700012460000",
                           "resUpdatedAt": "1703733151000",
                           "updatedBy": "meizhiying",
                           "updatedById": "user_ae3a70a77d10d5c9b944eaa28d189224",
                           "createdById": "user_ae3a70a77d10d5c9b944eaa28d189224",
                           "isSto": 1,
                           "subPlanType": 0,
                           "zoneToStatus": {
                               "sz": "succeed"
                           },
                           "srcZone": "sz",
                           "srcProjectId": "P1645666176522661889",
                           "starsScore": 0,
                           "numCommentsVotes": "0",
                           "numGoods": "1",
                           "numRef": "2",
                           "numClicks": "9",
                           "datasetType": -1,
                           "version": "4.0.0",
                           "coverKey": "",
                           "progEnv": 0,
                           "billingType": -1,
                           "originalPrice": "0.00",
                           "more": {
                               'url': '123456'
                           },
                           "deleted": 0,
                           "myFeedback": None,
                           "myNumCp": 0,
                           "highlightFields": {},
                           "score": 3.3048167,
                           "coverUrl": None
                       },
                   ] * 2003,
        "total": 2003,
        "size": 16,
        "current": 1,
        "orders": [],
        "optimizeCountSql": True,
        "searchCount": True,
        "optimizeJoinOfCountSql": True,
        "maxLimit": None,
        "countId": None,
        "typeToCount": None,
        "pages": 1
    },
    "currentTime": "2025-03-24 21:17:05.171"
}

mock_repeat_demo = {
    "repeat_list": [
        {
            "name": "workflow_test_319_01",
            "is_sys": None,
            "user_name": "wenzhenbin",
            "repeatName": "workflow_test_319_01",
            "is_subscribe": "no",
            "origin_type": None,
            "toolbox_id_list_length": 0
        },
        {
            "name": "testlink_shoufei",
            "is_sys": None,
            "user_name": "wenzhenbin",
            "repeatName": "testlink_shoufei",
            "is_subscribe": "no",
            "origin_type": None,
            "toolbox_id_list_length": 0
        }
    ],
    "normal_list": [
        "SAW-ST-V5"
    ]
}

mock_repeat_demo_1 = {
    "repeat_list": [
        {
            "name": "workflow_test_319_01",
            "is_sys": '1',
            "user_name": "wenzhenbin",
            "repeatName": "workflow_test_319_01",
            "is_subscribe": "no",
            "origin_type": None,
            "toolbox_id_list_length": 0
        },
        {
            "name": "testlink_shoufei",
            "is_sys": None,
            "user_name": "wenzhenbin",
            "repeatName": "testlink_shoufei",
            "is_subscribe": "yes",
            "origin_type": 'public',
            "toolbox_id_list_length": 0
        }
    ],
    "normal_list": [
        "SAW-ST-V5"
    ]
}

mock_repeat_demo_2 = {
    "repeat_list": [
        {
            "name": "workflow_test_319_01",
            "is_sys": '1',
            "user_name": "wenzhenbin1",
            "repeatName": "workflow_test_319_01",
            "is_subscribe": "no",
            "origin_type": None,
            "toolbox_id_list_length": 0
        },
        {
            "name": "testlink_shoufei",
            "is_sys": None,
            "user_name": "wenzhenbin",
            "repeatName": "testlink_shoufei",
            "is_subscribe": "yes",
            "origin_type": 'public',
            "toolbox_id_list_length": 0
        }
    ],
    "normal_list": [
        "SAW-ST-V5"
    ]
}

mock_repeat_demo_3 = {
    "repeat_list": [
        {
            "name": "workflow_test_319_01",
            "is_sys": '1',
            "user_name": "wenzhenbin1",
            "repeatName": "workflow_test_319_01",
            "is_subscribe": "no",
            "origin_type": None,
            "toolbox_id_list_length": 0
        },
        {
            "name": "testlink_shoufei",
            "is_sys": None,
            "user_name": "wenzhenbin",
            "repeatName": "testlink_shoufei",
            "is_subscribe": "yes",
            "origin_type": 'public',
            "toolbox_id_list_length": 0
        },
        {
            "name": "testlink_shoufei1",
            "is_sys": None,
            "user_name": "wenzhenbin1",
            "repeatName": "testlink_shoufei",
            "is_subscribe": "yes",
            "origin_type": 'public',
            "toolbox_id_list_length": 0
        }
    ],
    "normal_list": [
        "SAW-ST-V5"
    ]
}

mock_repeat_demo_4 = {
    "repeat_list": [
        {
            "name": "workflow_test_319_01",
            "is_sys": None,
            "user_name": "6666",
            "repeatName": "workflow_test_319_01",
            "is_subscribe": "no",
            "origin_type": None,
            "toolbox_id_list_length": 0
        },
        {
            "name": "workflow_test_319_021",
            "is_sys": None,
            "user_name": "wenzhenbin",
            "repeatName": "workflow_test_319_01",
            "is_subscribe": "no",
            "origin_type": None,
            "toolbox_id_list_length": 0
        },
        {
            "name": "testlink_shoufei",
            "is_sys": None,
            "user_name": "wenzhenbin",
            "repeatName": "testlink_shoufei",
            "is_subscribe": "yes",
            "origin_type": 'public',
            "toolbox_id_list_length": 0
        },
        {
            "name": "testlink_shoufei1",
            "is_sys": None,
            "user_name": "6666",
            "repeatName": "testlink_shoufei",
            "is_subscribe": "yes",
            "origin_type": 'public',
            "toolbox_id_list_length": 0
        }
    ],
    "normal_list": [
        "SAW-ST-V5"
    ]
}

mock_repeat_demo_5 = {
    "repeat_list": [
        {
            "name": "workflow_test_319_01",
            "is_sys": None,
            "user_name": "666",
            "repeatName": "workflow_test_319_01",
            "is_subscribe": "no",
            "origin_type": None,
            "toolbox_id_list_length": 0
        },
        {
            "name": "workflow_test_319_021",
            "is_sys": None,
            "user_name": "666",
            "repeatName": "workflow_test_319_01",
            "is_subscribe": "no",
            "origin_type": None,
            "toolbox_id_list_length": 0
        },
        {
            "name": "testlink_shoufei",
            "is_sys": None,
            "user_name": "wenzhenbin",
            "repeatName": "testlink_shoufei",
            "is_subscribe": "yes",
            "origin_type": 'public',
            "toolbox_id_list_length": 0
        },
        {
            "name": "testlink_shoufei1",
            "is_sys": None,
            "user_name": "666",
            "repeatName": "testlink_shoufei",
            "is_subscribe": "yes",
            "origin_type": 'public',
            "toolbox_id_list_length": 0
        }
    ],
    "normal_list": [
        "SAW-ST-V5"
    ]
}

mock_repeat_demo_6 = {
    "repeat_list": [
        {
            "name": "workflow_test_319_01",
            "is_sys": '1',
            "user_name": "wenzhenbin1",
            "repeatName": "workflow_test_319_01",
            "is_subscribe": "no",
            "origin_type": None,
            "toolbox_id_list_length": 0
        },
        {
            "name": "workflow_test_319_021",
            "is_sys": None,
            "user_name": "wenzhenbin1",
            "repeatName": "workflow_test_319_01",
            "is_subscribe": "no",
            "origin_type": None,
            "toolbox_id_list_length": 0
        },
        {
            "name": "testlink_shoufei",
            "is_sys": None,
            "user_name": "wenzhenbin1",
            "repeatName": "testlink_shoufei",
            "is_subscribe": "yes",
            "origin_type": 'public',
            "toolbox_id_list_length": 0
        },
        {
            "name": "testlink_shoufei1",
            "is_sys": None,
            "user_name": "wenzhenbin1",
            "repeatName": "testlink_shoufei",
            "is_subscribe": "yes",
            "origin_type": 'public',
            "toolbox_id_list_length": 0
        }
    ],
    "normal_list": [
        "SAW-ST-V5"
    ]
}
