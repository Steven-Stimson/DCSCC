import pytest

from dcs_cli.main import main
from dcs_cli.commands.data import data, find


@pytest.mark.usefixtures('runner')
class TestData:
    def test_dcs_data_find(self, runner):
        for options in [
            ['/Files'],
            ['/Files', '-t', 'f'],
            ['/Files', '-t', 'd'],
            ['/Files', '-n', 'RawData'],
            ['/Files', '--entity', 'C01935E1'],
            ['/Files', '--sample', 'S00000667'],
            ['/Files', '--sn', 'C01935E1'],
            ['/Files', '--task', 'W202412050000015'],
            ['/Files', '--workflow', 'Hello,1.0.0'],
            ['/Files', '--user', 'huangxingxin'],
            ['/Files', '--time', '2024-12-01 00:00:00,2025-01-01 23:59:59'],
        ]:
            result = runner.invoke(main, [data.name, find.name] + options, input='q', catch_exceptions=False)
            assert '文件名称' in result.output
            print(result.output)
