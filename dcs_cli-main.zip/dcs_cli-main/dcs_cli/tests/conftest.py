import os

import pytest
import requests
from click.testing import CliRunner


@pytest.fixture
def runner():
    response = requests.post(
        'https://test-cloud.stomics.tech/api/customer/scLogin/loginByCredential',
        data={'username': os.getenv('USERNAME'), 'password': os.getenv('PASSWORD')}
    )
    env = {
        'DCS_PROJECT_ID': 'P1600787473158537217',
        'DCS_ZONE': 'sz',
        'DCS_CLOUD_URL': 'https://test-cloud.stomics.tech/',
        'DCS_X_ACCESS_TOKEN': response.json()['data']['token']
    }
    return CliRunner(env=env)
