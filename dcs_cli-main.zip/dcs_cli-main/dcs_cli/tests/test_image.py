import os.path
from unittest.mock import patch

import pytest

from dcs_cli.commands.image import _build_list_params
from dcs_cli.commands.image import get_detail_data
from dcs_cli.common import MAX_DIRECT_PRINT_PAGESIZE
from dcs_cli.common import MAX_OUTPUT_PAGESIZE
from dcs_cli.main import main
from dcs_cli.tests.mock_data import *
from dcs_cli.tests.mock_data import mock_build_list_params
from dcs_cli.tests.mock_data import mock_image_list
from dcs_cli.tests.mock_data import mock_image_list_by_all_demo_1
from dcs_cli.tests.mock_data import mock_image_list_by_all_demo_2
from dcs_cli.tests.mock_data import mock_image_list_by_name
from dcs_cli.tests.mock_data import mock_image_list_by_public
from dcs_cli.tests.mock_data import mock_image_list_by_url
from dcs_cli.tests.mock_data import public_name_list
from dcs_cli.tests.utils import get_data_length
from dcs_cli.tests.utils import get_params
from dcs_cli.tests.utils import set_env


@pytest.mark.usefixtures('runner')
class TestImageList:

    @set_env(DCS_PROJECT_ID="P20250328172629834")
    def test_dcs_image_in_project_error(self, runner):
        mock_responses = [
            (False, '16818'),
        ]
        with patch('dcs_cli.commands.image._safe_request') as mock_get:
            mock_get.side_effect = mock_responses
            result = runner.invoke(main, ['image', 'ls', '-n', 'stereonote'])
            assert ("16818") in result.output.replace('\n', '')
            assert result.exit_code == 0

        mock_responses = [
            (True, '16818'),
        ]
        with patch('dcs_cli.commands.image._safe_request') as mock_get:
            mock_get.side_effect = mock_responses
            result = runner.invoke(main, ['image', 'ls', '-n', 'stereonote'])
            assert ("查询数据失败。") in result.output.replace('\n', '')
            assert result.exit_code == 0


        mock_responses = [
            (True, mock_image_list_by_name),
        ]
        with patch('dcs_cli.commands.image._safe_request') as mock_get:
            mock_get.side_effect = mock_responses
            with patch('dcs_cli.commands.image.output_file') as mock_output_file:
                mock_output_file.return_value = (False, 'xxx')
                result = runner.invoke(main, ['image', 'ls', '-n', 'stereonote' ,'-o', './'])
                assert ("文件生成失败：xxx") in result.output.replace('\n', '')
                assert result.exit_code == 0

    def test_dcs_image_list(self, runner):
        with patch('dcs_cli.commands.image._safe_request') as mock_get:
            mock_get.return_value = (True, mock_image_list)
            result = runner.invoke(main, ['image', 'ls'])
            assert get_params(result.output) == {'page': 1, 'page_size': 10, 'project_id': 'P1871461072416366593'}
            assert result.exit_code == 0

    def test_dcs_image_list_by_name(self, runner):
        with patch('dcs_cli.commands.image._safe_request') as mock_get:
            mock_get.return_value = (True, mock_image_list_by_name)
            result = runner.invoke(main, ['image', 'ls', '-n', 'test'])
            assert get_params(result.output) == {'page': 1, 'page_size': 10, 'image_name': 'test',
                                                 'project_id': 'P1871461072416366593'}
            assert result.exit_code == 0

            result = runner.invoke(main, ['image', 'ls', '-n', 'test', '-a'])
            assert get_params(result.output) == {'page': 1, 'page_size': MAX_DIRECT_PRINT_PAGESIZE, 'image_name': 'test',
                                                 'project_id': 'P1871461072416366593'}
            assert result.exit_code == 0

            result = runner.invoke(main, ['image', 'ls', '-n', 'test', '--all'])
            assert get_params(result.output) == {'page': 1, 'page_size': MAX_DIRECT_PRINT_PAGESIZE, 'image_name': 'test',
                                                 'project_id': 'P1871461072416366593'}
            assert result.exit_code == 0

    def test_dcs_image_list_by_output(self, runner):
        mock_responses = [
            (True, mock_image_list_by_all_demo_1),
            (True, mock_image_list_by_all_demo_2),
        ]
        with patch('dcs_cli.commands.image._safe_request') as mock_get:
            mock_get.side_effect = mock_responses
            output_path = '202503241818.txt'
            result = runner.invoke(main, ['image', 'ls', '-n', 'test', '-o', output_path])
            assert get_params(result.output) == {'page': 1, 'page_size': 10,
                                                 'image_name': 'test',
                                                 'project_id': 'P1871461072416366593'}
            res_outpust = result.output.replace('\n', '')
            assert output_path in res_outpust
            assert os.path.isfile('202503241818.txt')
            os.remove('202503241818.txt')
            assert result.exit_code == 0
            assert mock_get.call_count == 1
            assert get_data_length(result.output) == 10

            result = runner.invoke(main, ['image', 'ls', '-n', 'test', '--output', output_path])
            assert get_params(result.output) == {'page': 1, 'page_size': 10,
                                                 'image_name': 'test',
                                                 'project_id': 'P1871461072416366593'}
            res_outpust = result.output.replace('\n', '')
            assert output_path in res_outpust
            assert os.path.isfile('202503241818.txt')
            os.remove('202503241818.txt')
            assert result.exit_code == 0
            assert mock_get.call_count == 2
            assert get_data_length(result.output) == 13

        mock_responses = [
                             (True, mock_image_list_by_all_demo_max_output),
                         ]
        with patch('dcs_cli.commands.image._safe_request') as mock_get:
            mock_get.side_effect = mock_responses

            output_path = '202503241818.txt'
            result = runner.invoke(main, ['image', 'ls', '-n', 'test', '-a', '-o', output_path])
            assert get_params(result.output) == {'page': 1, 'page_size': MAX_OUTPUT_PAGESIZE,
                                                 'image_name': 'test',
                                                 'project_id': 'P1871461072416366593'}
            res_outpust = result.output.replace('\n', '')
            assert output_path in res_outpust
            assert os.path.isfile('202503241818.txt')
            os.remove('202503241818.txt')
            assert result.exit_code == 0
            assert mock_get.call_count == 1
            assert get_data_length(result.output) == 2003


    def test_dcs_image_list_by_all(self, runner):
        mock_responses = [(True, mock_image_list_by_name)] * 3
        with patch('dcs_cli.commands.image._safe_request') as mock_get:
            mock_get.side_effect = mock_responses
            result = runner.invoke(main, ['image', 'ls', '-n', 'test'])
            assert get_params(result.output) == {'page': 1, 'page_size': 10, 'image_name': 'test',
                                                 'project_id': 'P1871461072416366593'}
            assert result.exit_code == 0
            assert mock_get.call_count == 1
            assert get_data_length(result.output) == 1

            result = runner.invoke(main, ['image', 'ls', '-n', 'test', '-a'])
            assert get_params(result.output) == {'page': 1, 'page_size': MAX_DIRECT_PRINT_PAGESIZE,
                                                 'image_name': 'test',
                                                 'project_id': 'P1871461072416366593'}
            assert result.exit_code == 0
            assert mock_get.call_count == 2
            assert get_data_length(result.output) == 1

            result = runner.invoke(main, ['image', 'ls', '-n', 'test', '--all'])
            assert get_params(result.output) == {'page': 1, 'page_size': MAX_DIRECT_PRINT_PAGESIZE,
                                                 'image_name': 'test',
                                                 'project_id': 'P1871461072416366593'}
            assert result.exit_code == 0
            assert mock_get.call_count == 3
            assert get_data_length(result.output) == 1

        mock_responses = [
            (True, mock_image_list_by_all_demo_2),
        ]
        with patch('dcs_cli.commands.image._safe_request') as mock_get:
            mock_get.side_effect = mock_responses
            result = runner.invoke(main, ['image', 'ls', '-n', 'test', '-a'])
            assert get_params(result.output) == {'page': 1, 'page_size': MAX_DIRECT_PRINT_PAGESIZE,
                                                 'image_name': 'test',
                                                 'project_id': 'P1871461072416366593'}
            assert result.exit_code == 0
            assert mock_get.call_count == 1
            assert get_data_length(result.output) == 13

        mock_responses = [
                             (True, mock_image_list_by_all_max_direct_print),
                             (True, mock_image_list_by_all_max_direct_print_ii),
                         ]
        with patch('dcs_cli.commands.image._safe_request') as mock_get:
            mock_get.side_effect = mock_responses
            result = runner.invoke(main, ['image', 'ls', '-n', 'test', '-a'])
            assert get_params(result.output) == {'page': 1, 'page_size': MAX_DIRECT_PRINT_PAGESIZE,
                                                 'image_name': 'test',
                                                 'project_id': 'P1871461072416366593'}
            assert result.exit_code == 0
            assert mock_get.call_count == 1
            assert get_data_length(result.output) == 1888

            result = runner.invoke(main, ['image', 'ls', '-n', 'test', '-a'])
            assert get_params(result.output) == {'page': 1, 'page_size': MAX_DIRECT_PRINT_PAGESIZE,
                                                 'image_name': 'test',
                                                 'project_id': 'P1871461072416366593'}
            assert result.exit_code == 0
            assert mock_get.call_count == 2
            assert get_data_length(result.output) == MAX_DIRECT_PRINT_PAGESIZE

    def test_dcs_image_list_by_public(self, runner):
        with patch('dcs_cli.commands.image._safe_request') as mock_get:
            mock_get.return_value = (True, mock_image_list_by_public)
            # 测试没有参数的情况
            result = runner.invoke(main, ['image', 'ls', '-p'])
            assert get_params(result.output) == {'page': 1, 'limit': 10, 'types': 'img'}
            assert result.exit_code == 0

            # 测试携带url的情况
            result = runner.invoke(main, ['image', 'ls', '-p', '--url', 'image.url'])
            assert get_params(result.output) == {'page': 1, 'limit': 10, 'types': 'img', 'in': 'url',
                                                 'kw': 'image.url', 'exc': True}

            # 测试携带name的情况
            result = runner.invoke(main, ['image', 'ls', '-p', '-n', 'test_image'])
            assert get_params(result.output) == {'page': 1, 'limit': 10, 'types': 'img', 'in': 'name',
                                                 'kw': 'test_image'}

            result = runner.invoke(main, ['image', 'ls', '-p', '--name', 'test_image'])
            assert get_params(result.output) == {'page': 1, 'limit': 10, 'types': 'img', 'in': 'name',
                                                 'kw': 'test_image'}
            # 测试携带name和url的情况
            result = runner.invoke(main, ['image', 'ls', '-p', '--name', 'test_image', '--url', 'image.url'])
            assert get_params(result.output) == {'page': 1, 'limit': 10, 'types': 'img', 'in': 'url',
                                                 'kw': 'image.url', 'exc': True}

    def test_dcs_image_list_by_url(self, runner):
        with patch('dcs_cli.commands.image._safe_request') as mock_get:
            mock_get.return_value = (True, mock_image_list_by_url)
            result = runner.invoke(main, ['image', 'ls', '--url', 'test_url'])
            assert get_params(result.output) == {'page': 1, 'page_size': 10, 'image_url': 'test_url',
                                                 'project_id': 'P1871461072416366593'}
            assert result.exit_code == 0

    def test_dcs_image_list_by_combination(self, runner):
        with patch('dcs_cli.commands.image._safe_request') as mock_get:
            mock_get.return_value = (True, mock_image_list)
            # 测试携带name和url的情况
            result = runner.invoke(main, ['image', 'ls', '--name', 'test_image', '--url', 'image.url'])
            assert get_params(result.output) == {'page': 1, 'page_size': 10, 'image_url': 'image.url',
                                                 'image_name': 'test_image', 'project_id': 'P1871461072416366593'}
            assert result.exit_code == 0

    def test_dcs_image_by_public(self, runner):
        # 测试公共库的镜像情况
        result = runner.invoke(main, ['image', 'ls', '-p', '-n', 'SAW-ST-v6'])
        assert get_data_length(result.output) == 2
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '-p', '-n', 'saw-st-v6'])
        assert get_data_length(result.output) == 2
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '--public', '-n', 'SAW-ST-v6'])
        assert get_data_length(result.output) == 2
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '--public', '--name', 'saw-st-v6'])
        assert get_data_length(result.output) == 2
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '--public', '--name', 'SAW-ST-V6'])
        assert get_data_length(result.output) == 2
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '--public', '-n', 'SAW-ST-v6111111'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '--public', '-n', 'SAW-ST-v6', '--url', ''])
        assert get_data_length(result.output) == 2
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '--public', '-n', 'SAW-ST-v6', '--url', '111'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '--public', '-n', 'SAW-ST-v6', '--url',
                                      'public-library-test/meizhiying_51fa94ff213d4a57877b2747504cb783_public:latest'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '--public', '-n', 'SAW-ST-v6', '-u',
                                      'public-library-test/meizhiying_51fa94ff213d4a57877b2747504cb783_public:latest'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '--public', '-n', 'SAW-ST-v6', '--url',
                                      'public-library-test/meizhiying_51fa94ff213d4a57877b2747504cb783_public'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '--public', '-n', 'SAW-ST-v6', '--url',
                                      'PUBLIC-LIBRARY-TEST/MEIZHIYING_51FA94FF213D4A57877B2747504CB783_PUBLIC'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '--public', '-n', 'SAW-ST-v6-111', '--url',
                                      'public-library-test/meizhiying_51fa94ff213d4a57877b2747504cb783_public'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

    @set_env(DCS_PROJECT_ID="P20250328172629834")
    def test_dcs_image_by_project(self, runner):
        # 测试项目中的镜像情况
        result = runner.invoke(main, ['image', 'ls', '-n', 'stereonote'])
        assert get_data_length(result.output) == 4
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '-n', 'STEREONOTE'])
        assert get_data_length(result.output) == 4
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '--name', 'stereonote'])
        assert get_data_length(result.output) == 4
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '--name', 'STEREONOTE'])
        assert get_data_length(result.output) == 4
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '--name', 'stereonote-code-basic'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '-u', 'harbor.cngb.org/stereonote_hpc/stereonote-code-basic'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '--url', 'stereonote_hpc/stereonote-code-basic:latest'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '--url', 'STEREONOTE_HPC/STEREONOTE-CODE-BASIC:LATEST'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '-n', 'stereonote-code-BASIC', '--url',
                                      'stereonote_hpc/stereonote-code-basic:latest'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '-n', 'stereonote-code', '--url',
                                      'stereonote_hpc/stereonote-code-basic:latest'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '-n', 'stereonote-code', '--url',
                                      'STEREONOTE_HPC/STEREONOTE-CODE-BASIC:LATEST'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'ls', '-n', 'stereonote-code-111111111', '--url',
                                      'stereonote_hpc/stereonote-code-basic:latest'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

    @pytest.mark.parametrize(
        "project, base_url, public, url, name, expected_url_suffix, expected_params",
        mock_build_list_params
    )
    def test_build_list_params(self, project, base_url, public, url, name, expected_url_suffix, expected_params):
        req_url, params = _build_list_params(project, base_url, public, url, name)
        assert params == expected_params

    # 特殊用例单独处理
    def test_private_url_priority(self):
        """测试 URL 参数的优先级"""
        records = [
            {'image_name': 'n1', 'image_url': 'u1'},
            {'image_name': 'n1', 'image_url': 'u2'}
        ]
        result = get_detail_data(records, 'n1', 'u2', False)
        assert result['image_url'] == 'u1'


@pytest.mark.usefixtures('runner')
class TestImageInfo:

    def test_dcs_image_in_public_query_by_name(self, runner):
        # 测试公共库的镜像情况，通过name情况
        result = runner.invoke(main, ['image', 'info', '-p', '-n', 'SAW-ST-v6'])
        assert '找不到名称为“SAW-ST-v6”的镜像。请重新检查名称或使用“dcs image ls -p”查看所有可用镜像。' in result.output.replace(
            '\n', '')
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '--public', '-n', 'SAW-ST-v6'])
        assert '找不到名称为“SAW-ST-v6”的镜像。请重新检查名称或使用“dcs image ls -p”查看所有可用镜像。' in result.output.replace(
            '\n', '')
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info'])
        assert '请输入"-n/--name"或者"-u/--url"命令。' in result.output.replace('\n', '')
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '--public', '--name', 'saw-st-v6.1.4'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '--public', '--name', 'SAW-ST-V6.1.4'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '--public', '-n', 'saw-st-v6.1.4'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '--public', '-n', 'SAW-ST-V6.1.4'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '--public', '-n', 'SAW-ST-v6111111'])
        assert '找不到名称为“SAW-ST-v6111111”的镜像。请重新检查名称或使用“dcs image ls -p”查看所有可用镜像。' in result.output.replace(
            '\n', '')
        assert result.exit_code == 0

    def test_dcs_image_in_public_query_by_url(self, runner):
        # 测试公共库的镜像情况，通过url情况
        result = runner.invoke(main, ['image', 'info', '--public', '-u',
                                      'public-library-test/yanghongli_e2b984bf90394147be98e3ea6e7173a3_public:latest'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '--public', '--url',
                                      'public-library-test/yanghongli_e2b984bf90394147be98e3ea6e7173a3_public:latest'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '-p', '--url',
                                      'public-library-test/yanghongli_e2b984bf90394147be98e3ea6e7173a3_public'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '--public', '--url',
                                      'public-library-test/yanghongli_e2b984bf90394147be98e3ea6e7173a3_public0'])
        assert ("找不到URL为“public-library-test/yanghongli_e2b984bf90394147be98e3ea6e7173a3_public0”的镜像。请重新"
                "检查URL或使用“dcs image ls -p”查看所有可用镜像。") in result.output.replace('\n', '')
        assert result.exit_code == 0

    def test_dcs_image_in_public_query_by_others(self, runner):
        # 测试公共库的镜像情况，通过组合情况
        result = runner.invoke(main, ['image', 'info', '--public', '-n', 'saw-st-v6.1.4', '--url',
                                      'public-library-test/meizhiying_d6a6c8004be04528a2a7666162740638_public:latest'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '-p', '-n', 'SAW-ST-V6.1.4', '-u',
                                      'public-library-test/meizhiying_d6a6c8004be04528a2a7666162740638_public:latest'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '-p', '-n', 'SAW-ST-V6.1.4', '-u',
                                      'meizhiying_d6a6c8004be04528a2a7666162740638_public0'])
        assert (("找不到URL为“meizhiying_d6a6c8004be04528a2a7666162740638_public0”、名称为“SAW-ST-V6.1.4”的镜像。") in
                result.output.replace('\n', ''))
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '--public', '-n', 'saw-st-v6.1.4', '--url', ''])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        for name in public_name_list:
            result = runner.invoke(main, ['image', 'info', '--public', '--name', name])
            assert get_data_length(result.output) == 1
            assert result.exit_code == 0

    def test_dcs_image_in_p20250328172629834_query_by_name(self, runner):
        for name in P20250328172629834_name_list:
            result = runner.invoke(main, ['image', 'info', '--name', name])
            assert get_data_length(result.output) == 1
            assert result.exit_code == 0

    @set_env(DCS_PROJECT_ID="P20250328172629834")
    def test_dcs_image_in_p20250328172629834_query_by_name(self, runner):
        result = runner.invoke(main, ['image', 'info', '-n', 'stereonote1'])
        assert ("找不到名称为“stereonote1”的镜像。请重新检查名称或使用“dcs image ls”查看所有可用镜像。" in
                result.output.replace('\n', ''))
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '--name', 'stereonote-code-basic'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '--name', 'stereonote-code-basic'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        for name in P20250328172629834_name_list:
            result = runner.invoke(main, ['image', 'info', '--name', name])
            assert get_data_length(result.output) == 1
            assert result.exit_code == 0

    @set_env(DCS_PROJECT_ID="P20250328172629834")
    def test_dcs_image_in_project_query_by_url(self, runner):
        # 测试项目中的镜像情况
        result = runner.invoke(main, ['image', 'info', '--url',
                                      'stereonote_hpc/stereonote-code-basic:latest'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '-u',
                                      'stereonote_hpc/stereonote-code-basic:latest'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '--url',
                                      'stereonote_hpc/STEREONOTE-code-basic:latest'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        # 测试项目中的镜像情况
        result = runner.invoke(main, ['image', 'info', '--url',
                                      'stereonote_hpc/stereonote-code-basic:latest1'])
        assert ("找不到URL为“stereonote_hpc/stereonote-code-basic:latest1”的镜像。请重新检查URL或使用“dcs"
                "") in result.output.replace('\n', '')
        assert result.exit_code == 0

    @set_env(DCS_PROJECT_ID="P20250328172629834")
    def test_dcs_image_in_project_query_by_others(self, runner):
        # 测试项目中的镜像情况
        result = runner.invoke(main, ['image', 'info', '-n', 'stereonote-code-BASIC', '--url',
                                      'stereonote_hpc/stereonote-code-basic:latest'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '-n', 'stereonote-code-basic', '--url',
                                      'STEREONOTE_HPC/STEREONOTE-CODe-basic:latest'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '-n', 'stereonote-code-BASIC', '--url',
                                      'STEREONOTE_HPC/STEREONOTE-CODe-basic:latest'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '-n', 'stereonote-code-basic', '--url',
                                      'stereonote_hpc/stereonote-code-basic:latest'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '-n', 'stereonote-code-basic', '--url',
                                      'stereonote_hpc/stereonote-code-basic:latest111'])
        assert ("找不到URL为“stereonote_hpc/stereonote-code-basic:latest111”、名称为“stereonote-code-basic”的"
                "镜像。请重新检查名称和URL或使用“dcs image ls”查看所有可用镜像。") in result.output.replace('\n', '')
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '-n', 'stereonote-code-basic', '--url',
                                      'stereonote_hpc/stereonote-code-basic'])
        assert ("找不到URL为“stereonote_hpc/stereonote-code-basic”、名称为“stereonote-code-basic”的"
                "镜像。请重新检查名称和URL或使用“dcs image ls”查看所有可用镜像。") in result.output.replace('\n', '')
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '-n', 'stereonote-code1', '--url',
                                      'stereonote_hpc/stereonote-code-basic:latest'])
        assert ("找不到URL为“stereonote_hpc/stereonote-code-basic:latest”、名称为“stereonote-code1"
                "”的镜像。请重新检查名称和URL或使用“dcs image ls”查看所有可用镜像。") in result.output.replace('\n', '')
        assert result.exit_code == 0

        result = runner.invoke(main, ['image', 'info', '-n', 'stereonote-code-111111111', '--url',
                                      'stereonote_hpc/stereonote-code-basic:latest'])
        assert ("找不到URL为“stereonote_hpc/stereonote-code-basic:latest”、名称为“stereonote-code-111111111"
                "”的镜像。请重新检查名称和URL或使用“dcs image ls”查看所有可用镜像。") in result.output.replace('\n', '')
        assert result.exit_code == 0

        mock_responses = [
            (False, '查询数据失败。'),
            (True, {'data':{'record':[]}}),
        ]
        with patch('dcs_cli.commands.image._safe_request') as mock_get:
            mock_get.side_effect = mock_responses
            result = runner.invoke(main, ['image', 'info', '-n', 'stereonote-code-basic', '--url',
                                          'stereonote_hpc/stereonote-code-basic'])
            assert ("查询数据失败。") in result.output.replace('\n', '')
            assert result.exit_code == 0

            result = runner.invoke(main, ['image', 'info', '-n', 'stereonote-code-basic', '--url',
                                          'stereonote_hpc/stereonote-code-basic'])
            assert ("找不到URL为“stereonote_hpc/stereonote-code-basic”、名称为“stereonote-code-basic”的镜像。") in result.output.replace('\n', '')
            assert result.exit_code == 0


    @set_env(DCS_PROJECT_ID="P20250328172629834")
    def test_dcs_image_in_project_error(self, runner):
        mock_responses = [
            (True, {'data': {'record': [{'image_name':'stereonote'}]}}),
            (False, 'xxx'),
        ]
        with patch('dcs_cli.commands.image._safe_request') as mock_get:
            mock_get.side_effect = mock_responses
            result = runner.invoke(main, ['image', 'info', '-n', 'stereonote'])
            assert ("查询数据失败。") in result.output.replace('\n', '')
            assert result.exit_code == 0

        mock_responses = [
            (True, {'data': {'record': [{'image_name':'stereonote','image_id':'168'}]}}),
            (False, 'xxx'),
        ]
        with patch('dcs_cli.commands.image._safe_request') as mock_get:
            mock_get.side_effect = mock_responses
            result = runner.invoke(main, ['image', 'info', '-n', 'stereonote'])
            assert ("xxx") in result.output.replace('\n', '')
            assert result.exit_code == 0

