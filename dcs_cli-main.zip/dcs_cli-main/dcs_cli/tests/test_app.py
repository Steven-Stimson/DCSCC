import errno
import shutil
import time
from unittest.mock import patch

import pytest
from pytest_mock import mocker  # noqa

from dcs_cli.commands.app import *
from dcs_cli.commands.app import get_update_ids
from dcs_cli.commands.app import get_version_list
from dcs_cli.commands.app import handle_repeat_data
from dcs_cli.commands.app import validate_file_format
from dcs_cli.main import main
from dcs_cli.tests.mock_data import *
from dcs_cli.tests.mock_data import mock_prompt_update_data
from dcs_cli.tests.mock_data import mock_workflow_list
from dcs_cli.tests.utils import _test_build_common_headers
from dcs_cli.tests.utils import delete_test_temp_file
from dcs_cli.tests.utils import get_data_length
from dcs_cli.tests.utils import get_params
from dcs_cli.tests.utils import set_env
from dcs_cli.utils import create_dir
from src.codes.common_codes import *
from src.codes.manager import manager_cli

PROJECT = 'P20250328172629834'
BASE_URL = 'https://test-cloud.stomics.tech/'
TIME_SECOND = 0.5
WDL_PATH = (r'C:\Users\wenzhenbin\Desktop\work\dcs_clients\test_data\validate_data\Chips_scRNA_singlespecies_V1'
            '.1.1\Chips_scRNA_singlespecies_V1.1.1.wdl')
SUCCESSED_PATH = r'C:\Users\wenzhenbin\Desktop\work\dcs_clients\test_data\push_data\workflow_export_two.zip'


@pytest.mark.usefixtures('runner')
class TestAppList:

    @set_env(DCS_PROJECT_ID="P20250328172629834")
    def test_dcs_app_in_project_query_by_name(self, runner):
        # 测试项目中的镜像情况，按照名称查询
        result = runner.invoke(main, ['app', 'ls', '-n', 'SAW-ST-V8-re'])
        assert get_data_length(result.output) == 3
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '--name', 'saw-st-v8-re'])
        assert get_data_length(result.output) == 3
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '--name', 'SAW-ST-V8-realign-autotest'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '--name', 'SAW-ST-V8-realign-autotest'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '--name', 'SAW-ST-V8-merge111'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

    def test_dcs_app_in_public_query_by_name(self, runner):
        # 测试公共库的应用情况，通过name查询
        result = runner.invoke(main, ['app', 'ls', '-p', '-n', 'SAW-ST-V6-'])
        assert get_data_length(result.output) == 4
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '--public', '-n', 'SAW-ST-v6-'])
        assert get_data_length(result.output) == 4
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '--public', '--name', 'SAW-ST-v6-'])
        assert get_data_length(result.output) == 4
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '--public', '--name', 'saw-st-v6-'])
        assert get_data_length(result.output) == 4
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '--public', '--name', 'SAW-ST-v6-111'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

        with patch('dcs_cli.commands.app._safe_request') as mock_get:
            mock_get.return_value = (True, mock_public_app_list_by_all_demo)
            result = runner.invoke(main, ['app', 'ls', '-p'])
            print(result.output)
            assert get_data_length(result.output) == 1
            assert result.exit_code == 0

    def test_dcs_app_in_public_list_by_output(self, runner):
        mock_responses = [
            (True, mock_public_app_list_by_all_output_path),
            (True, mock_public_app_list_by_all_demo),
        ]
        with patch('dcs_cli.commands.app._safe_request') as mock_get:
            mock_get.side_effect = mock_responses
            output_path = '202503241818.txt'
            result = runner.invoke(main, ['app', 'ls', '-p', '-n', 'test', '-a', '-o', output_path])
            assert get_params(result.output) == {'in': 'name', 'kw': 'test', 'limit': MAX_OUTPUT_PAGESIZE, 'page': 1,
                                                 'types': 'workflow'}
            res_outpust = result.output.replace('\n', '')
            assert output_path in res_outpust
            assert os.path.isfile('202503241818.txt')
            os.remove('202503241818.txt')
            assert result.exit_code == 0
            assert mock_get.call_count == 1
            assert get_data_length(result.output) == 2003

            output_path = '202503241818.txt'
            result = runner.invoke(main, ['app', 'ls', '-p', '-n', 'test', '--output', output_path])
            assert get_params(result.output) == {'in': 'name', 'kw': 'test', 'limit': 10, 'page': 1,
                                                 'types': 'workflow'}
            res_outpust = result.output.replace('\n', '')
            assert output_path in res_outpust
            assert os.path.isfile('202503241818.txt')
            os.remove('202503241818.txt')
            assert result.exit_code == 0
            assert mock_get.call_count == 2
            assert get_data_length(result.output) == 1

    def test_dcs_app_in_public_list_by_all(self, runner):
        mock_responses = [(True, mock_public_app_list_by_all_demo)] * 3
        with patch('dcs_cli.commands.app._safe_request') as mock_get:
            mock_get.side_effect = mock_responses
            result = runner.invoke(main, ['app', 'ls', '-p', '-n', 'test'])
            assert get_params(result.output) == {'in': 'name', 'kw': 'test', 'limit': 10, 'page': 1,
                                                 'types': 'workflow'}
            assert result.exit_code == 0
            assert mock_get.call_count == 1
            assert get_data_length(result.output) == 1

            result = runner.invoke(main, ['app', 'ls', '-p', '-n', 'test', '-a'])
            assert get_params(result.output) == {'in': 'name', 'kw': 'test', 'limit': MAX_DIRECT_PRINT_PAGESIZE,
                                                 'page': 1, 'types': 'workflow'}
            assert result.exit_code == 0
            assert mock_get.call_count == 2
            assert get_data_length(result.output) == 1

            result = runner.invoke(main, ['app', 'ls', '-p', '-n', 'test', '--all'])
            assert get_params(result.output) == {'in': 'name', 'kw': 'test', 'limit': MAX_DIRECT_PRINT_PAGESIZE,
                                                 'page': 1, 'types': 'workflow'}
            assert result.exit_code == 0
            assert mock_get.call_count == 3
            assert get_data_length(result.output) == 1

        mock_responses = [
            (True, mock_public_app_list_by_all_demo_2),
        ]
        with patch('dcs_cli.commands.app._safe_request') as mock_get:
            mock_get.side_effect = mock_responses
            result = runner.invoke(main, ['app', 'ls', '-p', '-n', 'test', '-a'])
            assert get_params(result.output) == {'in': 'name', 'kw': 'test', 'limit': MAX_DIRECT_PRINT_PAGESIZE,
                                                 'page': 1, 'types': 'workflow'}
            assert result.exit_code == 0
            assert mock_get.call_count == 1
            assert get_data_length(result.output) == 13

        mock_responses = [
            (True, mock_public_app_list_by_all_max_print_ii),
            (True, mock_public_app_list_by_all_max_print),
        ]
        with patch('dcs_cli.commands.app._safe_request') as mock_get:
            mock_get.side_effect = mock_responses
            result = runner.invoke(main, ['app', 'ls', '-p', '-n', 'test', '-a'])
            assert get_params(result.output) == {'in': 'name', 'kw': 'test', 'limit': MAX_DIRECT_PRINT_PAGESIZE,
                                                 'page': 1,
                                                 'types': 'workflow'}
            assert result.exit_code == 0
            assert mock_get.call_count == 1
            assert get_data_length(result.output) == 1888

            output_path = '202503241818.txt'
            result = runner.invoke(main, ['app', 'ls', '-p', '-n', 'test', '-a', '-o', output_path])
            assert get_params(result.output) == {'in': 'name', 'kw': 'test', 'limit': MAX_OUTPUT_PAGESIZE, 'page': 1,
                                                 'types': 'workflow'}
            res_outpust = result.output.replace('\n', '')
            assert output_path in res_outpust
            assert os.path.isfile('202503241818.txt')
            os.remove('202503241818.txt')
            assert result.exit_code == 0
            assert mock_get.call_count == 2
            assert get_data_length(result.output) == 2000

    def test_dcs_app_in_project_list_by_output(self, runner):
        mock_responses = [
            (True, mock_project_app_list_by_all_demo),
        ]
        with patch('dcs_cli.commands.app._safe_request') as mock_get:
            mock_get.side_effect = mock_responses
            with patch('dcs_cli.commands.app.output_file') as mock_output_file:
                mock_output_file.return_value = (False, 'xxx')
                output_path = '202503241818.txt'
                result = runner.invoke(main, ['app', 'ls', '-n', 'test', '-a', '-o', output_path])
                assert get_params(result.output) == {'offset': 0, 'page_size': MAX_OUTPUT_PAGESIZE,
                                                     'project': 'P1871461072416366593', 'name': 'test'}
                res_out = result.output.replace('\n', '')
                assert f'文件生成失败：xxx' in res_out
        mock_responses = [
            (True, mock_project_app_list_by_all_max_output),
            (True, mock_project_app_list_by_all_demo),
            (True, mock_project_app_list_by_all_demo),
        ]
        with patch('dcs_cli.commands.app._safe_request') as mock_get:
            mock_get.side_effect = mock_responses
            output_path = '202503241818.txt'
            result = runner.invoke(main, ['app', 'ls', '-n', 'test', '-a', '-o', output_path])
            assert get_params(result.output) == {'offset': 0, 'page_size': MAX_OUTPUT_PAGESIZE,
                                                 'project': 'P1871461072416366593', 'name': 'test'}
            res_out = result.output.replace('\n', '')
            assert output_path in res_out
            assert os.path.isfile('202503241818.txt')
            os.remove('202503241818.txt')
            assert result.exit_code == 0
            assert mock_get.call_count == 1
            assert get_data_length(result.output) == 2003

            result = runner.invoke(main, ['app', 'ls', '-n', 'test', '-o', output_path])
            assert get_params(result.output) == {'offset': 0, 'page_size': 10,
                                                 'project': 'P1871461072416366593', 'name': 'test'}
            assert result.exit_code == 0
            assert mock_get.call_count == 2
            res_out = result.output.replace('\n', '')
            assert output_path in res_out
            assert os.path.isfile('202503241818.txt')
            os.remove('202503241818.txt')
            assert get_data_length(result.output) == 1

            result = runner.invoke(main, ['app', 'ls', '-n', 'test', '--output', output_path])
            assert get_params(result.output) == {'offset': 0, 'page_size': 10,
                                                 'project': 'P1871461072416366593', 'name': 'test'}
            assert result.exit_code == 0
            assert mock_get.call_count == 3
            assert get_data_length(result.output) == 1
            res_out = result.output.replace('\n', '')
            assert output_path in res_out
            assert os.path.isfile('202503241818.txt')
            os.remove('202503241818.txt')

    def test_dcs_app_in_project_list_by_all(self, runner):
        mock_responses = [(True, mock_project_app_list_by_all_demo)] * 3
        with patch('dcs_cli.commands.app._safe_request') as mock_get:
            mock_get.side_effect = mock_responses
            result = runner.invoke(main, ['app', 'ls', '-n', 'test'])
            assert get_params(result.output) == {'offset': 0, 'page_size': 10,
                                                 'project': 'P1871461072416366593', 'name': 'test'}
            assert result.exit_code == 0
            assert mock_get.call_count == 1
            assert get_data_length(result.output) == 1

            result = runner.invoke(main, ['app', 'ls', '-n', 'test', '-a'])
            assert get_params(result.output) == {'offset': 0, 'page_size': MAX_DIRECT_PRINT_PAGESIZE,
                                                 'project': 'P1871461072416366593', 'name': 'test'}
            assert result.exit_code == 0
            assert mock_get.call_count == 2
            assert get_data_length(result.output) == 1

            result = runner.invoke(main, ['app', 'ls', '-n', 'test', '--all'])
            assert get_params(result.output) == {'offset': 0, 'page_size': MAX_DIRECT_PRINT_PAGESIZE,
                                                 'project': 'P1871461072416366593', 'name': 'test'}
            assert result.exit_code == 0
            assert mock_get.call_count == 3
            assert get_data_length(result.output) == 1

        mock_responses = [
            (True, mock_project_app_list_by_all_demo_3),
            (True, mock_project_app_list_by_all_demo_4),
        ]
        with patch('dcs_cli.commands.app._safe_request') as mock_get:
            mock_get.side_effect = mock_responses
            result = runner.invoke(main, ['app', 'ls', '-n', 'test', '-a'])
            assert get_params(result.output) == {'offset': 0, 'page_size': MAX_DIRECT_PRINT_PAGESIZE,
                                                 'project': 'P1871461072416366593', 'name': 'test'}
            assert result.exit_code == 0
            assert mock_get.call_count == 1
            assert get_data_length(result.output) == 1888

            result = runner.invoke(main, ['app', 'ls', '-n', 'test', '--all'])
            assert get_params(result.output) == {'offset': 0, 'page_size': MAX_DIRECT_PRINT_PAGESIZE,
                                                 'project': 'P1871461072416366593', 'name': 'test'}
            assert result.exit_code == 0
            assert mock_get.call_count == 2
            assert get_data_length(result.output) == 2000

    def test_dcs_app_in_public_query_by_user(self, runner):
        # 测试公共库的应用情况，通过user查询
        result = runner.invoke(main, ['app', 'ls', '-p', '-u', 'SAW-ST-V6-'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-p', '-u', 'wenzhenbin'])
        assert get_data_length(result.output) == 4
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-p', '-u', 'WENZHENBIN'])
        assert get_data_length(result.output) == 4
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-p', '--user', 'wenzhenbin'])
        assert get_data_length(result.output) == 4
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-p', '-u', 'wenzhenbin1'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

    def test_dcs_app_in_public_query_by_tag(self, runner):
        # 测试公共库的应用情况，通过tag查询
        result = runner.invoke(main, ['app', 'ls', '-p', '-t', 'Epigenomics,Genomics,Metabolomics', '-n', 'zhen_test'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-p', '-t', 'Genomics', '-n', 'zhen_test'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-p', '--tag', 'Metabolomics', '-n', 'zhen_test'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

    def test_dcs_app_in_public_query_by_others(self, runner):
        # 测试公共库的应用情况
        # name + tag
        result = runner.invoke(main, ['app', 'ls', '-p', '--tag', 'Genomics,Metabolomics', '-n', 'SAW-111'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-p', '--tag', 'Genomics,Metabolomics', '-n', 'zhen_test'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-p', '--tag', 'Genomics,Metabolomics', '-n', 'zhen_test', '-a'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        # name + user
        result = runner.invoke(main, ['app', 'ls', '-p', '-u', 'wenzhenbin', '-n', 'zhen_test'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-u', 'wenzhenbin', '-pn', 'zhen_test'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-pu', 'wenzhenbin', '-n', 'zhen_test'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-p', '-u', 'WENZHENBIN', '-n', 'zhen_test'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-p', '-u', 'WENZHENBIN', '-n', 'zhen_test', '-a'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-pau', 'WENZHENBIN', '-n', 'zhen_test'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-p', '-u', 'WENZHENBIN', '-n', 'ZHEN_TEST'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-p', '-u', 'liuliu', '-n', 'test'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-p', '-u', 'wenzhenbin', '-n', 'test168168111111111111111'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

        # tag + user
        result = runner.invoke(main, ['app', 'ls', '-p', '--tag', 'Genomics,Metabolomics', '-u', 'wenzhenbin'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-p', '--tag', 'Genomics,Metabolomics', '-u', 'wenzhenbin', '-a'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-p', '--tag', 'Genomics,Metabolomics', '-u', 'wenzhenbin1'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

        # tag + user + name
        result = runner.invoke(main, ['app', 'ls', '-p', '--tag', 'Genomics,Metabolomics', '-u', 'wenzhenbin', '-n',
                                      'zhen_test'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-p', '--tag', 'Genomics,Metabolomics', '-u', 'wenzhenbin', '-n',
                                      'zhen_test', '-a'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main,
                               ['app', 'ls', '-p', '--tag', 'Genomics,Microbiomics', '-u', 'wenzhenbin111', '-n',
                                'SAW-'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

        result = runner.invoke(main,
                               ['app', 'ls', '-p', '--tag', 'Genomics,Microbiomics', '-u', 'wenzhenbin111', '-n',
                                'SAW-', '-a'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-p', '--tag', 'Genomics,Microbiomics', '-u', 'wenzhenbin', '-n',
                                      'zhen_test-11111'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

    @set_env(DCS_PROJECT_ID="P20250328172629834")
    def test_dcs_app_in_project_query_by_user(self, runner):
        # 测试项目中的镜像情况，按照用户查询
        result = runner.invoke(main, ['app', 'ls', '--user', 'bgi-skzx-test1'])
        assert get_data_length(result.output) == 2
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '--user', 'WENZHENBIN', '-a'])
        assert get_data_length(result.output) == 11
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '--user', 'wenzhenbin1'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-u', 'wenzhenbin1'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

    @set_env(DCS_PROJECT_ID="P20250328172629834")
    def test_dcs_app_in_project_query_by_tag(self, runner):
        # 测试项目中的镜像情况，按照tag查询
        result = runner.invoke(main, ['app', 'ls', '--tag', 'Genomics'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '--tag', 'Genomics1'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

    @set_env(DCS_PROJECT_ID="P20250328172629834")
    def test_dcs_app_in_project_query_by_others(self, runner):
        # 测试项目中的镜像情况
        result = runner.invoke(main, ['app', 'ls', '--tag', 'Epigenomics', '-n', "Copy-pref_test"])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '--tag', 'Epigenomics', '-n', "Copy-pref_test1"])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '--tag', 'Epigenomics', '-n', "Copy-pref_test", '-u', 'WENZHENBIN'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '--tag', 'Epigenomics', '-n', "Copy-pref_test", '-u', 'wenzhenbin1'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '--tag', 'Epigenomics', '-u', 'wenzhenbin'])
        assert get_data_length(result.output) == 3
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '--tag', 'Epigenomics', '-u', 'wenzhenbin1'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '--tag', 'Genomics0', '-u', 'wenzhenbin'])
        assert get_data_length(result.output) == 0

        result = runner.invoke(main, ['app', 'ls', '-n', "Copy-pref_test", '-u', 'wenzhenbin'])
        assert get_data_length(result.output) == 1
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'ls', '-n', "Copy-pref_test", '-u', 'wenzhenbin1'])
        assert get_data_length(result.output) == 0
        assert result.exit_code == 0

    def test_dcs_app_ls_exception(self, runner):
        with patch('dcs_cli.commands.app._safe_request') as mock_get:
            mock_get.return_value = 'str'
            result = runner.invoke(main, ['app', 'ls'])
            assert "查询数据失败。" in result.output.replace('\n', '')
            assert result.exit_code == 0

            mock_get.return_value = (False, 'xxxxx')
            result = runner.invoke(main, ['app', 'ls'])
            assert "xxxxx" == result.output.replace('\n', '')
            assert result.exit_code == 0


@pytest.mark.usefixtures('runner')
class TestAppPush:

    def test_no_perm_push(self, runner):
        with patch('dcs_cli.commands.app.get_user_perm') as mock_get_user_perm:
            mock_get_user_perm.return_value = (True, {'data': {'apiPerms': []}})
            result = runner.invoke(main, ['app', 'push', '-p', SUCCESSED_PATH])
            assert '无导入权限，不可执行dcs app push命令。' in result.output.replace('\n', '')
            assert result.exit_code == 0
            assert mock_get_user_perm.call_count == 1

            mock_get_user_perm.return_value = (True, {'data': {'apiPerms': [WORKFLOW_COPY_PERM]}})
            result = runner.invoke(main, ['app', 'push', '-p', SUCCESSED_PATH])
            assert '无导入权限，不可执行dcs app push命令。' in result.output.replace('\n', '')
            assert result.exit_code == 0
            assert mock_get_user_perm.call_count == 2

            mock_get_user_perm.return_value = (False, 'xxx')
            result = runner.invoke(main, ['app', 'push', '-p', SUCCESSED_PATH])
            assert 'xxx' in result.output.replace('\n', '')
            assert result.exit_code == 0
            assert mock_get_user_perm.call_count == 3

    def test_handle_special_data_mock(self):
        with patch('dcs_cli.commands.app.get_user_perm') as mock_get:
            mock_get.return_value = (True, {'data': {'apiPerms': [WORKFLOW_IMPORT_PERM]}})
            perm_list = []
            user_info = {'username': 'wenzhenbin'}
            req_data = mock_repeat_demo['repeat_list']
            req_data, renames = handle_special_data(perm_list, req_data, user_info)
            assert len(req_data) == 2
            assert len(renames) == 0

            req_data = mock_repeat_demo_1['repeat_list']
            req_data, renames = handle_special_data(perm_list, req_data, user_info)
            assert len(req_data) == 2
            assert len(renames) == 0

            req_data = mock_repeat_demo_2['repeat_list']
            req_data, renames = handle_special_data(perm_list, req_data, user_info)
            assert len(req_data) == 1
            assert len(renames) == 1

            req_data = mock_repeat_demo_3['repeat_list']
            req_data, renames = handle_special_data(perm_list, req_data, user_info)
            assert len(req_data) == 1
            assert len(renames) == 2

            req_data = mock_repeat_demo_4['repeat_list']
            req_data, renames = handle_special_data(perm_list, req_data, user_info)
            assert len(req_data) == 2
            assert len(renames) == 2

            req_data = mock_repeat_demo_5['repeat_list']
            req_data, renames = handle_special_data(perm_list, req_data, user_info)
            assert len(req_data) == 1
            assert len(renames) == 3

            req_data = mock_repeat_demo_6['repeat_list']
            req_data, renames = handle_special_data(perm_list, req_data, user_info)
            assert len(req_data) == 0
            assert len(renames) == 4

            perm_list = ['project_management:workflow_analysis:workflow:edit']
            req_data = mock_repeat_demo_4['repeat_list']
            req_data, renames = handle_special_data(perm_list, req_data, user_info)
            assert len(req_data) == 3
            assert len(renames) == 1

            req_data = mock_repeat_demo_5['repeat_list']
            req_data, renames = handle_special_data(perm_list, req_data, user_info)
            assert len(req_data) == 3
            assert len(renames) == 1

            req_data = mock_repeat_demo_6['repeat_list']
            req_data, renames = handle_special_data(perm_list, req_data, user_info)
            assert len(req_data) == 1
            assert len(renames) == 3

    def test_dcs_app_push_mock(self, runner):
        with patch('dcs_cli.commands.app.get_user_perm') as mock_get_user_perm:
            mock_get_user_perm.return_value = (True, {'data': {'apiPerms': [WORKFLOW_IMPORT_PERM]}})
            failed_path = r'C:\Users\wenzhenbin\Desktop\work\dcs_clients\test_data\push_data\111.zip'
            result = runner.invoke(main, ['app', 'push', '-p', failed_path])
            assert 'Missing info file, please check the import file.' in result.output.replace('\n', '')

            mock_responses = [
                (True, {'data': {'repeat_list': [], 'normal_list': ['123', '456']}}),
                (True, {}),
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                result = runner.invoke(main, ['app', 'push', '-p', SUCCESSED_PATH])
                assert """"rename": ["123", "456"]""" in result.output.replace('\n', '')
                assert """overwrite": []""" in result.output.replace('\n', '')
                assert result.exit_code == 0
                assert mock_get.call_count == 2

            mock_responses = [
                                 (True, {'data': {'repeat_list': ['3', '4'], 'normal_list': ['1', '2']}}),
                                 (True, {}),
                             ] * 3
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                with patch('dcs_cli.commands.app.handle_special_data') as mock_handle_special_data:
                    mock_handle_special_data.return_value = ['3', '4'], []
                    with patch('dcs_cli.commands.app.handle_repeat_data') as mock_handle_repeat_data:
                        # overwrite_list, rename_list
                        mock_handle_repeat_data.return_value = ['3'], ['4']
                        result = runner.invoke(main, ['app', 'push', '-p', SUCCESSED_PATH])
                        assert """"rename": ["4", "1", "2"]""" in result.output.replace('\n', '')
                        assert """overwrite": ["3"]""" in result.output.replace('\n', '')
                        assert result.exit_code == 0
                        assert mock_get.call_count == 2

                        mock_handle_repeat_data.return_value = ['3', '4'], []
                        result = runner.invoke(main, ['app', 'push', '-p', SUCCESSED_PATH])
                        assert """"rename": ["1", "2"]""" in result.output.replace('\n', '')
                        assert """overwrite": ["3", "4"]""" in result.output.replace('\n', '')
                        assert result.exit_code == 0
                        assert mock_get.call_count == 4

                        mock_handle_repeat_data.return_value = [], ['3', '4']
                        result = runner.invoke(main, ['app', 'push', '-p', SUCCESSED_PATH])
                        assert """"rename": ["3", "4", "1", "2"]""" in result.output.replace('\n', '')
                        assert """overwrite": []""" in result.output.replace('\n', '')
                        assert result.exit_code == 0
                        assert mock_get.call_count == 6

    def test_dcs_app_push_exception(self, runner):
        with patch('dcs_cli.commands.app.get_user_perm') as mock_get_user_perm:
            mock_get_user_perm.return_value = (True, {'data': {'apiPerms': [WORKFLOW_IMPORT_PERM]}})
            result = runner.invoke(main, ['app', 'push', '-p', './168168'])
            assert "文件路径“./168168”不存在，请检查路径是否存在当前容器中。" == result.output.replace('\n', '')
            assert result.exit_code == 0

            result = runner.invoke(main, ['app', 'push', '-p', WDL_PATH])
            assert f"文件“{WDL_PATH}”不符合规范，当前仅支持“.zip”后缀的文件。" == result.output.replace('\n', '')
            assert result.exit_code == 0

            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.return_value = (False, 'validate zip failed')
                failed_path = r'C:\Users\wenzhenbin\Desktop\work\dcs_clients\test_data\push_data\workflow_export.zip'
                result = runner.invoke(main, ['app', 'push', '-p', failed_path])
                assert 'validate zip failed' in result.output.replace('\n', '')

            mock_responses = [
                (False, {'msg': 'test app push failed.'}),
                (True, {}),
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                result = runner.invoke(main, ['app', 'push', '-p', SUCCESSED_PATH])
                assert 'test app push failed.' in result.output.replace('\n', '')
                assert result.exit_code == 0
                assert mock_get.call_count == 1

            mock_responses = [
                (True, {'msg': 'test app push failed.'}),
                (True, {}),
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                result = runner.invoke(main, ['app', 'push', '-p', SUCCESSED_PATH])
                assert '注册流程失败。' in result.output.replace('\n', '')
                assert result.exit_code == 0
                assert mock_get.call_count == 1

            mock_responses = [
                (True, {'data': {'repeat_list': [], 'normal_list': ['123']}}),
                (False, 'test app push failed.'),
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                result = runner.invoke(main, ['app', 'push', '-p', SUCCESSED_PATH])
                assert "test app push failed." in result.output.replace('\n', '')
                assert result.exit_code == 0
                assert mock_get.call_count == 2


@pytest.mark.usefixtures('runner')
class TestAppInfo:

    def test_no_perm_info(self, runner):
        with patch('dcs_cli.commands.app.get_user_perm') as mock_get_user_perm:
            mock_get_user_perm.return_value = (True, {'data': {'apiPerms': []}})
            result = runner.invoke(main, ['app', 'info', '-n', 'successed_path'])
            assert '无查看详情权限，不可执行dcs app info命令。' in result.output.replace('\n', '')
            assert result.exit_code == 0
            assert mock_get_user_perm.call_count == 1

            mock_get_user_perm.return_value = (False, 'xxx')
            result = runner.invoke(main, ['app', 'info', '-n', 'successed_path'])
            assert 'xxx' in result.output.replace('\n', '')
            assert result.exit_code == 0
            assert mock_get_user_perm.call_count == 2

            mock_get_user_perm.return_value = (True, {'data': {'apiPerms': [WORKFLOW_COPY_PERM]}})
            result = runner.invoke(main, ['app', 'info', '-n', 'successed_path'])
            assert '无查看详情权限，不可执行dcs app info命令。' in result.output.replace('\n', '')
            assert result.exit_code == 0
            assert mock_get_user_perm.call_count == 3

            mock_get_user_perm.return_value = (True, {'data': 'apiPerms'})
            result = runner.invoke(main, ['app', 'info', '-n', 'successed_path'])
            assert '查询数据失败。' in result.output.replace('\n', '')
            assert result.exit_code == 0
            assert mock_get_user_perm.call_count == 4

    def test_info_error(self, runner):
        with patch('dcs_cli.commands.app._safe_request') as mock_safe_request:
            mock_safe_request.return_value = (False, 'xxxx')
            result = runner.invoke(main, ['app', 'info', '-n', 'successed_path', '-p'])
            assert 'xxx' in result.output.replace('\n', '')
            assert result.exit_code == 0

        reps_mock = [
            (True, {'data': {'total': 1, 'records': [{'oid': '168'}]}}),
            (False, 'yyyyy'),
            (True, {'data': {'total': 1, 'records': [{'oid': '168'}]}}),
            (True, {})
        ]
        with patch('dcs_cli.commands.app._safe_request') as mock_safe_request:
            mock_safe_request.side_effect = reps_mock
            result = runner.invoke(main, ['app', 'info', '-n', 'successed_path', '-p'])
            assert 'yyyyy' in result.output.replace('\n', '')
            assert result.exit_code == 0
            assert mock_safe_request.call_count == 2

            result = runner.invoke(main, ['app', 'info', '-n', 'successed_path', '-p'])
            assert '找不到名称为“successed_path”的应用。请使用“dcs app ls -p”查找所有可用应用。' in result.output.replace(
                '\n', '')
            assert result.exit_code == 0
            assert mock_safe_request.call_count == 4

        with patch('dcs_cli.commands.app.get_user_perm') as mock_get_user_perm:
            mock_get_user_perm.return_value = (True, {'data': {'apiPerms': [WORKFLOW_DETAIL_PERM]}})
            reps_mock = [
                (False, 'yyyyyy'),
                (True, {'error_type': 'WDL failed', 'message': 'test failed'}),
                (True, {})
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_safe_request:
                mock_safe_request.side_effect = reps_mock
                result = runner.invoke(main, ['app', 'info', '-n', 'successed_path'])
                assert 'yyyyyy' in result.output.replace('\n', '')
                assert result.exit_code == 0
                assert mock_safe_request.call_count == 1

                result = runner.invoke(main, ['app', 'info', '-n', 'successed_path'])
                assert 'test failed' in result.output.replace('\n', '')
                assert result.exit_code == 0
                assert mock_safe_request.call_count == 2

                result = runner.invoke(main, ['app', 'info', '-n', 'successed_path'])
                assert '找不到名称为“successed_path”的应用。请使用“dcs app ls”查找所有可用应用。' in result.output.replace(
                    '\n', '')
                assert result.exit_code == 0
                assert mock_safe_request.call_count == 3

    def test_dcs_app_info_in_public_query_by_name(self, runner):
        result = runner.invoke(main, ['app', 'info', '-n', 'SAW1111111111', '--public'])
        msg = result.output.replace('\n', '')
        assert '找不到名称为“SAW1111111111”的应用。请使用“dcs app ls -p”查找所有可用应用。' in msg

        result = runner.invoke(main, ['app', 'info', '-n', 'SAW-ST-V7-registration(2)', '--public'])
        msg = result.output.replace('\n', '')
        assert get_data_length(msg) == 1
        assert result.exit_code == 0
        for info in ['脚本信息', '相关链接']:
            assert info not in msg
        for info in ['费用说明', '1 - 2', '100', '3 - 6', '8折', '80', '≥ 7', '6折', '60']:
            assert info in msg

        result = runner.invoke(main, ['app', 'info', '-n', 'VT1.1.1', '--public'])
        msg = result.output.replace('\n', '')
        assert get_data_length(msg) == 1
        assert result.exit_code == 0
        for info in ['脚本信息', '相关链接']:
            assert info not in msg
        for info in ['费用说明', '999.99']:
            assert info in msg

        result = runner.invoke(main, ['app', 'info', '-n', 'workflow_401_paid', '--public'])
        msg = result.output.replace('\n', '')
        assert get_data_length(msg) == 1
        assert result.exit_code == 0
        for info in ['脚本信息', '相关链接']:
            assert info not in msg
        for info in ['费用说明', '9折', '10', '9']:
            assert info in msg

        for name in ['workflow_327_01', 'pref_test', 'workflow_401_1']:
            result = runner.invoke(main, ['app', 'info', '-n', name, '--public'])
            msg = result.output.replace('\n', '')
            assert get_data_length(msg) == 1
            assert result.exit_code == 0
            for info in ['费用说明']:
                assert info not in msg
            for info in ['脚本信息', '相关链接']:
                assert info in msg

    def test_dcs_app_info_in_public_query_by_name_and_version(self, runner):
        result = runner.invoke(main,
                               ['app', 'info', '-n', 'SAW-ST-V7-registration(2)', '--public', '--version', '1.1.0'])
        msg = result.output.replace('\n', '')
        assert result.exit_code == 0
        assert '找不到名称为“SAW-ST-V7-registration(2)”、版本为“1.1.0”的应用。请使用“dcs app ls' in msg

        result = runner.invoke(main, ['app', 'info', '-n', 'VT1.1.1', '--public', '--version', '1.1.0'])
        msg = result.output.replace('\n', '')
        assert get_data_length(msg) == 1
        assert result.exit_code == 0
        for info in ['脚本信息', '相关链接']:
            assert info not in msg
        for info in ['费用说明', '999.99']:
            assert info in msg

        result = runner.invoke(main, ['app', 'info', '-n', 'pref_test', '-p', '-v', '4.0.0'])
        msg = result.output.replace('\n', '')
        assert get_data_length(msg) == 1
        assert result.exit_code == 0
        for info in ['费用说明']:
            assert info not in msg
        for info in ['脚本信息', '相关链接']:
            assert info in msg

    @set_env(DCS_PROJECT_ID="P20250328172629834")
    def test_dcs_app_info_in_project_query_by_name(self, runner):
        with patch('dcs_cli.commands.app.get_user_perm') as mock_get_user_perm:
            mock_get_user_perm.return_value = (True, {'data': {'apiPerms': [WORKFLOW_DETAIL_PERM]}})
            result = runner.invoke(main, ['app', 'info', '-n', 'demo_bill_private_discount'])
            msg = result.output.replace('\n', '')
            assert get_data_length(msg) == 1
            assert result.exit_code == 0
            for info in ['脚本信息', '相关链接', '100', '90', '1 - 2']:
                assert info in msg

            result = runner.invoke(main, ['app', 'info', '-n', 'd11111111111', '-v', '99999999999'])
            msg = result.output.replace('\n', '')
            assert 'The Workflow: name: d11111111111, version: 99999999999 does not found!' in msg

            result = runner.invoke(main, ['app', 'info', '-n', 'Copy-workflow_401_paid'])
            msg = result.output.replace('\n', '')
            assert get_data_length(msg) == 1
            assert result.exit_code == 0
            for info in ['脚本信息', '相关链接']:
                assert info not in msg
            for info in ['9折', '10', '费用说明']:
                assert info in msg

            result = runner.invoke(main, ['app', 'info', '-n', 'demo_bill_private(1)'])
            msg = result.output.replace('\n', '')
            assert get_data_length(msg) == 1
            assert result.exit_code == 0
            assert '相关链接' not in msg
            for info in ['脚本信息', '168', '费用说明']:
                assert info in msg

            for name in ['demo_free_public(1)', 'demo_bill_private', 'demo_free_public', 'Copy-workflow_328',
                         'Copy-workflow_327_01', 'Copy-workflow_401_1']:
                result = runner.invoke(main, ['app', 'info', '-n', name])
                msg = result.output.replace('\n', '')
                assert get_data_length(msg) == 1
                assert result.exit_code == 0
                for info in ['脚本信息', '相关链接']:
                    assert info in msg

            result = runner.invoke(main, ['app', 'info', '-n', 'demo_bill_private_discount1'])
            assert "The Workflow: name: demo_bill_private_discount1 does not found!" in result.output.replace('\n', '')
            assert result.exit_code == 0

    @set_env(DCS_PROJECT_ID="P20250328172629834")
    def test_dcs_app_info_in_project_query_by_name_and_version(self, runner):
        with patch('dcs_cli.commands.app.get_user_perm') as mock_get_user_perm:
            mock_get_user_perm.return_value = (True, {'data': {'apiPerms': [WORKFLOW_DETAIL_PERM]}})
            result = runner.invoke(main, ['app', 'info', '-n', 'SAW-ST-V7-registration(1)', '-v', '8.0.0'])
            msg = result.output.replace('\n', '')
            assert 'The Workflow: name: SAW-ST-V7-registration(1), version: 8.0.0 does not found!' in msg

            mock_get_user_perm.return_value = (True, {'data': {'apiPerms': [WORKFLOW_DETAIL_PERM]}})
            result = runner.invoke(main, ['app', 'info', '-n', 'SAW-ST-V7-registration(11)', '-v', '8.0.0'])
            msg = result.output.replace('\n', '')
            assert 'The Workflow: name: SAW-ST-V7-registration(11)' in msg

            result = runner.invoke(main, ['app', 'info', '-n', 'Copy-workflow_401_1', '--version', '1.0.0'])
            msg = result.output.replace('\n', '')
            assert get_data_length(msg) == 1
            assert result.exit_code == 0
            for info in ['脚本信息', '相关链接']:
                assert info in msg

            result = runner.invoke(main, ['app', 'info', '-n', 'Copy-workflow_401_1', '-v', '7.0.0'])
            msg = result.output.replace('\n', '')
            assert result.exit_code == 0
            assert 'The Workflow: name: Copy-workflow_401_1, version: 7.0.0 does not found!' in msg


@pytest.mark.usefixtures('runner')
class TestAppValidate:

    def test_dcs_app_validate(self, runner):
        # 测试正常情况
        result = runner.invoke(main, ['app', 'validate', '-p', WDL_PATH])
        assert f"WDLError: " in result.output.replace('\n', '')

        # 测试wdl异常
        wdl_failed_path = (
            r'C:\Users\wenzhenbin\Desktop\work\dcs_clients\test_data\validate_data\Chips_scRNA_singlespecies_V1.1.1'
            r'_failed\Chips_scRNA_singlespecies_V1.1.1.wdl')
        result = runner.invoke(main, ['app', 'validate', '-p', wdl_failed_path])
        assert "row: 2 col: 8" in result.output.replace('\n', '')

        # 测试没有依赖
        wdl_failed_path_ii = (
            r'C:\Users\wenzhenbin\Desktop\work\dcs_clients\test_data\validate_data\Chips_scRNA_singlespecies_V1.1.'
            r'1_failedII\Chips_scRNA_singlespecies_V1.1.1.wdl')
        result = runner.invoke(main, ['app', 'validate', '-p', wdl_failed_path_ii])
        assert (" Failed to import Chips_scRNA_singlespecies_V2.task/Chips_scRNA_singlespecies_V2.task.wdl" in
                result.output.replace('\n', ''))

    def test_dcs_app_validate_exception(self, runner):
        result = runner.invoke(main, ['app', 'validate', '-p', './168168'])
        assert "文件路径“./168168”不存在，请检查路径是否存在当前容器中。" == result.output.replace('\n', '')
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'validate', '-p', SUCCESSED_PATH])
        assert f"文件“{SUCCESSED_PATH}”不符合规范，当前仅支持“.wdl”后缀的文件。" == result.output.replace('\n', '')
        assert result.exit_code == 0

        result = runner.invoke(main, ['app', 'validate', '-p', r'C:\Users\wenzhenbin\Desktop\work\dcs_clients\test_d'
                                                               r'ata\validate_data\workflow_test_319_01_1.0.0_jx.wdl'])
        assert f"WDLError:" in result.output.replace('\n', '')
        assert result.exit_code == 0

        with patch('dcs_cli.commands.app._safe_request') as mock_get:
            mock_get.return_value = (False, 'test dcs app validate failed.')
            result = runner.invoke(main, ['app', 'validate', '-p', WDL_PATH])
            assert "test dcs app validate failed." in result.output.replace('\n', '')
            assert result.exit_code == 0

            mock_get.return_value = (True, '111')
            result = runner.invoke(main, ['app', 'validate', '-p', WDL_PATH])
            assert (f"校验失败：{WDL_PATH}。") in result.output.replace('\n', '')
            assert result.exit_code == 0

            mock_get.return_value = (True, {"code": 0})
            result = runner.invoke(main, ['app', 'validate', '-p', WDL_PATH])
            assert (f"校验成功：{WDL_PATH}。") in result.output.replace('\n', '')
            assert result.exit_code == 0

            mock_get.return_value = (True, {
                "message": "An internal error occurred!",
                "message_i18n": "An internal error occurred!",
                "error_type": "IndexError"
            })
            result = runner.invoke(main, ['app', 'validate', '-p', WDL_PATH])
            assert (f"校验失败：{WDL_PATH}。") in result.output.replace('\n', '')
            assert result.exit_code == 0

            mock_get.return_value = (True, {
                "error_type": "WDLError",
                "error_infos": [
                    {
                        "errorMsg": "duplicate call input 'NewName'",
                        "row": 11,
                        "col": 9,
                        "filename": "WDL",
                        "errorCode": "input:"
                    }
                ]
            })
            result = runner.invoke(main, ['app', 'validate', '-p', WDL_PATH])
            assert f"filename: {WDL_PATH} row: 11 col: 9" in result.output.replace('\n', '')
            assert "WDLError: duplicate call input 'NewName'" in result.output.replace('\n', '')
            assert result.exit_code == 0


@pytest.mark.usefixtures('runner')
class TestAppPull:

    def test_create_dir(self, runner):
        with patch('dcs_cli.commands.app.create_dir') as mock_create_dir:
            mock_create_dir.return_value = (False, 'create_dir failed')
            result = runner.invoke(main, ['app', 'pull', '-n', 'xxx'])
            assert 'create_dir failed' in result.output.replace('\n', '')
            assert result.exit_code == 0

    def test_pull_app_failed(self, runner):
        with patch('dcs_cli.commands.app.get_user_perm') as mock_get_user_perm:
            mock_get_user_perm.return_value = (True, {'data': {'apiPerms': [WORKFLOW_COPY_PERM, WORKFLOW_EXPORT_PERM]}})
            mock_responses = [
                (True, {'data': {'records': [{'oid': '168'}]}}),
                (True, {'data': {'workflow_id_list': [123]}}),
                (True,
                 {'workflow_list': [{'name': 'xxx', 'version_list': [{'version': '1.0.0'}, {'version': '2.0.0'}]}]}),
                (False, 'xxx')
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                result = runner.invoke(main, ['app', 'pull', '-n', 'xxx', '--public'])
                msg = result.output.replace('\n', '')
                assert 'xxx' in msg
                assert result.exit_code == 0
                assert mock_get.call_count == 4

            mock_responses = [
                (False, 'get app failed'),
                (True, {}),
                (True, {'data': {'records': [{'oid': '168'}]}}),
                (False, 'xxx'),
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                result = runner.invoke(main, ['app', 'pull', '-n', 'xxx', '--public'])
                msg = result.output.replace('\n', '')
                assert 'get app failed' in msg
                assert result.exit_code == 0
                assert mock_get.call_count == 1

                result = runner.invoke(main, ['app', 'pull', '-n', 'xxx', '--public'])
                msg = result.output.replace('\n', '')
                assert '找不到名称为“xxx”的应用。请使用“dcs app ls -p”查找所有可用应用。' in msg
                assert result.exit_code == 0
                assert mock_get.call_count == 2

                result = runner.invoke(main, ['app', 'pull', '-n', 'xxx', '--public'])
                msg = result.output.replace('\n', '')
                assert 'xxx' in msg
                assert mock_get.call_count == 4
                assert result.exit_code == 0

            mock_responses = [
                (True, {'data': {'records': [{'oid': '168'}]}}),
                (True, {'data': {'workflow_id_list': [123]}}),
                (False, '34567'),
                (True, {'data': {'records': [{'oid': '168'}]}}),
                (True, {'data': {'workflow_id_list': [123]}}),
                (True, {})
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses

                result = runner.invoke(main, ['app', 'pull', '-n', 'xxx', '--public'])
                msg = result.output.replace('\n', '')
                assert '34567' in msg
                assert result.exit_code == 0
                assert mock_get.call_count == 3

                result = runner.invoke(main, ['app', 'pull', '-n', 'xxx', '--public'])
                msg = result.output.replace('\n', '')
                assert '拉取公共库的应用“xxx”失败。' in msg
                assert result.exit_code == 0
                assert mock_get.call_count == 6

    def test_return_info(self):
        msg = return_info('xxx', '1111', True)
        assert msg == '找不到名称为“xxx”、版本为“1111”的应用。请使用“dcs app ls -p”查找所有可用应用。' in msg

        msg = return_info('xxx', None, True)
        assert msg == '找不到名称为“xxx”的应用。请使用“dcs app ls -p”查找所有可用应用。' in msg

        msg = return_info('xxx', '1111', False)
        assert msg == '找不到名称为“xxx”、版本为“1111”的应用。请使用“dcs app ls”查找所有可用应用。' in msg

        msg = return_info('xxx', None, False)
        assert msg == '找不到名称为“xxx”的应用。请使用“dcs app ls”查找所有可用应用。' in msg

    def test_handle_price(self):
        msg = handle_price('')
        assert '' == msg
        msg = handle_price('0')
        assert 'free' == msg
        msg = handle_price(0)
        assert 'free' == msg
        msg = handle_price('0.00')
        assert 'free' == msg
        msg = handle_price('168')
        assert '168' == msg
        msg = handle_price(None)
        assert '' == msg

    def test_no_perm_pull(self, runner):
        with patch('dcs_cli.commands.app.get_user_perm') as mock_get_user_perm:
            mock_get_user_perm.return_value = (True, {'data': {'apiPerms': []}})
            result = runner.invoke(main, ['app', 'pull', '-n', 'xxx'])
            assert '无导出权限，不可执行dcs app pull命令。' in result.output.replace('\n', '')
            assert result.exit_code == 0
            assert mock_get_user_perm.call_count == 1

            mock_get_user_perm.return_value = (True, {'data': {'apiPerms': [WORKFLOW_EXPORT_PERM]}})
            result = runner.invoke(main, ['app', 'pull', '--name', 'xxx', '--public'])
            assert '无复制权限，不可从公共库复制工作流。' in result.output.replace('\n', '')
            assert result.exit_code == 0
            assert mock_get_user_perm.call_count == 2

            mock_get_user_perm.return_value = (True, 'xxxxxxxxx')
            result = runner.invoke(main, ['app', 'pull', '--name', 'xxx', '--public'])
            assert '拉取工具到本地失败。' in result.output.replace('\n', '')
            assert result.exit_code == 0

            mock_get_user_perm.return_value = (False, 'xxxxxxxxx')
            result = runner.invoke(main, ['app', 'pull', '--name', 'xxx', '--public'])
            assert 'xxxxxxxxx' in result.output.replace('\n', '')
            assert result.exit_code == 0

    @set_env(DCS_PROJECT_ID="P20250328172629834")
    def test_get_version_list(self):
        headers = _test_build_common_headers('access')
        status, info = get_version_list(PROJECT, BASE_URL, headers, 'test')
        assert not status
        assert "找不到名称为“test”的应用。请使用“dcs app ls”查找所有可用应用。" in info.replace('\n', '')

        status, info = get_version_list(PROJECT, BASE_URL, headers, 'test168168')
        assert not status
        assert "找不到名称为“test168168”的应用。请使用“dcs app ls”查找所有可用应用。" in info.replace('\n', '')

        status, info = get_version_list(PROJECT, BASE_URL, headers, 'Copy-pref_test')
        assert status
        assert ['4.0.0'] == info

        status, info = get_version_list(PROJECT, BASE_URL, headers, 'SAW-ST-V7-count')
        assert status
        assert sorted(['7.0.0', '7.0.1', '7.0.2', '7.0.3']) == sorted(info)

        with patch('dcs_cli.commands.app._safe_request') as mock_safe_request:
            mock_safe_request.return_value = (False, 'xxx')
            status, info = get_version_list(PROJECT, BASE_URL, headers, 'test168168')
            assert not status

    def test_pull_data_in_public(self, runner):
        with patch('dcs_cli.commands.app.get_user_perm') as mock_get_user_perm:
            mock_get_user_perm.return_value = (True, {'data': {'apiPerms': [WORKFLOW_EXPORT_PERM, WORKFLOW_COPY_PERM]}})
            result = runner.invoke(main, ['app', 'pull', '--public', '-n', '168168'])
            assert "找不到名称为“168168”的应用。请使用“dcs app ls -p”查找所有可用应用。" in result.output.replace('\n',
                                                                                                                '')
            assert result.exit_code == 0

            result = runner.invoke(main, ['app', 'pull', '--public', '--name', '168168'])
            assert "找不到名称为“168168”的应用。请使用“dcs app ls -p”查找所有可用应用。" in result.output.replace('\n',
                                                                                                                '')
            assert result.exit_code == 0

            result = runner.invoke(main, ['app', 'pull', '--public', '--name', 'SAW-ST-V7-registration', '-v', '1.0.0'])
            assert "参数public不能跟版本（version）号共用。" in result.output.replace('\n', '')
            assert result.exit_code == 0

            result = runner.invoke(main, ['app', 'pull', '--public', '--name', 'SAW-ST-V8'])
            assert "工具下载的路径为：" in result.output.replace('\n', '')
            delete_test_temp_file('./SAW-ST-V8*')
            assert result.exit_code == 0
            time.sleep(TIME_SECOND)

            result = runner.invoke(main, ['app', 'pull', '--public', '--name', 'SAW-ST-V5', '-v', '5.6.3'])
            assert "参数public不能跟版本（version）号共用。" in result.output.replace('\n', '')
            assert result.exit_code == 0

            result = runner.invoke(main, ['app', 'pull', '--public', '--name', 'SAW-ST-V7-registration', '-p',
                                          './test168168'])
            assert "工具下载的路径为：" in result.output.replace('\n', '')
            time.sleep(TIME_SECOND)
            shutil.rmtree(os.path.join('./test168168'))
            assert result.exit_code == 0

    def test_pull_data_in_project(self, runner):
        with patch('dcs_cli.commands.app.get_user_perm') as mock_get:
            mock_get.return_value = (True, {'data': {'apiPerms': [WORKFLOW_EXPORT_PERM, WORKFLOW_COPY_PERM]}})

            result = runner.invoke(main, ['app', 'pull', '--name', 'SAW-ST-V5'])
            assert "工具下载的路径为：" in result.output.replace('\n', '')
            delete_test_temp_file('./SAW-ST-V5*')
            assert result.exit_code == 0
            time.sleep(TIME_SECOND)

    @set_env(DCS_PROJECT_ID="P20250328172629834")
    def test_pull_data_in_project(self, runner):
        with patch('dcs_cli.commands.app.get_user_perm') as mock_get:
            mock_get.return_value = (True, {'data': {'apiPerms': [WORKFLOW_EXPORT_PERM, WORKFLOW_COPY_PERM]}})
            result = runner.invoke(main, ['app', 'pull', '-n', '168168'])
            assert "找不到名称为“168168”的应用。请使用“dcs app ls”查找所有可用应用。" in result.output.replace('\n', '')
            assert result.exit_code == 0

            result = runner.invoke(main, ['app', 'pull', '--name', '168168'])
            assert "找不到名称为“168168”的应用。请使用“dcs app ls”查找所有可用应用。" in result.output.replace('\n', '')
            assert result.exit_code == 0

            result = runner.invoke(main, ['app', 'pull', '--name', 'Copy-pref_test', '-v', '2.0.0'])
            assert "找不到名称为“Copy-pref_test”、版本为“2.0.0”的应用。请使用“dcs app ls”查找所有可用应用。" in result.output.replace(
                '\n', '')
            assert result.exit_code == 0

            result = runner.invoke(main, ['app', 'pull', '--name', 'Copy-pref_test', '-v', '4.0.0'])
            assert "工具下载的路径为：" in result.output.replace('\n', '')
            shutil.rmtree(os.path.join('./Copy-pref_test'))
            assert result.exit_code == 0
            time.sleep(TIME_SECOND)

            result = runner.invoke(main, ['app', 'pull', '--name', 'Copy-pref_test', '--version', '4.0.0'])
            assert "工具下载的路径为：" in result.output.replace('\n', '')
            shutil.rmtree(os.path.join('./Copy-pref_test'))
            assert result.exit_code == 0
            time.sleep(TIME_SECOND)

            result = runner.invoke(main,
                                   ['app', 'pull', '--name', 'Copy-pref_test', '--version', '4.0.0', '-p',
                                    './test168168'])
            assert "工具下载的路径为：" in result.output.replace('\n', '')
            time.sleep(TIME_SECOND)
            shutil.rmtree(os.path.join('./test168168'))
            assert result.exit_code == 0

            result = runner.invoke(main, ['app', 'pull', '-n', 'Copy-pref_test', '-p', './test168168'])
            assert "工具下载的路径为：" in result.output.replace('\n', '')
            shutil.rmtree(os.path.join('./test168168'))
            assert result.exit_code == 0


@pytest.mark.usefixtures('runner')
class TestAppUpdate:

    def test_no_perm_update(self, runner):
        with patch('dcs_cli.commands.app.get_user_perm') as mock_get_user_perm:
            mock_get_user_perm.return_value = (True, {'data': {'apiPerms': []}})
            result = runner.invoke(main, ['app', 'update', '-n', 'xxx'])
            assert '无更新权限，不可执行dcs app update命令。' in result.output.replace('\n', '')
            assert result.exit_code == 0
            assert mock_get_user_perm.call_count == 1

            result = runner.invoke(main, ['app', 'update', '--name', 'xxx'])
            assert '无更新权限，不可执行dcs app update命令。' in result.output.replace('\n', '')
            assert result.exit_code == 0
            assert mock_get_user_perm.call_count == 2

            mock_get_user_perm.return_value = (False, '11111111')
            result = runner.invoke(main, ['app', 'update', '-n', 'xxx'])
            assert '11111111' in result.output.replace('\n', '')
            assert result.exit_code == 0

    # 参数化测试用例
    @pytest.mark.parametrize("mock_input, expected_ids", mock_get_update_ids)
    def test_get_update_ids(self, mock_input, expected_ids):
        """ 模拟不同用户输入场景 """
        # 使用嵌套 patch 处理多次输入的情况
        with patch('click.prompt') as mock_prompt:
            # 设置模拟返回值
            if isinstance(mock_input, list):
                mock_prompt.side_effect = mock_input
            else:
                mock_prompt.return_value = mock_input
            # 执行测试
            result = get_update_ids(mock_prompt_update_data)

            # 验证结果
            assert sorted(result) == (sorted(expected_ids) if isinstance(expected_ids, list) else expected_ids)

    @set_env(DCS_PROJECT_ID="P20250328172629834")
    def test_dcs_app_update_empty_name(self, runner):
        with patch('dcs_cli.commands.app.get_user_perm') as mock_get_user_perm:
            mock_get_user_perm.return_value = (True, {'data': {'apiPerms': [WORKFLOW_UPDATE_PERM]}})
            # 定义多个返回值（按调用顺序返回）
            mock_responses = [
                (False, {'msg': 'test app update failed.'}),  # 第一次调用返回
                (True, {}),  # 第二次调用返回
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                result = runner.invoke(main, ['app', 'update'])
                assert 'test app update failed.' in result.output.replace('\n', '')
                assert result.exit_code == 0
                assert mock_get.call_count == 1

            mock_responses = [
                (True, {'workflow_list': []}),
                (True, {}),
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                result = runner.invoke(main, ['app', 'update'])
                assert '更新工作流失败。' in result.output.replace('\n', '')
                assert result.exit_code == 0
                assert mock_get.call_count == 1

            mock_responses = [
                (True, {'data': {'workflows': {'1001': '流程A'}, 'count': 1}}),
                (True, {}),
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                with patch('dcs_cli.commands.app.get_update_ids') as mock_get_update_ids:
                    mock_get_update_ids.return_value = ['1001']
                    result = runner.invoke(main, ['app', 'update'])
                    assert get_data_length(result.output) == 1
                    assert result.exit_code == 0
                    assert mock_get.call_count == 2

            mock_responses = [
                (True, {'data': {'workflows': {'1001': '流程A'}, 'count': 1}}),
                (False, 'yyyyyyyyyyy'),
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                with patch('dcs_cli.commands.app.get_update_ids') as mock_get_update_ids:
                    mock_get_update_ids.return_value = ['1001']
                    result = runner.invoke(main, ['app', 'update'])
                    assert result.exit_code == 0
                    assert 'yyyyyyyyyyy' in result.output.replace('\n', '')
                    assert mock_get.call_count == 2

            mock_responses = [
                (True, {'data': {'workflows': mock_prompt_update_data, 'count': 3}}),
                (True, {}),
                (True, {}),
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                with patch('dcs_cli.commands.app.get_update_ids') as mock_ids:
                    mock_ids.return_value = ['1001', '1002']
                    result = runner.invoke(main, ['app', 'update'])
                    assert get_data_length(result.output) == 2
                    assert result.exit_code == 0
                    assert mock_get.call_count == 2
                    assert '更新工作流成功。' in result.output.replace('\n', '')

            mock_responses = [
                (True, {'data': {'workflows': {}, 'count': 0}}),
                (True, {}),
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                result = runner.invoke(main, ['app', 'update'])
                assert result.exit_code == 0
                assert mock_get.call_count == 1
                assert '未找到可更新工作流或该工作流已经是最新版本，无需更新。' in result.output.replace('\n', '')

    @set_env(DCS_PROJECT_ID="P20250328172629834")
    def test_dcs_app_update_by_name(self, runner):
        with patch('dcs_cli.commands.app.get_user_perm') as mock_get_user_perm:
            mock_get_user_perm.return_value = (True, {'data': {'apiPerms': [WORKFLOW_UPDATE_PERM]}})
            # 定义多个返回值（按调用顺序返回）
            mock_responses = [
                (False, {'msg': 'test app update failed.'}),  # 第一次调用返回
                (True, {}),  # 第二次调用返回
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                result = runner.invoke(main, ['app', 'update', '-n', 'xxx'])
                assert 'test app update failed.' in result.output.replace('\n', '')
                assert result.exit_code == 0
                assert mock_get.call_count == 1

            mock_responses = [
                (True, {'data': {'workflows': {}, 'count': 0}}),
                (True, {}),
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                result = runner.invoke(main, ['app', 'update', '--name', 'xxx'])
                assert '未找到可更新工作流或该工作流已经是最新版本，无需更新。' in result.output.replace('\n', '')
                assert result.exit_code == 0
                assert mock_get.call_count == 1

            mock_responses = [
                (True, {'data': {'workflows': mock_prompt_update_data, 'count': 3}}),
                (True, {}),
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                with patch('dcs_cli.commands.app.get_update_ids') as mock_ids:
                    mock_ids.return_value = ['1001']
                    result = runner.invoke(main, ['app', 'update', '-n', '流程A'])
                    assert get_data_length(result.output) == 1
                    assert result.exit_code == 0
                    assert mock_get.call_count == 2

            mock_responses = [
                (True, {'data': {'workflows': mock_prompt_update_data, 'count': 3}}),
                (True, {}),
                (True, {}),
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                with patch('dcs_cli.commands.app.get_update_ids') as mock_ids:
                    mock_ids.return_value = ['1001', '1002']
                    result = runner.invoke(main, ['app', 'update', '-n', '100'])
                    assert get_data_length(result.output) == 2
                    assert result.exit_code == 0
                    assert mock_get.call_count == 2
                    assert '更新工作流成功。' in result.output.replace('\n', '')

            mock_responses = [
                (True, mock_prompt_update_data),
                (True, {}),
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                result = runner.invoke(main, ['app', 'update', '-n', '100'])
                assert result.exit_code == 0
                assert mock_get.call_count == 1
                assert '更新工作流失败。' in result.output.replace('\n', '')

            mock_responses = [
                (True, {'data': {'workflows': {}, 'count': 0}}),
                (True, {}),
            ]
            with patch('dcs_cli.commands.app._safe_request') as mock_get:
                mock_get.side_effect = mock_responses
                result = runner.invoke(main, ['app', 'update', '-n', '100'])
                assert result.exit_code == 0
                assert mock_get.call_count == 1
                assert '未找到可更新工作流或该工作流已经是最新版本，无需更新。' in result.output.replace('\n', '')


@pytest.fixture(scope="class")
def sample_data():
    """类级别的测试数据fixture"""
    return mock_workflow_list


@pytest.mark.usefixtures("runner", "sample_data", "mocker")
class TestHandleRepeatData:

    @pytest.fixture(autouse=True)
    def _setup_mocks(self, mocker):
        """类内mock初始化"""
        self.mocker = mocker
        self.mock_prompt = mocker.patch('dcs_cli.commands.app.click.prompt')
        self.mock_echo = mocker.patch('dcs_cli.commands.app.echo_info')

    def test_option1_overwrite_all(self, sample_data):
        """测试选项1：覆盖所有重复项"""
        self.mocker.patch('dcs_cli.commands.app.click.prompt', return_value=1)

        overwrite, rename = handle_repeat_data(
            data=sample_data,
            overwrite_list=[],
            rename_list=[],
            repeat_count=3
        )

        assert overwrite == ['workflow1', 'workflow2', 'workflow3']
        assert rename == []

    @pytest.mark.parametrize("user_input,expected_overwrite,expected_rename", [
        (2, [], ['workflow1', 'workflow2', 'workflow3']),
        (1, ['workflow1', 'workflow2', 'workflow3'], [])
    ])
    def test_basic_options(self, sample_data, user_input, expected_overwrite, expected_rename):
        """参数化测试基础选项"""
        self.mocker.patch('dcs_cli.commands.app.click.prompt', return_value=user_input)

        overwrite, rename = handle_repeat_data(
            data=sample_data,
            overwrite_list=[],
            rename_list=[],
            repeat_count=3
        )

        assert overwrite == expected_overwrite
        assert rename == expected_rename

    def test_option3_selective_overwrite(self, sample_data):
        """测试选项3：选择性覆盖"""
        self.mocker.patch('dcs_cli.commands.app.click.prompt', side_effect=[3, '1,3', 'b'])

        overwrite, rename = handle_repeat_data(
            data=sample_data,
            overwrite_list=[],
            rename_list=[],
            repeat_count=3
        )

        assert overwrite == ['workflow1', 'workflow3']
        assert rename == ['workflow2']
        assert self.mock_echo.call_count == 0

    def test_option3_invalid_input(self, sample_data, caplog):
        """测试选项3的异常输入处理"""
        self.mocker.patch('dcs_cli.commands.app.click.prompt', side_effect=[3, 'invalid', '5', '1,2'])

        with caplog.at_level('WARNING'):
            overwrite, rename = handle_repeat_data(
                data=sample_data,
                overwrite_list=[],
                rename_list=[],
                repeat_count=3
            )
        assert len(caplog.records) == 0
        assert overwrite == ['workflow1', 'workflow2']

    def test_prepopulated_lists(self, sample_data):
        """测试预填充列表的追加逻辑"""
        self.mocker.patch('dcs_cli.commands.app.click.prompt', return_value=1)

        overwrite, rename = handle_repeat_data(
            data=sample_data,
            overwrite_list=['existing1'],
            rename_list=['existing2'],
            repeat_count=3
        )

        assert 'existing1' in overwrite
        assert 'existing2' in rename


class TestOthers:

    def test_check_file(self):
        assert not check_file('./168168168')[0]

        assert check_file('./')[0]

        assert check_file(SUCCESSED_PATH)[0]

        assert validate_file_format(WDL_PATH, '.wdl')

        assert not validate_file_format(WDL_PATH, '.zip')

        assert validate_file_format(SUCCESSED_PATH, '.zip')

    def test_list_tar_files(self):
        list_tar_files(r'C:\Users\wenzhenbin\Desktop\work\dcs_clients\test_data\zip_test\requests-2.32.3.tar.gz')
        list_tar_files(r'C:\Users\wenzhenbin\Desktop\work\dcs_clients\test_data\zip_test\version.tar.bz2')

    def test_list_archive_files(self):
        list_archive_files(r'C:\Users\wenzhenbin\Desktop\work\dcs_clients\test_data\zip_test\requests-2.32.3.tar.gz')
        list_archive_files(WDL_PATH)


@pytest.mark.parametrize("path, exists, dir_executable, file_readable, expected", [
    # 文件不存在
    ("/path/to/nonexistent/file", False, True, True,
     (False, manager_cli.get_msg_info(FILE_NOT_FOUND_ERROR) % "/path/to/nonexistent/file")),
    # 目录不可执行
    ("/path/to/file", True, False, True, (False, manager_cli.get_msg_info(NO_FILE_READ_PERMISSION) % "/path/to/file")),
    # 文件不可读
    ("/path/to/file", True, True, False, (False, manager_cli.get_msg_info(NO_FILE_READ_PERMISSION) % "/path/to/file")),
    # 文件存在且可读
    ("/path/to/file", True, True, True, (True, 'ok')),
])
def test_check_file(path, exists, dir_executable, file_readable, expected):
    with patch('os.path.exists') as mock_exists, \
            patch('os.path.dirname') as mock_dirname, \
            patch('os.access') as mock_access:

        # 模拟 os.path.exists 的返回值
        mock_exists.return_value = exists

        # 模拟 os.path.dirname 的返回值
        mock_dirname.return_value = os.path.dirname(path) or '.'

        # 模拟 os.access 的返回值
        def access_side_effect(file_path, mode):
            if mode == os.X_OK:
                return dir_executable
            elif mode == os.R_OK:
                return file_readable
            return True

        mock_access.side_effect = access_side_effect

        # 调用 check_file 函数并断言结果
        result = check_file(path)
        assert result == expected


@pytest.mark.parametrize("path, is_str, dir_exists, is_file, mkdir_side_effect, expected", [
    # 路径类型错误（非字符串）
    (123, False, False, False, None, (False, manager_cli.get_msg_info(PATH_TYPE_ERROR) % type(123))),
    # 目标路径是文件而不是目录
    ("/path/to/file", True, True, True, None, (False, manager_cli.get_msg_info(NOT_A_DIRECTORY_ERROR))),
    # 成功创建目录
    ("/path/to/dir", True, False, False, None, (True, "ok")),
    # 权限错误
    ("/path/to/dir", True, False, False, OSError(errno.EACCES, "Permission denied"),
     (False, manager_cli.get_msg_info(PERMISSION_DENIED_ERROR)%"/path/to/dir")),
    # 磁盘空间不足
    ("/path/to/dir", True, False, False, OSError(errno.ENOSPC, "No space left on device"),
     (False, manager_cli.get_msg_info(DISK_SPACE_ERROR))),
    # 其他系统错误
    ("/path/to/dir", True, False, False, OSError(errno.EIO, "Input/output error"),
     (False, manager_cli.get_msg_info(PATH_ERROR))),
    # 未知异常
    ("/path/to/dir", True, False, False, Exception("Unknown error"), (False, manager_cli.get_msg_info(PATH_ERROR))),
])
def test_create_dir(path, is_str, dir_exists, is_file, mkdir_side_effect, expected):
    with patch('os.path.abspath', return_value=path), \
            patch('pathlib.Path.exists', return_value=dir_exists), \
            patch('pathlib.Path.is_file', return_value=is_file), \
            patch('pathlib.Path.mkdir', side_effect=mkdir_side_effect):

        # 模拟路径类型检查
        if not is_str:
            result = create_dir(path)
        else:
            result = create_dir(path)

        # 断言结果
        assert result == expected
