import ast
import glob
import os
import re
import shutil
from functools import wraps
from typing import Dict
from typing import Literal
from unittest.mock import patch


def get_data_length(info):
    """匹配查询结果总数"""
    try:
        data_len = int(re.search(r"Found (\w+) matching data entries.", info).group(1))
    except Exception:
        return -1
    return data_len


def set_env(**env_vars):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            original_env = os.environ.copy()
            try:
                # 设置环境变量
                for k, v in env_vars.items():
                    os.environ[k] = str(v)
                # 执行测试函数
                with patch.dict(os.environ, env_vars):
                    return func(*args, **kwargs)
            finally:
                # 恢复环境
                os.environ.clear()
                os.environ.update(original_env)

        return wrapper

    return decorator


def _test_build_common_headers(
        auth_type: Literal['token', 'access'] = 'token'
) -> Dict[str, str]:
    """构造包含动态认证头的公共请求头

    Args:
        auth_type: 认证类型
            'token' -> 键为 'token'
            'access' -> 键为 'x-access-token'

    Returns:
        包含 zone 和动态 token 的请求头字典
    """
    env_dict = os.environ.copy()
    headers = {'zone': env_dict.get('DCS_ZONE')}
    key = 'token' if auth_type == 'token' else 'X-Access-Token'
    headers[key] = env_dict.get('DCS_X_ACCESS_TOKEN')
    return headers


def delete_test_temp_file(path):
    """删除测试产生的数据"""
    # 匹配当前目录下的目标目录
    matching_dirs = glob.glob(path)

    # 2. 遍历删除所有匹配目录
    for dir_path in matching_dirs:
        if os.path.isdir(dir_path):
            try:
                shutil.rmtree(dir_path)
                print(f"成功删除目录: {dir_path}")
            except Exception as e:
                print(f"删除 {dir_path} 失败: {str(e)}")
        else:
            print(f"忽略非目录文件: {dir_path}")


def get_file_path(text):
    # 正则表达式模式
    text = text.replace('\n', '')
    pattern = r"文件生成成功，路径:\s*(.+)"

    # 匹配
    match = re.search(pattern, text)
    if match:
        # 提取路径
        path = match.group(1)
        return path
    else:
        return 'None'


def get_params(info):
    """获取params参数"""
    try:
        dict_str = re.search(r"params: \{.*?\}", info).group(0)
    except Exception:
        try:
            pattern = r"params:\s*({.*?})\s*headers:"
            dict_str = re.search(pattern, info, re.DOTALL).group(1)
        except Exception:
            return ''
    res = ast.literal_eval(dict_str.replace('params: ', ''))
    return res


if __name__ == '__main__':
    delete_test_temp_file(r'C:\Users\wenzhenbin\Desktop\work\dcs_clients\20250311152330')
