import codecs
import csv
import errno
import os
import re
import traceback
from datetime import datetime
from pathlib import Path
from typing import Any
from typing import Dict
from typing import Iterable
from typing import Literal
from typing import Optional
from typing import Tuple
from typing import Union
from urllib.parse import urljoin

import click
from click.exceptions import UsageError
from tabulate import tabulate

from dcs_cli.common import URL_DICT
from dcs_cli.common import echo_info
from dcs_cli.enums import MsgStatusTypeEnum
from src.codes.common_codes import AUTHENTICATION_FAILED_ERROR
from src.codes.common_codes import CLOUD_SERVICE_ERROR
from src.codes.common_codes import DISK_SPACE_ERROR
from src.codes.common_codes import FILE_NOT_FOUND_ERROR
from src.codes.common_codes import GET_USER_PREM_ERROR
from src.codes.common_codes import NOT_A_DIRECTORY_ERROR
from src.codes.common_codes import NO_FILE_READ_PERMISSION
from src.codes.common_codes import PATH_ERROR
from src.codes.common_codes import PATH_TYPE_ERROR
from src.codes.common_codes import PERMISSION_DENIED_ACCESS_ERROR
from src.codes.common_codes import PERMISSION_DENIED_ERROR
from src.codes.common_codes import PERMISSION_DENIED_WRITE_ERROR
from src.codes.common_codes import SYSTEM_ERROR
from src.codes.manager import manager_cli


def raise_sap_exception(response, *args, **kwargs):
    """抛出云平台报错"""
    if not response.ok:
        raise click.ClickException('{}: {} {} {}'.format('STOmics Cloud raises exception',
                                                         response.status_code, response.reason, response.url))
    data = response.json()
    code = data['code']
    message = '{}: {}'.format('STOmics Cloud raises exception', data['msg'])
    if code == 401:
        raise click.ClickException(message)
    elif code != 0:
        raise click.ClickException(message)


def raise_workflow_exception(response, *args, **kwargs):
    """抛出Workflow报错"""
    if not response.ok:
        data = response.json()
        message = data.get('message_i18n') or data.get('message')
        raise click.ClickException('{}: {}'.format('Workflow raises exception', message))


def raise_stereonote_exception(response, *args, **kwargs):
    """抛出stereonote报错"""
    if response.ok:
        data = response.json()
        code = data['code']
        if code != 0:
            message = data.get('message', '') or data.get('msg', '')
            raise click.ClickException('{}: {} {}'.format('Stereonote raises exception', code, message))


sap_hooks = {'response': raise_sap_exception}
workflow_hooks = {'response': raise_workflow_exception}
stereonote_hooks = {'response': raise_stereonote_exception}


def bytes_to_human_readable(size, decimal_places=2):
    """将字节数转换为易读的字符串表示

    :param size: 字节数
    :param decimal_places: 保留的小数位数（B单位时自动忽略），默认为2
    :return: 易读的字符串，如 "1.23 KB"
    """
    size = int(size)
    units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']

    index = 0
    while size >= 1024 and index < len(units) - 1:
        size /= 1024.0
        index += 1

    unit = units[index]
    if unit == 'B':
        return f'{size}{unit}'
    return f'{size:.{decimal_places}f}{unit}'


def human_readable_to_bytes(human_size):
    """将易读的字节字符串转换回字节数（支持单字母单位如 M/G）"""
    units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
    unit_aliases = {
        'B': 'B', 'K': 'KB', 'KB': 'KB',
        'M': 'MB', 'MB': 'MB',
        'G': 'GB', 'GB': 'GB',
        'T': 'TB', 'TB': 'TB',
        'P': 'PB', 'PB': 'PB',
        'E': 'EB', 'EB': 'EB',
        'Z': 'ZB', 'ZB': 'ZB',
        'Y': 'YB', 'YB': 'YB'
    }

    match = re.match(r'^\s*([+-]?[\d.]+)\s*([A-Za-z]{1,3})\s*$', human_size.strip(), re.IGNORECASE)  # 提取数值和单位（兼容单字母）
    if not match:
        raise ValueError(f'无效的输入格式: {human_size}')

    number_str, unit = match.groups()
    unit = unit.upper()  # 统一转大写

    if unit in unit_aliases:  # 转换单位别名（例如 M → MB）
        unit = unit_aliases[unit]
    else:
        raise ValueError(f'不支持的单位: {unit}')

    try:
        number = abs(float(number_str))
    except ValueError:
        raise ValueError(f'无效的数值部分: {number_str}')

    exponent = units.index(unit)
    bytes_value = number * (1024 ** exponent)  # 计算字节数

    return int(round(bytes_value))


def echo_debug(ctx, *args):
    """根据上下文对象中的调试标志--debug决定是否输出调试信息"""
    debug = ctx.obj.get('debug')
    if debug:
        for i in args:
            click.echo(i)


def to_curl(request, compressed=False, verify=True):
    """将request对象转换为curl字符串

    :param request: 请求对象
    :param compressed: 是否启用压缩
    :param verify: 是否验证SSL证书
    :return: curl字符串
    """
    from shlex import quote

    parts = [
        ('curl', None),
        ('-X', request.method),
    ]

    parts.extend(('-H', f'{k}: {v}') for k, v in sorted(request.headers.items()))

    if request.body:
        body = request.body
        if isinstance(body, bytes):
            body = body.decode('utf-8')
        parts.append(('-d', body))

    if compressed:
        parts.append(('--compressed', None))

    if not verify:
        parts.append(('--insecure', None))

    parts.append((None, request.url))

    return ' '.join(
        quote(str(element))
        for part in parts
        for element in part
        if element is not None
    )


def echo_request(ctx, request):
    """根据上下文对象中的调试标志--debug决定是否输出请求的cURL"""
    debug = ctx.obj.get('debug')
    if debug:
        click.echo(request.method)
        click.echo(request.url)
        if request.body:
            click.echo(request.body)
        click.echo(to_curl(request))
        click.echo()


def get_headers(ctx):
    """获取请求头"""
    headers = {
        'X-Access-Token': ctx.obj['token'],
        'X-Zone': ctx.obj['zone'],
        'X-Client-App': ctx.obj['user_info']['clientApp'],
        'X-Domain-Code': ctx.obj['projectId'],
        'X-Domain-Type': '21',
        'projectId': ctx.obj['projectId'],
    }
    return headers


def make_request(ctx, method, api, headers=None, files=None, data=None, params=None, hooks=None, json=None,
                 session=None, raw=False):
    """发送HTTP请求的通用函数

    :param ctx: 上下文
    :param method: 请求方法，如GET、POST
    :param api: API字符串
    :param headers: 请求头，复用时传
    :param session: 复用时传
    :param raw: True时返回response本身，默认False返回json
    """
    from yarl import URL
    from requests import Session, Request

    if session is None:
        session = Session()

    if headers is None:
        headers = get_headers(ctx)

    url = URL(ctx.obj.get('cloud_url')) / api

    request = session.prepare_request(Request(
        method=method,
        url=url,
        headers=headers,
        files=files,
        data=data,
        params=params,
        hooks=hooks,
        json=json
    ))
    echo_request(ctx, request)
    response = session.send(request)
    return response if raw else response.json()


def paginated_request(ctx, api, params, callback, payload=None, method='POST', hooks=None,
                      params_page_key='page', response_data_key='data', response_record_key='records', all=False,
                      output=False):
    """分页请求API，并根据用户输入进行翻页

    :param ctx: 上下文
    :param api: 请求的API地址
    :param params: Query参数
    :param callback: 回调函数，用于处理每次请求的响应数据
    :param method: 请求方法
    :param payload: JSON参数
    :param hooks: 钩子函数
    :param params_page_key: Query参数中的页码的键值
    :param response_data_key: 响应中获取数组的那层键值
    :param response_record_key: 响应中获取具体数据的那层键值
    :param all: 循环返回所有数据
    :param output: 输出文件路径
    """
    import requests

    session = requests.Session()
    if all:
        all_response = None
        while True:
            response = make_request(ctx, method, api, params=params, json=payload, hooks=hooks, session=session)
            if not all_response:
                all_response = response
            else:
                all_response[response_data_key][response_record_key].extend(
                    response[response_data_key][response_record_key])
            if response[response_data_key]['current'] < response[response_data_key]['pages']:
                params[params_page_key] += 1
            else:
                break
        callback(all_response)

    else:
        while True:
            response = make_request(ctx, method, api, params=params, json=payload, hooks=hooks, session=session)
            callback(response)

            if not response.get(response_data_key):
                break

            if response[response_data_key]['pages'] <= 1:
                break

            if output:
                break

            click.echo('共{}条 第{}/{}页 上一页↑ 下一页↓ 跳转g 退出q'.format(
                response[response_data_key]['total'],
                response[response_data_key]['current'],
                response[response_data_key]['pages']
            ), nl=False)
            c = click.getchar()
            click.echo()

            if c == '\x1b[A' or c == 'àH':  # 向上翻页
                if params[params_page_key] > 1:
                    params[params_page_key] -= 1
            elif c == '\x1b[B' or c == 'àP':  # 向下翻页
                if response[response_data_key]['current'] < response[response_data_key]['pages']:
                    params[params_page_key] += 1
            elif c == 'g':  # 跳转到指定页
                page = click.prompt('请输入跳转的页数', type=click.IntRange(1, response[response_data_key]['pages']))
                if 1 <= page <= response[response_data_key]['pages']:
                    params[params_page_key] = page
            elif c == 'q':  # 退出
                break


def process_exist_option(payload, option, key):
    """处理命令行选项添加到payload，存在就放在key

    :param payload: 要修改的payload
    :param option: 要处理的选项
    :param key: 放置的key
    """
    if option:
        payload[key] = option


class HelpOnInvalidCommand(click.Group):
    """输入无效子命令时打印帮助信息"""

    def parse_args(self, ctx, args):
        try:
            return super().parse_args(ctx, args)
        except Exception as e:
            if str(e) != '0':
                echo_info(e, MsgStatusTypeEnum.ERROR)
                click.echo(ctx.get_help())
            ctx.exit()

    def invoke(self, ctx):
        try:
            return super().invoke(ctx)
        except UsageError as e:
            echo_info(e, MsgStatusTypeEnum.ERROR)
            click.echo(ctx.get_help())
            ctx.exit()


class HelpOnMissingParamCommand(click.Command):
    """用户输入异常的时候打印help信息"""

    def parse_args(self, ctx, args):
        try:
            return super().parse_args(ctx, args)
        except Exception as e:
            if str(e) != '0':
                echo_info(e, MsgStatusTypeEnum.ERROR)
                click.echo(ctx.get_help())
            ctx.exit()


def create_output(module, output, content):
    """将内容输出到文件

    :param module: 模块名
    :param output: 输出文件路径
    :param content: 内容
    :return: 输出文件绝对路径
    """
    path = Path(output)

    if path.is_dir():  # 目录路径则生成系统命名的文件
        target_path = path / '{}_{}.txt'.format(module, datetime.now().strftime('%Y%m%d%H%M'))
    else:  # 文件路径直接使用用户提供的路径
        target_path = path

    target_path.parent.mkdir(parents=True, exist_ok=True)  # 确保目录存在
    with target_path.open('w', encoding='utf-8') as f:
        f.write(content)

    return target_path.resolve()


def is_path_valid(path):
    """
    验证路径是否合法（支持文件和目录路径）
    规则：
    1. 如果路径存在：
        - 是目录：检查该目录写入权限
        - 是文件：检查父目录写入权限
    2. 如果路径不存在：检查第一个存在的父目录写入权限
    """
    abs_path = os.path.abspath(path)

    # 处理根目录特殊情况
    if abs_path == os.path.sep:
        if os.access(os.path.sep, os.W_OK):
            return True, "ok"
        else:
            return False, manager_cli.get_msg_info(PERMISSION_DENIED_WRITE_ERROR) % (abs_path)

    # 场景1: 路径已存在
    if os.path.exists(abs_path):
        if os.path.isdir(abs_path):
            # 直接检查目录权限
            if os.access(abs_path, os.W_OK):
                return True, "ok"
            return False, manager_cli.get_msg_info(PERMISSION_DENIED_WRITE_ERROR) % (abs_path)
        else:
            # 文件路径，检查父目录
            parent_dir = os.path.dirname(abs_path)
            if os.access(parent_dir, os.W_OK):
                return True, "ok"
            return False, manager_cli.get_msg_info(PERMISSION_DENIED_WRITE_ERROR) % (parent_dir)

    # 场景2: 路径不存在，向上查找存在的父目录
    current_dir = abs_path
    while True:
        parent_dir = os.path.dirname(current_dir)

        # 到达根目录
        if parent_dir == current_dir or parent_dir == os.path.sep:
            if os.access(os.path.sep, os.W_OK):
                return True, "ok"
            return False, manager_cli.get_msg_info(PERMISSION_DENIED_WRITE_ERROR) % (os.path.sep)

        # 检查父目录是否存在
        if os.path.exists(parent_dir):
            if not os.path.isdir(parent_dir):
                return False, manager_cli.get_msg_info(NOT_A_DIRECTORY_ERROR)
            if os.access(parent_dir, os.W_OK):
                return True, "ok"
            return False, manager_cli.get_msg_info(PERMISSION_DENIED_WRITE_ERROR) % (parent_dir)

        current_dir = parent_dir


def create_dir(path: str, dir_flag=False) -> Tuple[bool, str]:
    """创建目录并返回操作状态及信息"""
    msg = manager_cli.get_msg_info(PATH_ERROR)
    try:
        # 预处理路径防止无效输入
        if not isinstance(path, str):
            return False, manager_cli.get_msg_info(PATH_TYPE_ERROR) % type(path)

        # 解析目标目录路径，创建目录
        if not dir_flag:
            dir_path = Path(os.path.dirname(os.path.abspath(path)))
        else:
            check_status, check_msg = is_path_valid(path)
            if not check_status:
                return False, check_msg
            dir_path = Path(os.path.abspath(path))
        # 新增防御性校验
        if dir_path.exists() and dir_path.is_file():
            return False, manager_cli.get_msg_info(NOT_A_DIRECTORY_ERROR)

        dir_path.mkdir(parents=True, exist_ok=True)
        return True, "ok"
    except OSError as e:
        # 根据错误类型生成消息
        error_map = {
            errno.EACCES: manager_cli.get_msg_info(PERMISSION_DENIED_ERROR) % path,
            errno.ENOSPC: manager_cli.get_msg_info(DISK_SPACE_ERROR),
            errno.EEXIST: manager_cli.get_msg_info(PATH_ERROR),
        }
        return False, error_map.get(e.errno, msg)
    except Exception:
        return False, msg


def handle_output(outpath: str):
    """处理空字符串"""
    def_path = './'
    if outpath:
        outpath = outpath.strip()
        outpath = outpath if outpath else def_path
    else:
        outpath = def_path
    return outpath


def is_file_path(path: str) -> bool:
    """
    判断路径是否表示文件（基于字符串格式，不依赖实际文件系统）。

    Args:
        path (str): 输入路径（如 'test/abc.txt' 或 'output-dir'）。

    Returns:
        bool: True 表示文件，False 表示文件夹。
    """
    # 规范化路径（处理跨平台分隔符）
    normalized_path = os.path.normpath(path)

    if normalized_path.endswith(os.sep):
        return False

    basename = os.path.basename(normalized_path)
    if '.' in basename:
        parts = basename.split('.')
        if len(parts) > 1 and parts[-1]:
            return True

    return False


def get_format_file_path(path: str, module_name: str) -> tuple:
    """
    :param path: 文件路径或者文件夹名称
    :param module_name: 模块名称，比如app、image等
    :return: 文件路径

    如果已经是文件直接返回，如果是文件夹，就生成对应模块的文件名，比如：image_202503211736.txt
    """
    if not is_file_path(path):
        path = os.path.join(path, f'{module_name}_{get_current_datetime()}.txt')

    status, msg = is_path_valid(os.path.normpath(path))
    return status, msg, path


def generate_txt_data(output_path: str, headers: list, data: Iterable[Iterable[Any]]) -> (bool, str):
    """生成txt文件
    :param output_path: 输出文件路径
    :param headers: 表头信息
    :param data: 数据信息列表或者可迭代对象

    eg:
        headers = ["ID", "城市", "温度(℃)"]
        data = [
            [1, "北京", 28.5],
            [2, "上海", 30.2],
            [3, "广州", 32.1]
        ]
    """
    # 如果文件夹不存在则创建文件夹
    status, msg = create_dir(output_path)
    if not status:
        return False, msg

    try:
        # 写入文件
        with open(output_path, "w", newline='', encoding='utf-8-sig') as file:  # utf-8-sig 含BOM头
            writer = csv.writer(file)
            writer.writerow(headers)
            for row in data:
                file.write(f"{','.join([str(item) for item in row])}\n")
        return True, output_path
    except Exception:
        return False, manager_cli.get_msg_info(SYSTEM_ERROR)


def get_table_info(table_data, translate=None):
    """获取table的header和data信息"""
    headers = [manager_cli.translate_message(column.header, target_lang='en') if translate else column.header for column
               in table_data.columns]
    data = [[str(table_data.columns[col_idx]._cells[row_idx]) for col_idx in range(len(table_data.columns))
             ] for row_idx in range(len(table_data.rows))]
    return headers, data


def output_file(output_path, table_data, module_name, translate=True):
    """
    将table表的数据保存为文件

    :param output_path: 文件路径
    :param table_data: rich的table
    :param module_name: 模块名称
    :param translate: 是否转换为英文【产品要求输出文件的header需要为英文】
    :return:
    """
    # 获取文件路径并且创建文件夹
    status, msg, file_path = get_format_file_path(output_path, module_name)
    if not status:
        return status, msg

    # 构建headers和data信息
    headers, data = get_table_info(table_data, translate)
    data = [[re.sub(r'\x1b\[[\d;]*m', '', item).strip() for item in row] for row in data]
    # 生成数据
    status, msg = generate_txt_data(file_path, headers, data)
    return status, msg


def echo_table_info(table_data):
    headers, data = get_table_info(table_data)
    print(tabulate(
        data,
        headers=headers,
        tablefmt='plain',  # 最简单的空格分隔格式
        stralign='left',
        numalign='left'
    ))


def get_current_datetime() -> str:
    """获取当前时间的紧凑格式字符串(年月日时分)

    Returns:
        str: 格式为YYYYMMDDHHMMSS的16位字符串，示例: 20231025153016
    """
    return datetime.now().strftime("%Y%m%d%H%M%S")


def _safe_request(
        url: str,
        method: str = "GET",
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: int = 60,
        files: Optional[Dict[str, Union[bytes, str, Tuple]]] = None,
        return_type: Literal['origin'] = None
):
    """安全执行 HTTP 请求的封装函数

    参数说明：
    :param url: 请求目标地址（必须）
    :param method: HTTP 方法，默认为 GET
    :param params: 查询参数字典（可选）
    :param data: 表单数据字典（可选）
    :param json: JSON 数据字典（可选）
    :param headers: 请求头字典（可选）
    :param timeout: 超时时间（秒），默认为 60
    :param files: 上传文件字典（可选），值可以是字节/字符串/(文件名, 文件对象)元组
    :param return_type: 对于服务器状态码为500的，我们还是希望直接返回其json格式，用这个设置。

    返回：
    Bool - 请求成功还是失败
    Union[dict, requests.Response] - 根据 return_type 返回对应类型数据
    """
    import requests
    message = manager_cli.get_msg_info(CLOUD_SERVICE_ERROR)
    try:
        if '/api/' in url and 'projectId' not in headers:
            echo_info(f'projectId must be included in the request headers, url: {url}, params: {params}',
                      MsgStatusTypeEnum.ERROR)
            raise Exception('projectId parameter is required')
        response = requests.request(
            method=method.upper(),
            url=url,
            data=data,
            params=params,
            json=json,
            headers=headers,
            timeout=timeout,
            files=files,
        )
        response.raise_for_status()
        # 根据 Content-Type 自动处理响应
        content_type = response.headers.get('Content-Type', '').lower()

        if 'octet-stream' in content_type or 'zip' in content_type:
            return True, response

        if 'application/json' in content_type:
            json_data = response.json()
            if json_data.get('code') == 401:
                return False, manager_cli.get_msg_info(AUTHENTICATION_FAILED_ERROR)
            if json_data.get('code') == 500:
                return False, json_data.get('msg') or json_data.get('message') or message
            return True, response.json()
    except Exception:
        if return_type == 'origin':
            return True, response.json()
        try:
            message = f"{message}: {response.json().get('msg') or response.json().get('message')}"
        finally:
            return False, message


def _build_common_headers(
        ctx: Any,
        auth_type: Literal['token', 'access'] = 'token'
) -> Dict[str, str]:
    """构造包含动态认证头的公共请求头

    Args:
        ctx: 上下文对象（如 Click 上下文）
        auth_type: 认证类型
            'token' -> 键为 'token'
            'access' -> 键为 'x-access-token'

    Returns:
        包含 zone 和动态 token 的请求头字典
    """
    headers = {'X-Zone': ctx.obj.get('zone')}
    key = 'token' if auth_type == 'token' else 'X-Access-Token'
    headers[key] = ctx.obj.get('token')
    headers['projectId'] = ctx.obj.get('projectId')
    headers['X-Domain-Code'] = ctx.obj.get('projectId')
    headers['X-Client-App'] = ctx.obj['user_info']['clientApp']
    return headers


def _build_common_params(key: Literal['page_size', 'limit'] = 'page_size', page_size=10) -> dict:
    """构造公共请求参数"""
    return {
        'page': 1,
        key: page_size
    }


def format_datetime(iso_str: str = None, timestamp_ms: int = None) -> str:
    """将ISO时间或毫秒时间戳转换为用户友好格式

    输入示例：
    - ISO时间："2025-01-13T18:18:18.163000"
    - 时间戳：1740104409000（毫秒）
    输出示例："2025-1-13 18:18:18"

    Args:
        iso_str: ISO 8601格式字符串（与timestamp_ms二选一）
        timestamp_ms: 毫秒级时间戳（与iso_str二选一）

    Returns:
        格式化的时间字符串（月/日去除前导零，时间保留两位）
    """
    try:
        if timestamp_ms is not None:
            dt = datetime.fromtimestamp(timestamp_ms // 1000)
        elif iso_str is not None:
            dt = datetime.fromisoformat(iso_str.replace("Z", "+00:00")).replace(tzinfo=None)
        else:
            raise ValueError("必须提供 iso_str 或 timestamp_ms 中的一个")

        return f"{dt.year}-{dt.month}-{dt.day} {dt.hour:02}:{dt.minute:02}:{dt.second:02}"
    except Exception:
        return ''


def paginate_query(req_url, params, headers, callback, total_page, total_count,
                   params_page_key: Literal['offset', 'page'] = 'page',
                   params_page_offset: Literal[0, 1] = 0,
                   page_size: int = 10, is_multiply=False,
                   ):
    """
    :param req_url: 请求的API地址
    :param params: Query参数
    :param headers: 请求头
    :param callback: 回调函数，用于处理每次请求的响应数据
    :param total_page: 总页数
    :param total_count: 总条数
    :param params_page_key: Query参数中的页码的键值
    :param params_page_offset: 页码偏移量，由于current_page设置为1，故有偏移量这个参数；
        如果page从1开始这里填0，
        如果page从0开始这里填1.
    :param page_size: 每页条数。
    :param is_multiply: 计算起始数据库的index值。
    :return: info
    """
    # current_page: 当前页，默认为1，以符合用户的阅读习惯。
    current_page, flag = 1, True
    go_to_flag = False
    if total_page < 2:  # 翻页
        return

    while True:
        if flag:
            click.echo('共{}条 第{}/{}页 向上翻页↑ 向下翻页↓ 跳转g 退出q'.format(
                total_count, current_page, total_page), nl=False
            )
        c = click.getchar()
        click.echo() if flag else ''
        if c == '\x1b[A' or c == 'àH' or c == 'w' or c == '\x00H':  # 向上翻页
            if current_page > 1:
                current_page -= 1
        elif c == '\x1b[B' or c == 'àP' or c == 's' or c == '\x00P':  # 向下翻页
            if current_page < total_page:
                current_page += 1
        elif c == 'q':  # 退出
            break
        elif c == 'g':  # 跳转到指定页
            current_page = click.prompt('请输入跳转的页数', type=click.IntRange(1, total_page))
            go_to_flag = True

        if (current_page != params[params_page_key] + params_page_offset) or go_to_flag:
            flag, go_to_flag = True, False
            ori_params_page_key = current_page - params_page_offset
            params[params_page_key] = ori_params_page_key * page_size if is_multiply else ori_params_page_key
            status, response = _safe_request(req_url, params=params, headers=headers)
            if not status:
                return echo_info(response, MsgStatusTypeEnum.ERROR)
            # 回调渲染数据
            callback(response)
            if is_multiply:
                params[params_page_key] = ori_params_page_key
        else:
            flag = False


def split_desc(msg):
    """描述太长，截断处理"""
    if not msg:
        return msg
    if len(msg) > 100:
        return msg[:97] + '...'
    else:
        return msg


def safe_decode(text):
    try:
        return codecs.decode(text, 'unicode_escape')
    except UnicodeDecodeError:
        return text  # 或自定义处理逻辑


def echo_debug_info(ctx, req_url, params, headers, records):
    """打印调试信息"""
    if ctx.obj.get('debug'):
        echo_info(f'req_url: {req_url}')
        echo_info(f'params: {params}')
        echo_info(f'headers: {headers}')
        echo_info(f'Found {len(records)} matching data entries.')


def echo_exceprtion(ctx):
    if ctx.obj.get('debug'):
        print(traceback.print_exc())


def handle_msg(msg):
    return msg if msg else ''


def format_user_perm(data):
    '''
    生成用户权限的所有路径
    eg:
        {
            "project_management": {
                "chip": {
                    "run_task": {},
                    "run_task_batch": {},
                    "sn_detail": {
                        "fastq_information": {
                            "copy_path": {},
                        },
                    },
                },
            }
        }
    output:
        project_management.chip.run_task
        project_management.chip.run_task_batch
        project_management.chip.sn_detail.fastq_information.copy_path
    '''

    def generate_paths(data, parent_key='', sep=':'):
        """递归生成所有叶子节点的路径"""
        paths = []

        # 遍历当前层级的所有键值对
        for key, value in data.items():
            # 构建当前完整路径
            new_key = f"{parent_key}{sep}{key}" if parent_key else key

            # 检查值类型
            if isinstance(value, dict):
                # 如果是字典，递归处理
                if value:  # 非空字典继续递归
                    paths.extend(generate_paths(value, new_key, sep))
                else:  # 空字典直接作为路径
                    paths.append(new_key)
            else:
                # 非字典值直接添加路径
                paths.append(new_key)

        return paths

    return generate_paths(data)


def get_user_perm(ctx):
    """获取用户权限"""
    from yarl import URL
    msg = manager_cli.get_msg_info(GET_USER_PREM_ERROR)
    try:
        headers = _build_common_headers(ctx, 'access')
        headers['projectId'] = ctx.obj.get('projectId')
        req_url = urljoin(str(URL(ctx.obj.get('cloud_url'))), URL_DICT.get('app_get_user_perm'))
        params = {
            'domainCode': ctx.obj.get('projectId'),
            'domainType': 21
        }
        status, response = _safe_request(req_url, params=params, headers=headers)
        if not status:
            return False, msg
        return True, format_user_perm(response.get('data'))
    except Exception:
        return False, msg


def check_file(path):
    """检查文件是否存在，并且是否有读取权限"""
    if not os.path.exists(path):
        return False, manager_cli.get_msg_info(FILE_NOT_FOUND_ERROR) % path

    dir_path = os.path.dirname(path) or '.'
    if not os.access(dir_path, os.X_OK):
        return False, manager_cli.get_msg_info(NO_FILE_READ_PERMISSION) % path

    # 检查文件是否有读取权限
    if not os.access(path, os.R_OK):
        return False, manager_cli.get_msg_info(NO_FILE_READ_PERMISSION) % path

    return True, 'ok'
