import click
from dcs_cli.utils import HelpOnInvalidCommand

from dcs_cli.commands import image, app, task, data


@click.group(cls=HelpOnInvalidCommand)
@click.option('--debug/--no-debug', default=False, help='debug模式')
@click.pass_context
def main(ctx, debug):
    import os
    import json
    from pathlib import Path

    # 从文件中读取环境变量
    path = Path('/dcs/cli/dcs_cli_environment.txt')
    if path.exists():
        with path.open('r', encoding='utf-8') as f:
            env = json.load(f)
            for key, value in env.items():
                os.environ[key] = value

    # 解析token
    import jwt
    from src.codes.manager import manager_cli
    from src.codes.common_codes import AUTHENTICATION_FAILED_ERROR
    token = os.getenv('DCS_X_ACCESS_TOKEN')
    try:
        user_info = jwt.decode(token, options={'verify_signature': False})
    except Exception:
        raise click.ClickException(manager_cli.get_msg_info(AUTHENTICATION_FAILED_ERROR))

    # 设置上下文
    ctx.obj = {
        'token': token,
        'projectId': os.getenv('DCS_PROJECT_ID'),
        'zone': os.getenv('DCS_ZONE'),
        'cloud_url': os.getenv('DCS_CLOUD_URL'),
        'workspace_id': os.getenv('DCS_WORKSPACE_ID'),
        'subnet': os.getenv('DCS_SUBNET'),
        'data_work_path': os.getenv('DCS_DATA_WORK_PATH'),
        'share_presonal_path': os.getenv('DCS_SHARE_PERSONAL_PATH'),
        'user_info': user_info,
        'debug': debug
    }


main.add_command(app.app)
main.add_command(data.data)
main.add_command(image.image)
main.add_command(task.task)

if __name__ == '__main__':
    main(auto_envvar_prefix='DCS')  # 环境变量前缀
